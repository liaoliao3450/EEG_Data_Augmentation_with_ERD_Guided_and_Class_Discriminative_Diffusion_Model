import os
import sys
from pathlib import Path
import argparse
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
# 条件导入：支持直接运行和模块运行
try:
    from .dataset import EEGNPYDataset
    from .model import UNet1D
except ImportError:
    from dataset import EEGNPYDataset
    from model import UNet1D
from typing import Tuple, Dict, Optional
try:
    import matplotlib.pyplot as plt
    HAS_MPL = True
except Exception:
    HAS_MPL = False
import json

# 确保可从项目根导入 `metric` 与 `ts2vec`
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 统一评估指标与表征
from tools.utilities.compare_metrics import compare_metrics as _compare_batch_metrics
from tools.utilities.context_fid import calculate_fid as _calculate_fid
from core.utils.ts2vec.ts2vec import TS2Vec

try:
    from tools.utilities.discriminative_metric import discriminative_score_metrics as _disc_metric
    from tools.utilities.predictive_metric import predictive_score_metrics as _pred_metric
    HAS_TF_METRICS = True
except Exception:
    HAS_TF_METRICS = False

try:
    from sklearn.manifold import TSNE as _TSNE_CHECK
    HAS_SK = True
except Exception:
    HAS_SK = False

# EEGNet 分类器（可选）
try:
    from EEGNET import EEGNetEval
    HAS_EEGNET = True
except Exception:
    HAS_EEGNET = False


def get_results_dir_from_key(dataset_key: str) -> str:
    key = dataset_key.lower()
    if key == 'bci2a':
        return os.path.join(str(PROJECT_ROOT), 'data', 'processed', 'BCI2a')
    if key == 'bci2a_fixed':
        return os.path.join(str(PROJECT_ROOT), 'data', 'processed', 'BCI2a_Fixed')
    if key == 'bci2a_fixed_4sec':
        return os.path.join(str(PROJECT_ROOT), 'data', 'processed', 'BCI2a_Fixed_4sec')
    if key == 'bci2b':
        return os.path.join(str(PROJECT_ROOT), 'data', 'processed', 'BCI2b')
    if key == 'seed':
        return os.path.join(str(PROJECT_ROOT), 'data', 'processed', 'SEED')
    raise ValueError(f'未知数据集标识: {dataset_key}')


def get_default_num_classes_from_key(dataset_key: str) -> int:
    key = str(dataset_key).lower()
    if key == 'bci2a':
        return 4
    if key == 'bci2b':
        return 2
    if key == 'seed':
        return 3
    raise ValueError(f'无法为数据集 {dataset_key} 推断类别数，请手动指定 --num_classes')


def resolve_dataset_root(args) -> str:
    """根据数据集标识 + `--subject`（如 A01E/A01T、B0102T）解析数据目录。
    - 若提供 `--subject`，优先在 BCI2a 情况下合并同被试 E/T 两段（A01E + A01T）
    - 否则返回 processed/<DATASET>
    """
    base = args.results_root if args.results_root else get_results_dir_from_key(args.dataset_key)
    subj = str(getattr(args, 'subject', '') or '').strip()
    if subj:
        try:
            key = str(args.dataset_key).lower()
            if key == 'bci2a' and subj.upper().startswith('A') and subj[1:3].isdigit():
                sid = subj[:3].upper()
                cand = [os.path.join(base, f"{sid}E"), os.path.join(base, f"{sid}T")]
                have = [d for d in cand if os.path.exists(os.path.join(d,'X.npy')) and os.path.exists(os.path.join(d,'y.npy'))]
                if len(have) >= 2:
                    import numpy as _np
                    Xe = _np.load(os.path.join(have[0],'X.npy'), allow_pickle=True); ye = _np.load(os.path.join(have[0],'y.npy'), allow_pickle=True).astype(int)
                    Xt = _np.load(os.path.join(have[1],'X.npy'), allow_pickle=True); yt = _np.load(os.path.join(have[1],'y.npy'), allow_pickle=True).astype(int)
                    if Xe.shape[1:] == Xt.shape[1:]:
                        X = _np.concatenate([Xe, Xt], axis=0); y = _np.concatenate([ye, yt], axis=0)
                        combined_dir = os.path.join(base, f"{sid}_ET")
                        os.makedirs(combined_dir, exist_ok=True)
                        _np.save(os.path.join(combined_dir,'X.npy'), X); _np.save(os.path.join(combined_dir,'y.npy'), y)
                        return combined_dir
                if len(have) == 1:
                    return have[0]
        except Exception:
            pass
        return os.path.join(base, subj)
    return base


def cosine_beta_schedule(timesteps, s=0.008):
    steps = timesteps + 1
    x = torch.linspace(0, timesteps, steps)
    alphas_cumprod = torch.cos(((x / timesteps) + s) / (1 + s) * np.pi * 0.5) ** 2
    alphas_cumprod = alphas_cumprod / alphas_cumprod[0]
    betas = 1 - (alphas_cumprod[1:] / alphas_cumprod[:-1])
    return torch.clamp(betas, 1e-6, 0.999)


class Diffusion1D:
    def __init__(self, model: UNet1D, n_steps: int, device: torch.device, cfg_drop_prob: float = 0.1, guidance_scale: float = 0.0):
        self.model = model
        self.device = device
        self.n_steps = n_steps
        self.beta = cosine_beta_schedule(n_steps).to(device)
        self.alpha = 1. - self.beta
        self.alpha_bar = torch.cumprod(self.alpha, dim=0)
        # classifier-free guidance 配置
        self.cfg_drop_prob = float(cfg_drop_prob)
        self.guidance_scale = float(guidance_scale)

    @staticmethod
    def psd_loss(pred: torch.Tensor, target: torch.Tensor, fs: float = 250.0,
                 bands=((1,3),(4,7),(8,12),(13,30)), weights=(0.5,0.9,1.1,0.9)) -> torch.Tensor:
        eps = 1e-8
        pred_fft = torch.fft.rfft(pred, dim=-1)
        targ_fft = torch.fft.rfft(target, dim=-1)
        pred_psd = torch.log10((pred_fft.real**2 + pred_fft.imag**2) + eps)
        targ_psd = torch.log10((targ_fft.real**2 + targ_fft.imag**2) + eps)
        freqs = torch.fft.rfftfreq(pred.size(-1), d=1.0/fs).to(pred.device)
        w = torch.tensor(weights, dtype=pred.dtype, device=pred.device)
        w = w / (w.sum() + 1e-8)
        losses = []
        for bi, (fmin, fmax) in enumerate(bands):
            mask = (freqs >= fmin) & (freqs <= fmax)
            losses.append(w[bi] * F.l1_loss(pred_psd[..., mask], targ_psd[..., mask]))
        return torch.stack(losses).sum()

    @staticmethod
    def tv1d(x: torch.Tensor) -> torch.Tensor:
        return (x[..., 1:] - x[..., :-1]).abs().mean()

    def q_sample(self, x0: torch.Tensor, t: torch.Tensor, noise: torch.Tensor | None = None):
        if noise is None:
            noise = torch.randn_like(x0)
        mean = (self.alpha_bar.gather(0, t).sqrt())[:, None, None] * x0
        var = (1 - self.alpha_bar.gather(0, t))[:, None, None].sqrt()
        return mean + var * noise

    def p_sample(self, xt: torch.Tensor, t: torch.Tensor, eps_theta: torch.Tensor):
        alpha = self.alpha.gather(0, t)[:, None, None]
        alpha_bar = self.alpha_bar.gather(0, t)[:, None, None]
        eps_coef = (1 - alpha) / (1 - alpha_bar).sqrt()
        mean = (1 / alpha.sqrt()) * (xt - eps_coef * eps_theta)
        var = self.beta.gather(0, t)[:, None, None]
        noise = torch.randn_like(xt)
        return mean + var.sqrt() * noise

    def loss(self, x0: torch.Tensor, y: torch.Tensor | None = None,
             lambda_psd: float = 0.02, lambda_tv: float = 0.005, lambda_x_psd: float = 0.02,
             fs: float = 250.0, bands=((1,3),(4,7),(8,12),(13,30)), weights=(0.5,0.9,1.1,0.9)):
        b = x0.size(0)
        t = torch.randint(0, self.n_steps, (b,), device=x0.device, dtype=torch.long)
        noise = torch.randn_like(x0)
        xt = self.q_sample(x0, t, noise)
        # 训练时随机丢弃条件，使用 -1 表示无条件
        if y is not None and getattr(self.model, 'num_classes', 0) > 0 and self.cfg_drop_prob > 0:
            drop_mask = (torch.rand_like(y.float()) < self.cfg_drop_prob)
            y_in = y.clone()
            y_in[drop_mask] = -1
        else:
            y_in = y
        eps_theta = self.model(xt, t, y_in)
        loss_eps = F.mse_loss(eps_theta, noise)
        alpha_bar_t = self.alpha_bar.gather(0, t)[:, None, None]
        x0_pred = (xt - (1 - alpha_bar_t).sqrt() * eps_theta) / alpha_bar_t.sqrt()
        loss_psd = self.psd_loss(eps_theta, noise, fs=fs, bands=bands, weights=weights)
        loss_x_psd = self.psd_loss(x0_pred, x0, fs=fs, bands=bands, weights=weights)
        loss_tv = self.tv1d(eps_theta)
        return loss_eps + lambda_psd * loss_psd + lambda_x_psd * loss_x_psd + 2.0 * lambda_tv * loss_tv

    @torch.no_grad()
    def sample(self, n: int, channels: int, length: int, y: torch.Tensor | None = None, n_steps: int | None = None,
               smooth_every: int = 10):
        n_steps = n_steps or self.n_steps
        x = torch.randn(n, channels, length, device=self.device)
        for i in range(n_steps):
            t = torch.full((n,), self.n_steps - i - 1, device=self.device, dtype=torch.long)
            if y is None or getattr(self.model, 'num_classes', 0) == 0 or self.guidance_scale <= 0:
                eps_theta = self.model(x, t, y)
            else:
                # 无条件分支使用 y=-1
                y_uc = torch.full_like(y, -1)
                eps_uncond = self.model(x, t, y_uc)
                eps_cond = self.model(x, t, y)
                w = self.guidance_scale
                eps_theta = eps_uncond + w * (eps_cond - eps_uncond)
            x = self.p_sample(x, t, eps_theta)
            if smooth_every and (i % max(1, smooth_every) == 0):
                x = (
                    F.pad(x, (2,2), mode='replicate')[:,:,0:-4]
                    + 2*F.pad(x, (1,1), mode='replicate')[:,:,0:-2]
                    + 2*F.pad(x, (1,1), mode='replicate')[:,:,2:]
                    + F.pad(x, (2,2), mode='replicate')[:,:,4:]
                ) / 5.75
        return x


def train(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    dataset_root = resolve_dataset_root(args)
    # 条件模式下自动补齐类别数
    if args.conditional and (getattr(args, 'num_classes', -1) is None or int(args.num_classes) <= 0):
        args.num_classes = get_default_num_classes_from_key(args.dataset_key)
        print(f"[Info] (train) 自动设置 num_classes={args.num_classes} for dataset={args.dataset_key}")

    train_ds = EEGNPYDataset(dataset_dir=dataset_root, split='train', window_size=args.window_size, step=args.step, include_tail=args.include_tail, no_sliding=args.no_sliding)
    val_ds = EEGNPYDataset(dataset_dir=dataset_root, split='val', window_size=args.window_size, step=args.step, include_tail=args.include_tail, no_sliding=args.no_sliding)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, pin_memory=True)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, pin_memory=True)

    C, T = train_ds.n_channels, train_ds.n_times

    model = UNet1D(in_channels=C, base=args.base, t_dim=args.time_dim, num_classes=(args.num_classes if args.conditional else 0), cond_embed_dim=args.cond_embed_dim).to(device)
    diffusion = Diffusion1D(model, n_steps=args.n_steps, device=device,
                            cfg_drop_prob=(args.cfg_drop_prob if args.conditional else 0.0),
                            guidance_scale=(args.guidance_scale if args.conditional else 0.0))

    opt = torch.optim.Adam(model.parameters(), lr=args.lr)

    for epoch in range(args.epochs):
        model.train()
        total = 0.0
        for x, y in train_loader:
            x = x.to(device)
            y = y.to(device) if args.conditional else None
            loss = diffusion.loss(x, y, lambda_psd=args.lambda_psd, lambda_tv=args.lambda_tv,
                                   lambda_x_psd=args.lambda_x_psd, fs=args.fs)
            opt.zero_grad(); loss.backward(); opt.step()
            total += float(loss.item())
        print(f"Epoch {epoch}: loss={total/len(train_loader):.6f}")

        with torch.no_grad():
            x_gen = diffusion.sample(n=args.n_samples, channels=C, length=T,
                                     y=(torch.randint(0, max(1, int(args.num_classes)), (args.n_samples,), device=device) if args.conditional else None),
                                     n_steps=min(100, args.n_steps), smooth_every=args.smooth_every)
            os.makedirs(args.out_dir, exist_ok=True)
            np.save(os.path.join(args.out_dir, f"ddpm_preview_epoch_{epoch}.npy"), x_gen.cpu().numpy())

        if (epoch + 1) % args.save_every == 0:
            os.makedirs(args.ckpt_dir, exist_ok=True)
            torch.save({'model': model.state_dict(), 'epoch': epoch+1, 'args': vars(args)},
                       os.path.join(args.ckpt_dir, f'ddpm_epoch_{epoch+1}.pt'))

    return model


def _l2_normalize_time(x: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    """中心化 + 沿时间维 L2 归一化，统一幅值与基线。"""
    assert x.ndim == 3
    x = x - x.mean(axis=2, keepdims=True)
    denom = np.sqrt(np.sum(x * x, axis=2, keepdims=True) + eps)
    return x / denom


def evaluate(args) -> Dict[str, float]:
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    dataset_root = resolve_dataset_root(args)
    if args.conditional and (getattr(args, 'num_classes', -1) is None or int(args.num_classes) <= 0):
        args.num_classes = get_default_num_classes_from_key(args.dataset_key)
        print(f"[Info] (evaluate) 自动设置 num_classes={args.num_classes} for dataset={args.dataset_key}")

    test_ds = EEGNPYDataset(dataset_dir=dataset_root, split='test', window_size=args.window_size, step=args.step, include_tail=args.include_tail, no_sliding=args.no_sliding)
    C, T = test_ds.n_channels, test_ds.n_times

    model = UNet1D(in_channels=C, base=args.base, t_dim=args.time_dim, num_classes=(args.num_classes if args.conditional else 0), cond_embed_dim=args.cond_embed_dim).to(device)
    diffusion = Diffusion1D(model, n_steps=args.n_steps, device=device,
                            cfg_drop_prob=(args.cfg_drop_prob if args.conditional else 0.0),
                            guidance_scale=(args.guidance_scale if args.conditional else 0.0))

    # 加载 ckpt（支持自动选择最新）
    def _auto_ckpt() -> Optional[str]:
        try:
            if os.path.isdir(args.ckpt_dir):
                cand = []
                for fn in os.listdir(args.ckpt_dir):
                    if fn.startswith('ddpm_epoch_') and fn.endswith('.pt'):
                        try:
                            num = int(fn.split('ddpm_epoch_')[-1].split('.pt')[0])
                        except Exception:
                            num = -1
                        cand.append((num, os.path.join(args.ckpt_dir, fn)))
                if cand:
                    cand.sort(key=lambda x: x[0])
                    return cand[-1][1]
        except Exception:
            pass
        return None

    if args.ckpt and os.path.exists(args.ckpt):
        state = torch.load(args.ckpt, map_location=device)
        model.load_state_dict(state['model'])
        print(f"Loaded checkpoint: {args.ckpt}")
    else:
        auto = _auto_ckpt()
        if auto:
            state = torch.load(auto, map_location=device)
            model.load_state_dict(state['model'])
            print(f"[Info] 未提供 --ckpt，已自动选择: {auto}")
        else:
            raise AssertionError('评估需要有效的 --ckpt 或 checkpoints_ddpm 下的权重')
    model.eval()

    # 采样规模
    n_total = len(test_ds)
    n_eval = args.eval_samples if args.eval_samples > 0 else n_total
    n_eval = min(n_eval, n_total)
    rng = np.random.RandomState(0)
    sel = rng.permutation(n_total)[:n_eval]

    # 真实数据 [B,C,T]，评估口径 L2 标准化
    real = np.stack([test_ds[i][0].numpy() for i in sel], axis=0).astype(np.float32)
    real = _l2_normalize_time(real)

    # 生成数据
    gen_list = []
    gen_labels_list = []
    bs = min(args.batch_size, n_eval)
    with torch.no_grad():
        for i in range(0, n_eval, bs):
            cur = min(bs, n_eval - i)
            if args.conditional:
                lbl_np = np.array([int(test_ds[i_idx][1]) for i_idx in sel[i:i+cur]], dtype=np.int64)
                lbl = torch.from_numpy(lbl_np % int(args.num_classes)).long().to(device)
                gen_labels_list.append(lbl_np)
            else:
                lbl = None
            # 评估用采样：关闭平滑，避免过度低通导致波形失真
            xg = diffusion.sample(n=cur, channels=C, length=int(args.window_size), y=lbl, n_steps=args.sample_steps, smooth_every=0)
            # 中心化 + L2 归一化到统一幅值
            xg = xg - xg.mean(dim=2, keepdim=True)
            xg = F.normalize(xg, p=2, dim=2)
            gen_list.append(xg.cpu().numpy())
    gen = np.concatenate(gen_list, axis=0)
    gen_labels = np.concatenate(gen_labels_list, axis=0).astype(np.int64) if (args.conditional and gen_labels_list) else None

    # 保存样本（可选）
    os.makedirs(args.eval_save_dir, exist_ok=True)
    if not args.no_save_gen:
        np.save(os.path.join(args.eval_save_dir, 'gen_eval.npy'), gen)
        np.save(os.path.join(args.eval_save_dir, 'real_eval.npy'), real)

    # 基础指标
    rp = rng.permutation(n_eval)
    paired_real = real[rp]
    basic = _compare_batch_metrics(paired_real, gen)

    # CFID（可选）
    cfid = None
    ts2vec = None
    if not args.skip_cfid:
        cfid_n = min(args.cfid_max_samples, n_eval)
        rr = real[:cfid_n].transpose(0, 2, 1)
        gg = gen[:cfid_n].transpose(0, 2, 1)
        ts_device = 'cuda' if torch.cuda.is_available() else 'cpu'
        ts2vec = TS2Vec(input_dims=rr.shape[-1], device=ts_device, batch_size=args.cfid_batch_size, lr=0.001, output_dims=320, max_train_length=args.cfid_max_train_len)
        ts2vec.fit(rr, n_iters=args.cfid_iters, verbose=False)
        rep_r = ts2vec.encode(rr, encoding_window='full_series')
        rep_g = ts2vec.encode(gg, encoding_window='full_series')
        cfid = float(_calculate_fid(rep_r, rep_g))

    results: Dict[str, float] = {
        'psnr': float(basic['psnr']),
        'mae': float(basic['mae']),
        'ssim': float(basic['ssim']),
        'kappa': float(basic['kappa']),
    }
    if cfid is not None:
        results['context_fid'] = cfid

    # 判别性/可预测性（可选）
    if args.eval_disc_pred:
        if not HAS_TF_METRICS:
            print('[warn] 缺少 TensorFlow v1，跳过判别性/可预测性')
        else:
            try:
                rr = real.transpose(0, 2, 1)
                gg = gen.transpose(0, 2, 1)
                dscore, fake_acc, real_acc = _disc_metric(rr, gg)
                pscore = _pred_metric(rr, gg)
                results['disc_score'] = float(dscore)
                results['disc_fake_acc'] = float(fake_acc)
                results['disc_real_acc'] = float(real_acc)
                results['pred_score_mae'] = float(pscore)
            except Exception as e:
                print(f'[warn] 判别性/可预测性评估失败: {e}')

    # 分类效用评估（可选，仅条件生成时才有标签）
    def _classification_utility_eval(
        train_ds: EEGNPYDataset,
        test_real: np.ndarray,
        test_real_labels: np.ndarray,
        gen: np.ndarray,
        gen_labels: np.ndarray,
        num_classes: int,
        out_dir: str,
        do_confmat: bool,
        cls_epochs: int,
        cls_lr: float,
        use_eegnet: bool = False,
    ) -> Dict[str, float]:
        cls_device = torch.device('cpu')
        nc = int(num_classes) if int(num_classes) > 0 else 1
        if use_eegnet and HAS_EEGNET:
            clf = EEGNetEval(train_ds.n_channels, train_ds.n_times, nc, freeze_backbone=True).to(cls_device)
        else:
            class SimpleCNN(torch.nn.Module):
                def __init__(self, in_channels: int, seq_len: int, num_classes: int):
                    super().__init__()
                    self.conv1 = torch.nn.Conv1d(in_channels, 32, kernel_size=7, padding=3)
                    self.bn1 = torch.nn.BatchNorm1d(32)
                    self.conv2 = torch.nn.Conv1d(32, 64, kernel_size=5, padding=2)
                    self.bn2 = torch.nn.BatchNorm1d(64)
                    self.conv3 = torch.nn.Conv1d(64, 64, kernel_size=3, padding=1)
                    self.bn3 = torch.nn.BatchNorm1d(64)
                    self.head = torch.nn.Linear(64*seq_len, num_classes)
                def forward(self, x):
                    x = F.relu(self.bn1(self.conv1(x)))
                    x = F.relu(self.bn2(self.conv2(x)))
                    x = F.relu(self.bn3(self.conv3(x)))
                    x = x.flatten(1)
                    return self.head(x)
            clf = SimpleCNN(train_ds.n_channels, train_ds.n_times, nc).to(cls_device)

        opt = torch.optim.Adam(clf.parameters(), lr=float(cls_lr))
        ce = torch.nn.CrossEntropyLoss()
        train_loader = DataLoader(train_ds, batch_size=64, shuffle=True)
        clf.train()
        for _ in range(max(1, int(cls_epochs))):
            for xb, yb in train_loader:
                xb = xb.to(cls_device)
                yb = torch.remainder(yb.long(), nc).to(cls_device)
                opt.zero_grad(); logits = clf(xb); loss = ce(logits, yb); loss.backward(); opt.step()

        def eval_acc(x: np.ndarray, y: np.ndarray) -> float:
            clf.eval(); accs = []
            with torch.no_grad():
                bs = 128
                for i in range(0, len(x), bs):
                    xb = torch.from_numpy(x[i:i+bs]).float().to(cls_device)
                    yb = torch.from_numpy(y[i:i+bs]).long(); yb = torch.remainder(yb, nc).to(cls_device)
                    pred = clf(xb).argmax(dim=1)
                    accs.append((pred==yb).float().mean().item())
            return float(np.mean(accs)) if accs else 0.0

        real_acc = eval_acc(test_real, test_real_labels)
        gen_acc = eval_acc(gen, gen_labels)
        res: Dict[str, float] = {'cls_acc_real': real_acc, 'cls_acc_gen': gen_acc}
        if do_confmat and HAS_SK and HAS_MPL:
            from sklearn.metrics import confusion_matrix
            with torch.no_grad():
                y_true = test_real_labels
                y_pred = []
                bs = 128
                for i in range(0, len(test_real), bs):
                    xb = torch.from_numpy(test_real[i:i+bs]).float().to(cls_device)
                    pred = clf(xb).argmax(dim=1).cpu().numpy(); y_pred.append(pred)
                y_pred = np.concatenate(y_pred, axis=0)
            cm = confusion_matrix(y_true, y_pred)
            plt.figure(figsize=(5,4)); im = plt.imshow(cm, cmap='Blues', interpolation='nearest'); plt.colorbar(im, fraction=0.046, pad=0.04)
            plt.xticks(np.arange(cm.shape[1]), [str(i) for i in range(cm.shape[1])])
            plt.yticks(np.arange(cm.shape[0]), [str(i) for i in range(cm.shape[0])])
            for i in range(cm.shape[0]):
                for j in range(cm.shape[1]):
                    plt.text(j, i, str(cm[i, j]), ha='center', va='center', color='black', fontsize=8)
            plt.xlabel('Predicted'); plt.ylabel('True'); plt.title('Confusion Matrix (Classifier on Real Test)')
            plt.gca().set_aspect('equal', adjustable='box')
            plt.tight_layout(); os.makedirs(out_dir, exist_ok=True)
            plt.savefig(os.path.join(out_dir, 'confusion_matrix_real.png'), dpi=150)
        return res

    if getattr(args, 'eval_cls_utility', False) and args.conditional and gen_labels is not None:
        cls_res = _classification_utility_eval(
            train_ds=EEGNPYDataset(dataset_dir=dataset_root, split='train', window_size=args.window_size, step=args.step, include_tail=args.include_tail, no_sliding=args.no_sliding),
            test_real=real,
            test_real_labels=np.array([int(test_ds[i_idx][1]) for i_idx in sel], dtype=np.int64),
            gen=gen,
            gen_labels=gen_labels,
            num_classes=args.num_classes,
            out_dir=args.eval_save_dir,
            do_confmat=getattr(args, 'viz_confmat', False),
            cls_epochs=getattr(args, 'cls_epochs', 3),
            cls_lr=getattr(args, 'cls_lr', 1e-3),
            use_eegnet=(getattr(args, 'cls_model', 'eegnet') == 'eegnet')
        )
        results.update(cls_res)
    elif getattr(args, 'eval_cls_utility', False) and not args.conditional:
        print('[warn] 非条件模型无法进行分类效用评估，已跳过')

    # 可视化（可选）
    def _plot_psd_compare(real: np.ndarray, gen: np.ndarray, sfreq: float, out_path: str) -> None:
        from mne.time_frequency import psd_array_multitaper
        B = min(len(real), len(gen), 64)
        real_b = real[:B]; gen_b = gen[:B]
        def _avg_psd(x: np.ndarray):
            psds = []
            for xi in x:
                p, f = psd_array_multitaper(xi, fmin=1.0, fmax=40.0, sfreq=sfreq)
                psds.append(p.mean(axis=0))
            return f, np.mean(np.stack(psds, axis=0), axis=0)
        fo, o = _avg_psd(real_b)
        fg, g = _avg_psd(gen_b)
        plt.figure(figsize=(6,4))
        plt.plot(fo, 10*np.log10(o + 1e-12), label='Original', c='k')
        plt.plot(fg, 10*np.log10(g + 1e-12), label='Generated', c='tab:red')
        plt.xlabel('Frequency (Hz)'); plt.ylabel('PSD (dB)'); plt.title('PSD: Real vs Gen (DDPM)')
        plt.legend(); plt.tight_layout(); plt.savefig(out_path, dpi=150)

    def _plot_tsne(real: np.ndarray, gen: np.ndarray, ts2: Optional[TS2Vec], out_path: str) -> None:
        try:
            from sklearn.manifold import TSNE
        except Exception:
            return
        def to_repr(x: np.ndarray) -> np.ndarray:
            if ts2 is not None:
                return ts2.encode(x.transpose(0,2,1), encoding_window='full_series')
            return x.mean(axis=1)
        zr = to_repr(real); zg = to_repr(gen)
        X = np.concatenate([zr, zg], axis=0)
        domain = np.array([0]*len(zr) + [1]*len(zg))
        perpl = max(5, min(30, len(X)//10 if (len(X)//10)>0 else 5))
        tsne = TSNE(n_components=2, perplexity=perpl, init='pca', random_state=0)
        X2 = tsne.fit_transform(X)
        plt.figure(figsize=(6,5))
        plt.scatter(X2[domain==0,0], X2[domain==0,1], c='k', s=10, alpha=0.5, label='Real')
        plt.scatter(X2[domain==1,0], X2[domain==1,1], c='tab:red', s=10, alpha=0.5, label='Generated')
        plt.legend(); plt.title('t-SNE (DDPM)'); plt.tight_layout(); plt.savefig(out_path, dpi=150)

    def _plot_wave_compare(real: np.ndarray, gen: np.ndarray, out_path: str, channel: int, n_examples: int, t_start: int, t_stop: int, real_labels=None, gen_labels=None, align: bool = True, max_lag: int = 32) -> None:
        # 防御性 L2 归一化
        def _l2n(x: np.ndarray, eps: float = 1e-8):
            d = np.sqrt((x**2).sum(axis=2, keepdims=True)+eps); return x/np.maximum(d, eps)
        real2 = _l2n(real.astype(np.float32)); gen2 = _l2n(gen.astype(np.float32))
        B, C, T = real2.shape
        n = min(n_examples, B)
        t_stop = T if (t_stop is None or t_stop <= 0 or t_stop > T) else t_stop
        plt.figure(figsize=(8, 2.0*n))
        for i in range(n):
            r_full = real2[i, channel]; g_full = gen2[i, channel]
            if align:
                # 基于最大滞后相关的对齐，仅用于可视化
                cc, lag = _max_lag_corr_1d(r_full, g_full, max_lag=max_lag)
                if lag > 0:
                    r_al, g_al = r_full[lag:], g_full[:-lag]
                elif lag < 0:
                    r_al, g_al = r_full[:lag], g_full[-lag:]
                else:
                    r_al, g_al = r_full, g_full
            else:
                r_al, g_al = r_full, g_full
            # 截取窗口
            r = r_al[t_start:t_stop]; g = g_al[t_start:t_stop]
            t = np.arange(len(r)); ax = plt.subplot(n,1,i+1)
            ax.plot(t, r, 'k', lw=1.0, label='Original'); ax.plot(t, g, 'r', lw=0.9, alpha=0.9, label='Generated')
            title = [f'ch={channel}']
            if real_labels is not None and i < len(real_labels): title.insert(0, f'real={int(real_labels[i])}')
            if gen_labels is not None and i < len(gen_labels): title.append(f'gen={int(gen_labels[i])}')
            ax.set_title(' | '.join(title), fontsize=9)
            if i==0: ax.legend(loc='upper right', fontsize=8)
        plt.xlabel('Time (samples)'); plt.tight_layout(); plt.savefig(out_path, dpi=150)

    def _plot_erd_ers(real: np.ndarray, gen: np.ndarray, sfreq: float, band: str, out_path: str) -> None:
        from mne.time_frequency import psd_array_multitaper
        band_map = {'delta': (1,3), 'theta': (4,7), 'alpha': (8,12), 'mu': (8,12), 'beta': (13,30)}
        fmin, fmax = band_map.get(band, (8,12))
        def band_power(x: np.ndarray) -> float:
            p, f = psd_array_multitaper(x, fmin=fmin, fmax=fmax, sfreq=sfreq)
            return float(10 * np.log10(p.mean(axis=0).mean(axis=0) + 1e-12))
        r_bp = [band_power(x) for x in real]
        g_bp = [band_power(x) for x in gen]
        baseline = float(np.mean(r_bp))
        r_rel = (np.array(r_bp) - baseline) / (baseline + 1e-12) * 100.0
        g_rel = (np.array(g_bp) - baseline) / (baseline + 1e-12) * 100.0
        plt.figure(figsize=(6,4))
        plt.hist(r_rel, bins=20, alpha=0.6, label='Original')
        plt.hist(g_rel, bins=20, alpha=0.6, label='Generated')
        plt.xlabel(f'{band} band relative power change (%)'); plt.ylabel('Count'); plt.title('ERD/ERS (DDPM)')
        plt.legend(); plt.tight_layout(); plt.savefig(out_path, dpi=150)

    # 可视化开关
    if args.viz_psd:
        _plot_psd_compare(real, gen, sfreq=args.fs, out_path=os.path.join(args.eval_save_dir, 'psd_compare_ddpm.png'))
    if args.viz_tsne:
        _plot_tsne(real, gen, ts2vec, os.path.join(args.eval_save_dir, 'tsne_ddpm.png'))
    if args.viz_erd:
        band = getattr(args, 'erd_band', 'mu')
        _plot_erd_ers(real, gen, sfreq=args.fs, band=band, out_path=os.path.join(args.eval_save_dir, f'erd_{band}_ddpm.png'))
    if getattr(args, 'viz_wave', False):
        _plot_wave_compare(real, gen, out_path=os.path.join(args.eval_save_dir, 'wave_compare_ddpm.png'),
                           channel=args.viz_wave_channel, n_examples=args.viz_wave_n,
                           t_start=args.viz_wave_t_start, t_stop=(args.viz_wave_t_stop if args.viz_wave_t_stop>0 else None),
                           real_labels=(np.array([test_ds[i][1] for i in sel], dtype=np.int64) if args.conditional else None),
                           gen_labels=(np.array([test_ds[i][1] for i in sel], dtype=np.int64) if args.conditional else None))

    # 💾 保存ERD增强所需的viz_cache.npz格式
    try:
        from core.utils.save_viz_cache import save_viz_cache
        save_viz_cache(args.eval_save_dir, gen, real, test_ds, sel, gen_labels, args)
    except Exception as e:
        print(f"⚠️ 保存viz_cache.npz失败: {e}")

    # 打印与保存
    print('=== DDPM Evaluation ===')
    for k, v in results.items():
        print(f"{k.upper()}: {v:.6f}")
    with open(os.path.join(args.eval_save_dir, 'metrics_ddpm.txt'), 'w', encoding='utf-8') as f:
        for k, v in results.items():
            f.write(f"{k.upper()}: {v:.6f}\n")
    with open(os.path.join(args.eval_save_dir, 'metrics_ddpm.json'), 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    with open(os.path.join(args.eval_save_dir, 'metrics.json'), 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    try:
        np.save(os.path.join(args.eval_save_dir, 'metrics.npy'), np.array(list(results.items()), dtype=object))
    except Exception:
        pass
    return results

def sample(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    dataset_root = resolve_dataset_root(args)
    if args.conditional and (getattr(args, 'num_classes', -1) is None or int(args.num_classes) <= 0):
        args.num_classes = get_default_num_classes_from_key(args.dataset_key)
        print(f"[Info] (sample) 自动设置 num_classes={args.num_classes} for dataset={args.dataset_key}")
    test_ds = EEGNPYDataset(dataset_dir=dataset_root, split='test', window_size=args.window_size, step=args.step, include_tail=args.include_tail, no_sliding=args.no_sliding)
    C, T = test_ds.n_channels, test_ds.n_times

    model = UNet1D(in_channels=C, base=args.base, t_dim=args.time_dim, num_classes=(args.num_classes if args.conditional else 0), cond_embed_dim=args.cond_embed_dim).to(device)
    diffusion = Diffusion1D(model, n_steps=args.n_steps, device=device,
                            cfg_drop_prob=(args.cfg_drop_prob if args.conditional else 0.0),
                            guidance_scale=(args.guidance_scale if args.conditional else 0.0))

    def _load_ckpt_with_emb_adapt(model: torch.nn.Module, ckpt_path: str):
        state = torch.load(ckpt_path, map_location=device)
        sd = state['model'] if 'model' in state else state
        model_sd = model.state_dict()
        adapted = 0
        for k, v in list(sd.items()):
            if k.endswith('emb.weight') and k in model_sd:
                w_old = v
                w_new = model_sd[k]
                # 线性层权重形状: [out_features, in_features]
                if w_old.shape != w_new.shape:
                    of_old, inf_old = w_old.shape
                    of_new, inf_new = w_new.shape
                    # 输出特征应相同；若不同，跳过
                    if of_old == of_new:
                        if inf_old < inf_new:
                            pad_cols = inf_new - inf_old
                            pad = torch.zeros(of_old, pad_cols, dtype=w_old.dtype)
                            v = torch.cat([w_old, pad], dim=1)
                            sd[k] = v
                            adapted += 1
                        elif inf_old > inf_new:
                            sd[k] = w_old[:, :inf_new]
                            adapted += 1
        model.load_state_dict(sd, strict=False)
        print(f"Loaded checkpoint: {ckpt_path} (emb adapted: {adapted})")

    if args.ckpt and os.path.exists(args.ckpt):
        _load_ckpt_with_emb_adapt(model, args.ckpt)
    else:
        # 尝试在 ckpt_dir 中自动寻找最新权重
        try:
            if os.path.isdir(args.ckpt_dir):
                cand = []
                for fn in os.listdir(args.ckpt_dir):
                    if fn.startswith('ddpm_epoch_') and fn.endswith('.pt'):
                        try:
                            num = int(fn.split('ddpm_epoch_')[-1].split('.pt')[0])
                        except Exception:
                            num = -1
                        cand.append((num, os.path.join(args.ckpt_dir, fn)))
                if cand:
                    cand.sort(key=lambda x: x[0])
                    latest_path = cand[-1][1]
                    _load_ckpt_with_emb_adapt(model, latest_path)
                else:
                    print('[warn] 未在 ckpt_dir 找到形如 ddpm_epoch_*.pt 的文件，将使用随机初始化模型采样。')
            else:
                print('[warn] 未提供 --ckpt 且 ckpt_dir 非目录，将使用随机初始化模型采样。')
        except Exception as e:
            print(f"[warn] 自动查找权重失败：{e}，将使用随机初始化模型采样。")

    with torch.no_grad():
        y = torch.randint(0, max(1, int(args.num_classes)), (args.n_samples,), device=device) if args.conditional else None
        x_gen = diffusion.sample(n=args.n_samples, channels=C, length=T, y=y, n_steps=args.sample_steps, smooth_every=args.smooth_every)

    os.makedirs(args.out_dir, exist_ok=True)
    out_path = os.path.join(args.out_dir, args.save_name)
    np.save(out_path, x_gen.cpu().numpy())
    print(f"Samples saved to: {out_path}, shape={x_gen.shape}")


def _max_lag_corr_1d(x: np.ndarray, y: np.ndarray, max_lag: int = 128) -> Tuple[float, int]:
    x = (x - x.mean()) / (x.std() + 1e-8)
    y = (y - y.mean()) / (y.std() + 1e-8)
    c = np.correlate(x, y, mode='full')
    lags = np.arange(-len(x) + 1, len(x))
    sel = (lags >= -max_lag) & (lags <= max_lag)
    c_sel = c[sel]; l_sel = lags[sel]
    idx = int(np.argmax(np.abs(c_sel)))
    return float(c_sel[idx] / (len(x) + 1e-8)), int(l_sel[idx])


def _psd_js_np(x: np.ndarray, y: np.ndarray) -> float:
    X = np.fft.rfft(x); Y = np.fft.rfft(y)
    P = np.abs(X)**2; Q = np.abs(Y)**2
    P = P / (P.sum() + 1e-12); Q = Q / (Q.sum() + 1e-12)
    M = 0.5 * (P + Q)
    def _kl(A, B):
        A = np.clip(A, 1e-12, 1.0); B = np.clip(B, 1e-12, 1.0)
        return float(np.sum(A * (np.log(A) - np.log(B))))
    return 0.5 * _kl(P, M) + 0.5 * _kl(Q, M)


@torch.no_grad()
def sample_like_test_and_eval(args):
    """按测试集标签采样，1:1 与测试窗口对齐评估并可视化。"""
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    dataset_root = resolve_dataset_root(args)
    test_ds = EEGNPYDataset(dataset_dir=dataset_root, split='test', window_size=args.window_size, step=args.step, include_tail=args.include_tail)
    C, T = test_ds.n_channels, test_ds.n_times

    # 取前 K 个测试样本及其标签
    K = min(args.eval_first_k, len(test_ds))
    xs = []
    ys = []
    for i in range(K):
        x_i, y_i = test_ds[i]
        xs.append(x_i.unsqueeze(0))
        ys.append(y_i)
    x_test = torch.cat(xs, dim=0).to(device)  # [K, C, T]
    y_test = torch.tensor(ys, dtype=torch.long, device=device) if args.conditional else None

    model = UNet1D(in_channels=C, base=args.base, t_dim=args.time_dim, num_classes=(args.num_classes if args.conditional else 0), cond_embed_dim=args.cond_embed_dim).to(device)
    diffusion = Diffusion1D(model, n_steps=args.n_steps, device=device,
                            cfg_drop_prob=(args.cfg_drop_prob if args.conditional else 0.0),
                            guidance_scale=(args.guidance_scale if args.conditional else 0.0))

    if args.ckpt and os.path.exists(args.ckpt):
        state = torch.load(args.ckpt, map_location=device)
        model.load_state_dict(state['model'])
        print(f"Loaded checkpoint: {args.ckpt}")
    else:
        print('[warn] 未提供 --ckpt，将以随机初始化模型采样（仅调通流程）。')

    # 采样与标准化
    x_gen = diffusion.sample(n=K, channels=C, length=T, y=y_test, n_steps=args.sample_steps, smooth_every=args.smooth_every)

    xg = x_gen.detach().cpu().numpy()
    xt = x_test.detach().cpu().numpy()

    # 逐样本逐通道评估
    corr_list, js_list = [], []
    for i in range(K):
        cc_c, js_c = [], []
        for ch in range(C):
            cc, _ = _max_lag_corr_1d(xt[i, ch], xg[i, ch], max_lag=128)
            js = _psd_js_np(xt[i, ch], xg[i, ch])
            cc_c.append(cc); js_c.append(js)
        corr_list.append(np.mean(cc_c)); js_list.append(np.mean(js_c))
    print(f"[Eval] mean max-lag corr over {K} samples: {np.mean(corr_list):.4f}")
    print(f"[Eval] mean PSD-JS over {K} samples: {np.mean(js_list):.4f}")

    # 可视化前若指定索引
    if args.viz_idx >= 0 and args.viz_idx < K:
        idx = args.viz_idx
        ch = args.viz_channel
        import matplotlib.pyplot as plt
        t_axis = np.arange(T)
        plt.figure(figsize=(10, 3))
        plt.plot(t_axis, xt[idx, ch], 'k', label='real')
        plt.plot(t_axis, xg[idx, ch], 'r', alpha=0.8, label='gen')
        plt.title(f'sample #{idx}, ch {ch}')
        plt.legend(); plt.tight_layout()
        os.makedirs(args.out_dir, exist_ok=True)
        fig_path = os.path.join(args.out_dir, f'eval_overlay_idx{idx}_ch{ch}.png')
        plt.savefig(fig_path)
        print(f"Saved overlay figure to: {fig_path}")

    # 可选：重建完整 trial（按滑窗反标准化并重叠相加）
    if getattr(args, 'recon_trial_idx', -1) >= 0:
        recon_trial_idx = int(args.recon_trial_idx)
        test_ds2 = EEGNPYDataset(dataset_dir=dataset_root, split='test', window_size=args.window_size, step=args.step, include_tail=args.include_tail)
        if recon_trial_idx >= len(test_ds2.sel_trials):
            print(f"[recon] trial_idx {recon_trial_idx} 超出范围，跳过重建。")
        else:
            win_ids = test_ds2.get_trial_window_indices(recon_trial_idx)
            spans = test_ds2.get_window_spans(win_ids)
            n_win = len(win_ids)
            C = test_ds2.n_channels; T = test_ds2.n_times
            if n_win == 0:
                print(f"[recon] trial_idx {recon_trial_idx} 无窗口，跳过重建。")
            else:
                y_trial = None
                if args.conditional:
                    y_val = int(test_ds2.trial_labels[recon_trial_idx])
                    y_trial = torch.full((n_win,), y_val, dtype=torch.long, device=device)
                x_gen_win = diffusion.sample(n=n_win, channels=C, length=args.window_size, y=y_trial, n_steps=args.sample_steps, smooth_every=args.smooth_every)
                x_gen_win = x_gen_win.detach().cpu().numpy()
                mean = test_ds2.trial_mean[recon_trial_idx]
                std = test_ds2.trial_std[recon_trial_idx]
                recon = np.zeros((C, T), dtype=np.float32)
                weight = np.zeros((C, T), dtype=np.float32)
                hann = np.hanning(args.window_size).astype(np.float32)
                hann[hann == 0] = 1e-6
                for k, (ti, s, e) in enumerate(spans):
                    seg_len = e - s
                    win = x_gen_win[k, :, :seg_len] * std + mean
                    w = hann[:seg_len][None, :]
                    recon[:, s:e] += win * w
                    weight[:, s:e] += w
                weight[weight == 0] = 1.0
                recon = recon / weight
                os.makedirs(args.out_dir, exist_ok=True)
                recon_path = os.path.join(args.out_dir, args.recon_save_name.format(idx=recon_trial_idx))
                np.save(recon_path, recon)
                print(f"[recon] saved: {recon_path}, shape={recon.shape}")
                if getattr(args, 'recon_plot', 0):
                    ch = int(args.viz_channel)
                    t_axis = np.arange(T)
                    plt.figure(figsize=(10,3))
                    plt.plot(t_axis, test_ds2.trial_data[recon_trial_idx, ch], 'k', label='real')
                    plt.plot(t_axis, recon[ch], 'r', alpha=0.8, label='recon')
                    plt.title(f'recon trial #{recon_trial_idx}, ch {ch}')
                    plt.legend(); plt.tight_layout()
                    fig2 = os.path.join(args.out_dir, f'recon_trial{recon_trial_idx}_ch{ch}.png')
                    plt.savefig(fig2)
                    print(f"[recon] fig saved: {fig2}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['train', 'sample', 'train_and_sample', 'evaluate'], default='evaluate', help='运行模式')
    parser.add_argument('--dataset_key', type=str, default='bci2a', choices=['bci2a', 'bci2a_fixed', 'bci2a_fixed_4sec', 'bci2b', 'seed'])
    parser.add_argument('--results_root', type=str, default='', help='自定义数据根路径（留空则使用默认 processed/<DATASET>）')
    # 与其它基线保持一致，仅暴露 --subject
    parser.add_argument('--subject', type=str, default='A01E', help='仅使用单被试/会话（如 A01E/A01T、B0102T 等）')
    parser.add_argument('--window_size', type=int, default=750)
    parser.add_argument('--step', type=int, default=100)  # 修改默认步长避免内存问题
    parser.add_argument('--include_tail', action='store_true')
    parser.add_argument('--no_sliding', action='store_true', help='启用非滑窗模式：每个 trial 作为单段样本')

    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--epochs', type=int, default=300)
    parser.add_argument('--n_steps', type=int, default=1000)
    parser.add_argument('--lr', type=float, default=2e-4)
    parser.add_argument('--base', type=int, default=64)
    parser.add_argument('--time_dim', type=int, default=128)
    parser.add_argument('--conditional', action='store_true')
    parser.add_argument('--num_classes', type=int, default=4)
    parser.add_argument('--cond_embed_dim', type=int, default=32)
    # CFG 超参数
    parser.add_argument('--cfg_drop_prob', type=float, default=0.1, help='训练时丢弃条件概率')
    parser.add_argument('--guidance_scale', type=float, default=1.5, help='采样时指导强度，0 关闭 CFG')
    # 频域/平滑相关
    parser.add_argument('--fs', type=float, default=250.0)
    parser.add_argument('--lambda_psd', type=float, default=0.03)
    parser.add_argument('--lambda_x_psd', type=float, default=0.04)
    parser.add_argument('--lambda_tv', type=float, default=0.005)
    parser.add_argument('--smooth_every', type=int, default=10)

    parser.add_argument('--save_every', type=int, default=10)
    parser.add_argument('--ckpt_dir', type=str, default='./checkpoints_ddpm')

    parser.add_argument('--n_samples', type=int, default=16)
    parser.add_argument('--sample_steps', type=int, default=500)
    parser.add_argument('--ckpt', type=str, default='./checkpoints_ddpm/ddpm_epoch_300.pt')
    parser.add_argument('--out_dir', type=str, default='./results/ddpm_samples')
    parser.add_argument('--save_name', type=str, default='ddpm_samples.npy')
    # 评估
    parser.add_argument('--eval_samples', type=int, default=512)
    parser.add_argument('--eval_save_dir', type=str, default='./results/ddpm_eval')
    parser.add_argument('--no_save_gen', action='store_true')
    parser.add_argument('--skip_cfid', action='store_true')
    parser.add_argument('--cfid_iters', type=int, default=200)
    parser.add_argument('--cfid_max_samples', type=int, default=1024)
    parser.add_argument('--cfid_batch_size', type=int, default=64)
    parser.add_argument('--cfid_max_train_len', type=int, default=3000)
    parser.add_argument('--eval_disc_pred', action='store_true')
    # 分类效用与可视化（与其它基线一致）
    parser.add_argument('--eval_cls_utility', action='store_true', help='评估分类效用（条件模型需提供标签）')
    parser.add_argument('--cls_epochs', type=int, default=3, help='分类器训练轮数（加速考虑）')
    parser.add_argument('--cls_lr', type=float, default=1e-3, help='分类器学习率')
    parser.add_argument('--cls_model', type=str, default='eegnet', choices=['eegnet','simple'], help='分类器架构')
    parser.add_argument('--viz_confmat', action='store_true', help='保存分类混淆矩阵图')
    parser.add_argument('--viz_psd', action='store_true')
    parser.add_argument('--viz_tsne', action='store_true')
    parser.add_argument('--viz_erd', action='store_true')
    parser.add_argument('--erd_band', type=str, default='mu', choices=['delta','theta','alpha','beta','mu'])
    parser.add_argument('--viz_wave', action='store_true')
    parser.add_argument('--viz_wave_channel', type=int, default=0)
    parser.add_argument('--viz_wave_n', type=int, default=4)
    parser.add_argument('--viz_wave_t_start', type=int, default=0)
    parser.add_argument('--viz_wave_t_stop', type=int, default=0)
    # 按测试标签对齐评估
    parser.add_argument('--eval_first_k', type=int, default=16)
    parser.add_argument('--viz_idx', type=int, default=0)
    parser.add_argument('--viz_channel', type=int, default=0)
    # 重建完整 trial 选项
    parser.add_argument('--recon_trial_idx', type=int, default=-1, help='>=0 则对该测试 trial 做重建')
    parser.add_argument('--recon_save_name', type=str, default='recon_trial_{idx}.npy')
    parser.add_argument('--recon_plot', type=int, default=1)

    args = parser.parse_args()

    if args.mode in ['train', 'train_and_sample']:
        model = train(args)
        if args.mode == 'train_and_sample':
            args.ckpt = ''
            sample(args)
    elif args.mode == 'sample':
        # 与其它基线保持一致：sample 只保存样本，不做额外评估/复原
        sample(args)
    elif args.mode == 'evaluate':
        evaluate(args)

if __name__ == '__main__':
    main()

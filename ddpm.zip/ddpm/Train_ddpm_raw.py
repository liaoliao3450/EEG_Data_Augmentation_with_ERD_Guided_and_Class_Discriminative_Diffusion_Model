"""
---
title: A minimum implementation for DS_DDPM for start over with code comments
---
"""

from typing import List

import torch.utils.data
import os
import matplotlib.pyplot as plt
os.environ["GIT_PYTHON_REFRESH"] = "quiet"
from labml import lab, tracker, experiment, monit
from labml.configs import BaseConfigs, option
from labml_helpers.device import DeviceConfigs
from core.utils.EEGNet import EEG_Net_8_Stack
from core.utils.unet_eeg_subject_emb import sub_gaussion
from core.utils.unet_eeg import UNet
from typing import Tuple, Optional

import torch
import torch.nn.functional as F
import torch.utils.data
from torch import nn
from core.utils.utils import gather
import numpy as np
import math

def normalize_to_neg_one_to_one(x):
    return x * 2 - 1

def unnormalize_to_zero_to_one(x):
    return (x + 1) * 0.5
class DatasetLoader_BCI_IV_signle(torch.utils.data.Dataset):

    def __init__(self, setname, datafolder=None, train_aug=False, subject_id=1):

        subject_id = subject_id

        train_X = np.load(f'E:\eeg\DeepSeparator\diffusion_doc\data\original_data_{subject_id}.npy')
        train_y = np.load(f'E:\eeg\DeepSeparator\diffusion_doc\data\original_labels_{subject_id}.npy')

        test_X = np.load(f'E:\eeg\DeepSeparator\diffusion_doc\data\E_original_data_{subject_id}.npy')
        test_y = np.load(f'E:\eeg\DeepSeparator\diffusion_doc\data\E_original_labels_{subject_id}.npy')

        train_y -= 1
        test_y -= 1
        window_size = 224
        step = 75  # 这里必须保证产出的tensor 是偶数，这里是超大overlap（重叠）的形式
        # window_size = 400
        # step = 50 # 这里必须保证产出的tensor 是偶数，这里是超大overlap的形式
        n_channel = 22

        def windows(data, size, step):
            # 生成滑动窗口的起始和结束索引。
            start = 0
            while (start + size) < data.shape[0]:
                yield int(start), int(start + size)
                start += step

        def segment_signal_without_transition(data, window_size, step):
            # 将单个时间序列分割为多个完整窗口段。
            segments = []
            for (start, end) in windows(data, window_size, step):
                if len(data[start:end]) == window_size:
                    segments = segments + [data[start:end]]
            return np.array(segments)

        def segment_dataset(X, window_size, step):
            # 对整个数据集中的每个样本进行窗口分割。
            win_x = []
            for i in range(X.shape[0]):
                win_x = win_x + [segment_signal_without_transition(X[i], window_size, step)]
            win_x = np.array(win_x)
            return win_x

        train_raw_x = np.transpose(train_X, [0, 2, 1])
        test_raw_x = np.transpose(test_X, [0, 2, 1])

        train_win_x = segment_dataset(train_raw_x, window_size, step)
        test_win_x = segment_dataset(test_raw_x, window_size, step)
        train_win_y = train_y
        test_win_y = test_y

        expand_factor = train_win_x.shape[1]

        train_x = np.reshape(train_win_x, (-1, train_win_x.shape[2], train_win_x.shape[3]))
        test_x = np.reshape(test_win_x, (-1, test_win_x.shape[2], test_win_x.shape[3]))
        train_y = np.repeat(train_y, expand_factor)
        test_y = np.repeat(test_y, expand_factor)

        train_x = np.reshape(train_x, [train_x.shape[0], 1, train_x.shape[1], train_x.shape[2]]).astype('float32')
        train_y = np.reshape(train_y, [train_y.shape[0]]).astype('float32')

        test_x = np.reshape(test_x, [test_x.shape[0], 1, test_x.shape[1], test_x.shape[2]]).astype('float32')
        test_y = np.reshape(test_y, [test_y.shape[0]]).astype('float32')

        train_win_x = train_win_x.astype('float32')

        ratio = 0.5
        idx = list(range(len(test_win_y)))
        np.random.shuffle(idx)
        test_win_x = test_win_x[idx]
        test_win_y = test_win_y[idx]

        val_win_x = test_win_x[:int(len(test_win_x) * 0.5), :, :, :].astype('float32')
        val_win_y = test_win_y[:int(len(test_win_x) * 0.5)]

        real_test_win_x = test_win_x[int(len(test_win_x) * 0.5):, :, :, :].astype('float32')
        real_test_win_y = test_win_y[int(len(test_win_x) * 0.5):]

        self.X_val = val_win_x
        self.y_val = val_win_y

        print("The shape of sample x0 is {}".format(test_win_x.shape))

        if setname == 'train':
            self.data = train_win_x
            self.label = train_win_y
        elif setname == 'val':
            self.data = val_win_x
            self.label = val_win_y
        elif setname == 'test':
            self.data = real_test_win_x
            self.label = real_test_win_y

        self.num_class = 4

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        data, label = self.data[i], self.label[i]
        # data, label = F.normalize(torch.Tensor(self.data[i]), p=2, dim=2), self.label[i]
        return data, label


class DenoiseDiffusion:
    """
    ## Denoise Diffusion
    """

    def __init__(self, eps_model: nn.Module, n_steps: int, device: torch.device,  debug=False, time_diff_constraint=True):
        """
        * `eps_model` is $\textcolor{lightgreen}{\epsilon_\theta}(x_t, t)$ model
        * `n_steps` is $t$
        * `device` is the device to place constants on
        """
        super().__init__()
        self.eps_model = eps_model


        # Create $\beta_1, \dots, \beta_T$ linearly increasing variance schedule
        self.beta = torch.linspace(0.0001, 0.02, n_steps).to(device)

        # $\alpha_t = 1 - \beta_t$
        self.alpha = 1. - self.beta
        # $\bar\alpha_t = \prod_{s=1}^t \alpha_s$
        self.alpha_bar = torch.cumprod(self.alpha, dim=0)
        # $T$
        self.n_steps = n_steps
        # $\sigma^2 = \beta$
        self.sigma2 = self.beta
        self.debug = debug
        self.step_size = 75
        self.window_size = 224
        self.scale = 1.0
        # self.step_size = 93.5
        # self.window_size = 93.5
        # self.arcmargin = ArcMarginProduct()

    def q_xt_x0(self, x0: torch.Tensor, t: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        #### Get $q(x_t|x_0)$ distribution

        \begin{align}
        q(x_t|x_0) &= \mathcal{N} \Big(x_t; \sqrt{\bar\alpha_t} x_0, (1-\bar\alpha_t) \mathbf{I} \Big)
        \end{align}
        """

        # [gather](utils.html) $\alpha_t$ and compute $\sqrt{\bar\alpha_t} x_0$
        if self.debug:
            print("the selected alpha bar would be {}".format(gather(self.alpha_bar, t).shape))
        mean = gather(self.alpha_bar, t) ** 0.5 * x0
        # $(1-\bar\alpha_t) \mathbf{I}$
        var = 1 - gather(self.alpha_bar, t)
        #
        return mean, var

    def q_sample(self, x0: torch.Tensor, t: torch.Tensor, eps: Optional[torch.Tensor] = None):
        """
        #### Sample from $q(x_t|x_0)$

        \begin{align}
        q(x_t|x_0) &= \mathcal{N} \Big(x_t; \sqrt{\bar\alpha_t} x_0, (1-\bar\alpha_t) \mathbf{I} \Big)
        \end{align}
        """

        # $\epsilon \sim \mathcal{N}(\mathbf{0}, \mathbf{I})$
        if eps is None:
            eps = torch.randn_like(x0)

        # get $q(x_t|x_0)$
        x_0 = x0 * self.scale

        mean, var = self.q_xt_x0(x_0, t)
        x = mean + (var ** 0.5) * eps
        x = torch.clamp(x, min=-1.1 * self.scale, max=1.1 * self.scale)

        x = x / self.scale

        # Sample from $q(x_t|x_0)$
        return x

    def p_sample(self, xt: torch.Tensor, t: torch.Tensor, eps_theta: torch.Tensor):
        """
        #### Sample from $\textcolor{lightgreen}{p_\theta}(x_{t-1}|x_t)$
         计算 x（t−1∣xt）
        \begin{align}
        \textcolor{lightgreen}{p_\theta}(x_{t-1} | x_t) &= \mathcal{N}\big(x_{t-1};
        \textcolor{lightgreen}{\mu_\theta}(x_t, t), \sigma_t^2 \mathbf{I} \big) \\
        \textcolor{lightgreen}{\mu_\theta}(x_t, t)
          &= \frac{1}{\sqrt{\alpha_t}} \Big(x_t -
            \frac{\beta_t}{\sqrt{1-\bar\alpha_t}}\textcolor{lightgreen}{\epsilon_\theta}(x_t, t) \Big)
        \end{align}
        """
        # [gather](utils.html) $\bar\alpha_t$
        alpha_bar = gather(self.alpha_bar, t)
        # $\alpha_t$
        alpha = gather(self.alpha, t)
        # $\frac{\beta}{\sqrt{1-\bar\alpha_t}}$
        eps_coef = (1 - alpha) / (1 - alpha_bar) ** .5
        # $$\frac{1}{\sqrt{\alpha_t}} \Big(x_t -
        #      \frac{\beta_t}{\sqrt{1-\bar\alpha_t}}\textcolor{lightgreen}{\epsilon_\theta}(x_t, t) \Big)$$
        mean = 1 / (alpha ** 0.5) * (xt - eps_coef * eps_theta)
        # $\sigma^2$
        var = gather(self.sigma2, t)

        # $\epsilon \sim \mathcal{N}(\mathbf{0}, \mathbf{I})$
        eps = torch.randn(xt.shape, device=xt.device)
        # Sample
        return mean + (var ** .5) * eps

    def p_x0(self, xt: torch.Tensor, t: torch.Tensor, eps: torch.Tensor):
        """
        #### Estimate $x_0$  估算x_0

        $$x_0 \approx \hat{x}_0 = \frac{1}{\sqrt{\bar\alpha}}
         \Big( x_t - \sqrt{1 - \bar\alpha_t} \textcolor{lightgreen}{\epsilon_\theta}(x_t, t) \Big)$$
        """
        # [gather](utils.html) $\bar\alpha_t$
        alpha_bar = gather(self.alpha_bar, t)

        # $$x_0 \approx \hat{x}_0 = \frac{1}{\sqrt{\bar\alpha}}
        #  \Big( x_t - \sqrt{1 - \bar\alpha_t} \textcolor{lightgreen}{\epsilon_\theta}(x_t, t) \Big)$$
        return (xt - (1 - alpha_bar) ** 0.5 * eps) / (alpha_bar ** 0.5)

    def loss(self, x0: torch.Tensor,label: torch.Tensor, noise: Optional[torch.Tensor] = None,debug=False):
        """
        #### Simplified Loss

        $$L_simple(\theta) = \mathbb{E}_{t,x_0, \epsilon} \Bigg[ \bigg\Vert
        \epsilon - \textcolor{lightgreen}{\epsilon_\theta}(\sqrt{\bar\alpha_t} x_0 + \sqrt{1-\bar\alpha_t}\epsilon, t)
        \bigg\Vert^2 \Bigg]$$
        """
        # Get batch size
        batch_size = x0.shape[0]
        # Get random $t$ for each sample in the batch

        t = torch.randint(0, self.n_steps, (batch_size,), device=x0.device, dtype=torch.long)
        s = label
        # $\epsilon \sim \mathcal{N}(\mathbf{0}, \mathbf{I})$
        if noise is None:
            noise = torch.randn_like(x0)

        # Sample $x_t$ for $q(x_t|x_0)$
        xt = self.q_sample(x0, t, eps=noise)
        # Get $\textcolor{lightgreen}{\epsilon_\theta}(\sqrt{\bar\alpha_t} x_0 + \sqrt{1-\bar\alpha_t}\epsilon, t)$
        eps_theta = self.eps_model(xt, t)

        # MSE loss
        return F.mse_loss(noise, eps_theta)

    def loss_with_diff_constraint(self, x0: torch.Tensor, label: torch.Tensor,
                                  noise: Optional[torch.Tensor] = None, debug=False,
                                  noise_content_kl_co=1, arc_subject_co=0.1, orgth_co=2):
        """
        #### Simplified Loss

        $$L_simple(\theta) = \mathbb{E}_{t,x_0, \epsilon} \Bigg[ \bigg\Vert
        \epsilon - \textcolor{lightgreen}{\epsilon_\theta}(\sqrt{\bar\alpha_t} x_0 + \sqrt{1-\bar\alpha_t}\epsilon, t)
        \bigg\Vert^2 \Bigg]$$
        """
        # Get batch size
        debug = self.debug
        batch_size = x0.shape[0]
        # Get random $t$ for each sample in the batch

        t = torch.randint(0, self.n_steps, (batch_size,), device=x0.device, dtype=torch.long)
        # s = torch.randint(0, self.subject_noise_range, (batch_size,), device=x0.device, dtype=torch.long)
        s = label

        # $\epsilon \sim \mathcal{N}(\mathbf{0}, \mathbf{I})$
        if noise is None:
            noise = torch.randn_like(x0)

        # Sample $x_t$ for $q(x_t|x_0)$
        xt = self.q_sample(x0, t, eps=noise)

        # Get $\textcolor{lightgreen}{\epsilon_\theta}(\sqrt{\bar\alpha_t} x_0 + \sqrt{1-\bar\alpha_t}\epsilon, t)$
        eps_theta = self.eps_model(xt, t)
        subject_mu, subject_theta = self.sub_theta(xt, t, s)
        # print(subject_theta.shape)

        constraint_panelty = 0

        # eps_layernorm = F.layer_norm(eps_theta, [eps_theta.shape[1], eps_theta.shape[2], eps_theta.shape[3]])
        for i in range(eps_theta.shape[3] - 1):
            # i * self.step_size, i * self.step_size + self.window_size
            # (i + 1) * self.step_size,  (i + 1) * self.step_size + self.window_size
            if debug:
                print("logging with constraint panelty value")
                # print(F.mse_loss(eps_layernorm[:, :, (i + 1) * self.step_size : i * self.step_size + self.window_size, i], eps_layernorm[:, :, (i + 1) * self.step_size : i * self.step_size + self.window_size, i + 1], reduction='none').shape)
                # print(F.mse_loss(eps_layernorm[:, :, self.step_size:, i], eps_layernorm[:, :, :-self.step_size, i + 1], reduction='none').shape)
                # print(F.mse_loss(eps_layernorm[:, :, self.step_size:, i], eps_layernorm[:, :, :-self.step_size, i + 1], reduction='mean'))
                print(F.mse_loss(eps_theta[:, :, self.step_size:, i], eps_theta[:, :, :-self.step_size, i + 1],
                                 reduction='mean'))
            # constraint_panelty = constraint_panelty +F.mse_loss(eps_layernorm[:, :, self.step_size:, i], eps_layernorm[:, :, :-self.step_size, i + 1], reduction='mean')
            constraint_panelty = constraint_panelty + F.mse_loss(eps_theta[:, :, self.step_size:, i],
                                                                 eps_theta[:, :, :-self.step_size, i + 1],
                                                                 reduction='mean')
        if debug:
            print("logging with constraint panelty value")
            print(constraint_panelty)

        # MSE loss
        # return F.mse_loss(noise, eps_theta + subject_theta) + constraint_panelty, constraint_panelty
        # noise_conent_kl = F.kl_div(eps_theta.softmax(dim=-1).log(), subject_theta.softmax(dim=-1), reduction='sum')
        noise_conent_kl = F.kl_div(eps_theta.softmax(dim=-1).log(), subject_theta.softmax(dim=-1), reduction='mean')
        organal_squad = torch.bmm(
            eps_theta.view(eps_theta.shape[0] * eps_theta.shape[1], eps_theta.shape[2], eps_theta.shape[3]),
            subject_theta.view(subject_theta.shape[0] * subject_theta.shape[1], subject_theta.shape[2],
                               subject_theta.shape[3]).permute(0, 2, 1))
        if debug:
            print("logging with organal_squad")
            print(organal_squad.shape)
        ones = torch.ones(eps_theta.shape[0] * eps_theta.shape[1], eps_theta.shape[2], eps_theta.shape[2],
                          dtype=torch.float32, device='cuda')  # (N * C) * H * H
        diag = torch.eye(eps_theta.shape[2], dtype=torch.float32, device='cuda')  # (N * C) * H * H
        loss_orth = ((organal_squad * (ones - diag).to('cuda')) ** 2).mean()
        if debug:
            print("logging with loss_orth")
            print(loss_orth)
        subject_arc_logit = self.sub_arc_head(subject_theta.permute(0, 3, 2, 1), s)
        subject_arc_loss = F.cross_entropy(subject_arc_logit, s.long())
        # return F.mse_loss(noise, eps_theta + subject_theta) + 0.01 * 1/noise_conent_kl, constraint_panelty, noise_conent_kl
        # return F.mse_loss(noise, eps_theta + subject_theta) - noise_content_kl_co * noise_conent_kl + arc_subject_co *subject_arc_loss, constraint_panelty, noise_content_kl_co * noise_conent_kl, arc_subject_co *subject_arc_loss
        if self.time_diff_constraint:
            return F.mse_loss(noise,
                              eps_theta + subject_theta) + orgth_co * loss_orth + arc_subject_co * subject_arc_loss + 0.1 * constraint_panelty, constraint_panelty, noise_content_kl_co * noise_conent_kl, arc_subject_co * subject_arc_loss, orgth_co * loss_orth
        else:
            return F.mse_loss(noise,
                              eps_theta + subject_theta) + orgth_co * loss_orth + arc_subject_co * subject_arc_loss, constraint_panelty, noise_content_kl_co * noise_conent_kl, arc_subject_co * subject_arc_loss, orgth_co * loss_orth


class Configs(BaseConfigs):
    """
    ## Configurations
    """
    device: torch.device = DeviceConfigs()

    # U-Net model for $\textcolor{lightgreen}{\epsilon_\theta}(x_t, t)$
    eps_model: UNet
    # [DDPM algorithm](index.html)
    diffusion: DenoiseDiffusion

    # Number of channels in the image. $3$ for RGB.
    eeg_channels: int = 22
    # Image size
    # image_size: int = 32
    window_size: int = 224
    # window_size: int = 400
    stack_size: int = 8
    # Number of channels in the initial feature map
    n_channels: int = 64
    # The list of channel numbers at each resolution.
    # The number of channels is `channel_multipliers[i] * n_channels`
    channel_multipliers: List[int] = [1, 2, 2, 4]
    # The list of booleans that indicate whether to use attention at each resolution
    is_attention: List[int] = [False, False, False, True]

    # Number of time steps $T$
    n_steps: int = 1_000
    # Batch size
    # batch_size: int = 64
    batch_size: int = 8
    # Number of samples to generate
    n_samples: int = 8
    # Learning rate
    learning_rate: float = 0.2e-4

    loss_history = []

    # Number of training epochs
    epochs: int = 1_000

    # Dataset
    dataset: torch.utils.data.Dataset
    # Dataloader
    data_loader: torch.utils.data.DataLoader

    # Adam optimizer
    optimizer: torch.optim.Adam

    current_label: Optional[torch.Tensor]   # 添加这一行
    def init(self):
        # Create $\textcolor{lightgreen}{\epsilon_\theta}(x_t, t)$ model
        self.eps_model = UNet(
            eeg_channels=self.eeg_channels,
            n_channels=self.n_channels,
            ch_mults=self.channel_multipliers,
            is_attn=self.is_attention,
        ).to(self.device)

             # Create [DDPM class](index.html)
        self.diffusion = DenoiseDiffusion(
            eps_model=self.eps_model,
            n_steps=self.n_steps,
            device=self.device,
            debug=False,
        )

        # Create dataloader
        self.data_loader = torch.utils.data.DataLoader(self.dataset, self.batch_size, shuffle=True, pin_memory=True)
        # Create optimizer
        self.optimizer = torch.optim.Adam([
            {'params': self.eps_model.parameters(), 'lr': self.learning_rate}], lr=self.learning_rate)

    def sample(self,label):
        """
        ### Sample images
        """
        with torch.no_grad():
            # $x_T \sim p(x_T) = \mathcal{N}(x_T; \mathbf{0}, \mathbf{I})$
            xt = torch.randn([self.n_samples, self.eeg_channels, self.window_size, self.stack_size],
                            device=self.device)
            s = torch.tensor(label, dtype=torch.long, device=self.device)
            # Remove noise for $T$ steps
            for t_inv in monit.iterate('Sample', self.n_steps):
                # $t$
                t_ = self.n_steps - t_inv - 1
                t = xt.new_full((1,), t_, dtype=torch.long)
                # Sample from $\textcolor{lightgreen}{p_\theta}(x_{t-1}|x_t)$
                # x = self.diffusion.p_sample_noise(x, x.new_full((self.n_samples,), t, dtype=torch.long))
                # xt_noise = F.normalize(xt_noise, p=2, dim=2)
                # xt = F.normalize(self.p_sample(xt, t, eps_theta) + xt_noise, p=2, dim=2)
                eps_theta = self.eps_model(xt, t)

                x0 = self.diffusion.p_x0(xt, t, eps_theta)


                x0 = x0.detach().cpu().numpy()
                x0_noise = x0_noise.detach().cpu().numpy()


                # xt_noise = F.normalize(xt_noise, p=2, dim=2)  # ===
                xt = F.normalize(self.diffusion.p_sample(xt, t, eps_theta) + xt_noise, p=2, dim=2)  # ===
                xt = self.diffusion.p_sample(xt, t, eps_theta)

                # xt = F.unnormalize(xt, p=2, dim=2)
            return x0

    def plot_loss(self):
        """Plot training loss over iterations."""
        plt.figure(figsize=(12, 6))
        plt.plot(self.loss_history, label='Batch Loss')
        plt.xlabel('Iteration')
        plt.ylabel('Loss')
        plt.title('Training Loss Curve')
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.savefig('training_loss_curve.png')  # Save the figure
        plt.show()

    def train(self):
        """
        ### Train
        """
        # Iterate through the dataset
        # orinial_data = self.data_loader.dataset.data

        for data, label in monit.iterate('Train', self.data_loader):
            # Increment global step
        # for data, label in enumerate(self.data_loader):
            tracker.add_global_step()
            # Move data to device
            data = torch.permute(data, (0, 3, 2, 1))
            data = F.normalize(data, p=2, dim=2)
            data = data.to(self.device)
            label = label.float().to(self.device)
            self.optimizer.zero_grad()
            # Calculate loss
            loss = self.diffusion.loss(data,label)
            # loss, time_period_diff, noise_conent_kl, sub_arc_loss, loss_orth = self.diffusion.loss_with_diff_constraint(
            #     data, label)
            # return F.mse_loss(noise, eps_theta + subject_theta) + orgth_co * loss_orth + arc_subject_co *subject_arc_loss, constraint_panelty, noise_content_kl_co * noise_conent_kl, arc_subject_co *subject_arc_loss, orgth_co * loss_orth
            # Make the gradients zero
            # self.optimizer.zero_grad()
            # Compute gradients
            loss.backward()
            # Take an optimization step
            self.optimizer.step()
            # self.optimizer_noise.step()
            self.loss_history.append(loss.item())
        print(loss)

    def run(self):
        """
        ### Training loop
        """
        loss_history = []
        for inicator in monit.loop(self.epochs):
        # for inicator in range(self.epochs):
            # Train the model

            print(inicator)
            self.train()
            # Sample some images
            # self.sample()
            # New line in the console
            tracker.new_line()
            # Save the model
            if inicator % 30 == 0:
                experiment.save_checkpoint()
        self.plot_loss()

        # run_uuid = "360587e650db11f0872b04d9f5d2b66c"
        # experiment.evaluate()
        # configs = Configs()
        # configs_dict = experiment.load_configs(run_uuid)
        # experiment.configs(configs, configs_dict)
        # configs.init()
        #
        # experiment.add_pytorch_models({
        #     'eps_model': configs.eps_model,
        #     'subject_theta': configs.sub_theta
        # })
        #
        # experiment.load(run_uuid, 8052)
        # configs.window_size = 224
        # configs.stack_size = 8
        # step_size = (750 - configs.window_size) // (configs.stack_size - 1)
        # print(step_size)
        # # label = torch.from_numpy(self.data_loader.dataset.label).to(self.device)
        # label = [0,1,2,3,2,0,1,3]
        # label = torch.tensor(label, dtype=torch.long).to('cuda', non_blocking=True)
        # ddpm_list = []  # 用于收集所有组的数据
        #
        # for group in range(36):
        #     # 生成数据并转换为NumPy数组
        #     generate_data = self.sample(label)
        #
        #     # 获取当前批次大小
        #     batch_size = generate_data.shape[0]
        #
        #     # 创建目标数组（初始化为0）
        #     real_waves = np.zeros((batch_size, 22, 750), dtype=generate_data.dtype)
        #
        #     # 拼接当前组的8个数据块
        #     for i in range(generate_data.shape[3]):  # 假设第4维是8
        #         start = i * step_size
        #         end = start + configs.window_size
        #         real_waves[:, :, start:end] = generate_data[:, :, :, i]
        #
        #     # 将当前组的数据加入列表
        #     ddpm_list.append(real_waves)
        # # 拼接所有组的数据
        # DDPM_DATA = np.concatenate(ddpm_list, axis=0)
        # data_sampled_path = './results'
        # output_path = os.path.join(data_sampled_path, 'ddpm_label_data')
        # if not os.path.exists(output_path):
        #     os.makedirs(output_path)
        #
        # file_path = f"{output_path}/single_subject_data_1.npy"
        # # data_to_save = {
        # #     "real_waves": DDPM_DATA,
        # # }
        # np.save(file_path, DDPM_DATA, allow_pickle=True)
@option(Configs.dataset, 'bci_comp_iv')
def datasetLoader_BCI_IV_signle(c: Configs):
    """
    Create BCI IV dataset
    """
    return DatasetLoader_BCI_IV_signle('train', datafolder='E:\eeg\DeepSeparator\diffusion_doc\data', subject_id=1)


#
if __name__ == '__main__':
    experiment.create(name='7_4_ddpm', writers={'screen', 'comet'})

    # Create configurations 创建配置对象
    configs = Configs()

    # Set configurations. You can override the defaults by passing the values in the dictionary.设置实验配置（覆盖默认参数）
    experiment.configs(configs, {
        'dataset': 'bci_comp_iv',
        'eeg_channels': 22,  # 1,
        'epochs': 1000,  # 5,
    })

    # Initialize 初始化配置（如数据加载、模型参数初始化等）
    configs.init()

    # Set models for saving and loading 注册需要保存/加载的PyTorch模型
    experiment.add_pytorch_models({'eps_model': configs.eps_model})
    # experiment.add_pytorch_models({'subject_theta': configs.sub_theta})
    # Start and run the training loop 启动实验并运行训练流程
    with experiment.start():
        configs.run()
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

# 简单 1D U-Net 作为 epsilon_theta 预测器（支持可选类条件）

def sinusoidal_embedding(timesteps: torch.Tensor, dim: int = 128, max_period: int = 10000):
    half = dim // 2
    device = timesteps.device
    t = timesteps.float()
    freqs = torch.exp(-math.log(max_period) * torch.arange(0, half, device=device).float() / half)
    args = t[:, None] * freqs[None]
    emb = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
    if dim % 2 == 1:
        emb = F.pad(emb, (0,1))
    return emb

class ResBlock(nn.Module):
    def __init__(self, c_in, c_out, t_dim):
        super().__init__()
        self.conv1 = nn.Conv1d(c_in, c_out, 3, padding=1)
        self.conv2 = nn.Conv1d(c_out, c_out, 3, padding=1)
        self.emb = nn.Linear(t_dim, c_out)
        self.skip = nn.Conv1d(c_in, c_out, 1) if c_in != c_out else nn.Identity()
        self.act = nn.SiLU()
        self.norm1 = nn.BatchNorm1d(c_out)
        self.norm2 = nn.BatchNorm1d(c_out)
    def forward(self, x, t_emb):
        h = self.conv1(x)
        h = h + self.emb(t_emb).unsqueeze(-1)
        h = self.norm1(self.act(h))
        h = self.conv2(h)
        h = self.norm2(self.act(h))
        return h + self.skip(x)

class UNet1D(nn.Module):
    def __init__(self, in_channels: int, base: int = 64, t_dim: int = 128, num_classes: int = 0, cond_embed_dim: int = 32):
        super().__init__()
        self.num_classes = int(num_classes)
        self.time_dim = int(t_dim)
        # 若启用条件，使用嵌入将类别索引映射到 time_dim，并与时间嵌入相加
        self.cond_embed_dim = int(cond_embed_dim) if self.num_classes > 0 else 0
        self.class_embed = nn.Embedding(self.num_classes, self.cond_embed_dim) if self.num_classes > 0 else None
        self.class_proj = nn.Linear(self.cond_embed_dim, self.time_dim) if self.num_classes > 0 else None

        self.in_proj = nn.Conv1d(in_channels, base, 1)
        self.down1 = ResBlock(base, base*2, self.time_dim)
        self.down2 = ResBlock(base*2, base*4, self.time_dim)
        self.mid = ResBlock(base*4, base*4, self.time_dim)
        self.up1 = ResBlock(base*4, base*2, self.time_dim)
        self.up2 = ResBlock(base*2, base, self.time_dim)
        self.out = nn.Conv1d(base, in_channels, 1)
        self.pool = nn.AvgPool1d(2)
        self.up = nn.Upsample(scale_factor=2, mode='linear', align_corners=False)

    def _upsample_to(self, x: torch.Tensor, target_len: int) -> torch.Tensor:
        """线性插值到指定长度，避免因奇偶长度导致的形状不匹配。"""
        if x.size(-1) == target_len:
            return x
        return F.interpolate(x, size=target_len, mode='linear', align_corners=False)

    def forward(self, x, t, y=None):
        # 仅时间嵌入，维度恒为 time_dim
        t_emb = sinusoidal_embedding(t, self.time_dim)
        # 条件嵌入：若提供 y（允许部分为 -1 表示无条件），则将索引嵌入映射到 time_dim 并相加
        if self.class_embed is not None and y is not None:
            if not torch.is_tensor(y):
                raise TypeError("y should be a tensor of dtype long with values in [0,num_classes) or -1 for unconditional")
            y = y.long()
            B = y.shape[0]
            mask = y >= 0
            if mask.any():
                y_valid = torch.remainder(y[mask], self.num_classes)
                y_emb = self.class_embed(y_valid)
                y_proj = self.class_proj(y_emb)
                t_emb = t_emb + torch.zeros_like(t_emb)
                t_emb[mask] = t_emb[mask] + y_proj
        x0 = self.in_proj(x)
        d1 = self.down1(x0, t_emb)
        d2 = self.down2(self.pool(d1), t_emb)
        m = self.mid(self.pool(d2), t_emb)
        up_m = self._upsample_to(self.up(m), d2.size(-1))
        u1 = self.up1(up_m + d2, t_emb)
        up_u1 = self._upsample_to(self.up(u1), d1.size(-1))
        u2 = self.up2(up_u1 + d1, t_emb)
        return self.out(u2)

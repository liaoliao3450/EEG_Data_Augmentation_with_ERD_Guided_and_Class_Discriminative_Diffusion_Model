"""
Enhanced ERD Loss with CSP-based Multi-channel Analysis

真正的ERD特征提取：
1. 使用CSP空间滤波器
2. 多通道ERD综合分析
3. 对数方差特征
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from scipy.linalg import eigh


class CSPBasedERDLoss(nn.Module):
    """
    基于CSP的增强ERD损失函数
    
    使用Common Spatial Patterns提取真正的ERD特征，
    而不是简单的C3-C4侧化指数。
    """
    
    def __init__(self, n_channels: int = 22, n_components: int = 6, 
                 fs: int = 250, n_fft: int = 1000):
        """
        Args:
            n_channels: EEG通道数
            n_components: CSP成分数量
            fs: 采样率
            n_fft: FFT点数
        """
        super().__init__()
        self.n_channels = n_channels
        self.n_components = n_components
        self.fs = fs
        self.n_fft = n_fft
        
        # CSP滤波器（每个类别一组）
        self.csp_filters = {}  # {class_id: filters}
        
        # 频率轴
        freqs = torch.fft.rfftfreq(n_fft, 1.0 / fs)
        self.register_buffer('freqs', freqs)
        
        # Alpha频段掩码 (8-13Hz) - μ节律
        alpha_mask = (freqs >= 8) & (freqs <= 13)
        self.register_buffer('alpha_mask', alpha_mask)
        
        # Beta频段掩码 (13-30Hz) - β节律
        beta_mask = (freqs >= 13) & (freqs <= 30)
        self.register_buffer('beta_mask', beta_mask)
    
    def fit_csp_filters(self, X_real: np.ndarray, y_real: np.ndarray):
        """
        从真实数据中学习CSP滤波器
        
        Args:
            X_real: 真实EEG数据 [N, C, T]
            y_real: 标签 [N]
        """
        print("学习CSP滤波器...")
        
        classes = np.unique(y_real)
        
        # 为每个类别学习CSP滤波器 (one-vs-rest)
        for cls in classes:
            # 创建二分类标签
            binary_y = (y_real == cls).astype(int)
            
            if len(np.unique(binary_y)) < 2:
                continue
            
            # 计算两个类别的协方差矩阵
            cov_pos = self._compute_covariance(X_real[binary_y == 1])
            cov_neg = self._compute_covariance(X_real[binary_y == 0])
            
            # 广义特征值分解
            try:
                eigenvalues, eigenvectors = eigh(cov_pos, cov_pos + cov_neg)
                
                # 按特征值排序
                idx = np.argsort(eigenvalues)[::-1]
                eigenvectors = eigenvectors[:, idx]
                
                # 选择最大和最小的特征值对应的特征向量
                n_pairs = self.n_components // 2
                selected_filters = np.concatenate([
                    eigenvectors[:, :n_pairs],      # 最大特征值
                    eigenvectors[:, -n_pairs:]     # 最小特征值
                ], axis=1)
                
                # 转换为PyTorch张量
                filters = torch.FloatTensor(selected_filters.T)  # [n_components, n_channels]
                self.csp_filters[int(cls)] = filters
                
                print(f"  类别 {cls}: CSP滤波器形状 {filters.shape}")
                
            except Exception as e:
                print(f"  类别 {cls}: CSP训练失败 - {e}")
                continue
    
    def _compute_covariance(self, X: np.ndarray) -> np.ndarray:
        """
        计算归一化协方差矩阵
        
        Args:
            X: EEG数据 [N, C, T]
        
        Returns:
            avg_cov: 平均协方差矩阵 [C, C]
        """
        n_trials, n_channels, n_timepoints = X.shape
        cov_sum = np.zeros((n_channels, n_channels))
        
        for i in range(n_trials):
            trial_data = X[i]  # [C, T]
            
            # 计算协方差矩阵
            cov = np.cov(trial_data)
            
            # 正则化
            cov = cov + 1e-6 * np.eye(n_channels)
            
            # 归一化
            trace_val = np.trace(cov)
            if trace_val > 1e-10:
                cov = cov / trace_val
            else:
                cov = np.eye(n_channels)
            
            cov_sum += cov
        
        avg_cov = cov_sum / n_trials
        avg_cov = avg_cov + 1e-5 * np.eye(n_channels)
        
        return avg_cov
    
    def extract_csp_features(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """
        提取CSP特征（对数方差）
        
        Args:
            x: EEG数据 [B, C, T]
            y: 类别标签 [B]
        
        Returns:
            features: CSP特征 [B, n_components]
        """
        B, C, T = x.shape
        device = x.device
        
        # 为每个样本提取CSP特征
        all_features = []
        
        for i in range(B):
            cls = int(y[i].item())
            
            if cls not in self.csp_filters:
                # 如果没有该类别的CSP滤波器，使用零特征
                features = torch.zeros(self.n_components, device=device)
            else:
                # 应用CSP滤波器
                filters = self.csp_filters[cls].to(device)  # [n_components, C]
                filtered = torch.matmul(filters, x[i])  # [n_components, T]
                
                # 计算对数方差特征（真正的ERD特征）
                variances = torch.var(filtered, dim=1)  # [n_components]
                
                # 归一化并取对数
                total_var = torch.sum(variances) + 1e-10
                features = torch.log(variances / total_var + 1e-10)
            
            all_features.append(features)
        
        return torch.stack(all_features)  # [B, n_components]
    
    def compute_alpha_power_csp(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """
        计算CSP滤波后的alpha频段功率
        
        Args:
            x: EEG数据 [B, C, T]
            y: 类别标签 [B]
        
        Returns:
            alpha_power: Alpha功率 [B]
        """
        B, C, T = x.shape
        device = x.device
        
        alpha_powers = []
        
        for i in range(B):
            cls = int(y[i].item())
            
            if cls not in self.csp_filters:
                alpha_powers.append(torch.tensor(0.0, device=device))
                continue
            
            # 应用CSP滤波器
            filters = self.csp_filters[cls].to(device)
            filtered = torch.matmul(filters, x[i])  # [n_components, T]
            
            # FFT
            fft = torch.fft.rfft(filtered, dim=-1)
            psd = fft.abs() ** 2  # [n_components, num_freqs]
            
            # 提取alpha频段功率（所有CSP成分的平均）
            alpha_power = psd[:, self.alpha_mask].mean()
            alpha_powers.append(alpha_power)
        
        return torch.stack(alpha_powers)
    
    def forward(self, x0_pred: torch.Tensor, y: torch.Tensor,
                target_csp_features: torch.Tensor) -> torch.Tensor:
        """
        计算基于CSP的ERD损失
        
        Args:
            x0_pred: 预测的x0 [B, C, T]
            y: 类别标签 [B]
            target_csp_features: 目标CSP特征 [num_classes, n_components]
        
        Returns:
            loss: ERD损失 (标量)
        """
        if len(self.csp_filters) == 0:
            # 如果没有训练CSP滤波器，返回零损失
            return torch.tensor(0.0, device=x0_pred.device)
        
        # 提取预测数据的CSP特征
        pred_features = self.extract_csp_features(x0_pred, y)  # [B, n_components]
        
        # 获取每个样本的目标CSP特征
        target_features = target_csp_features[y]  # [B, n_components]
        
        # MSE损失
        loss = F.mse_loss(pred_features, target_features)
        
        return loss


class MultiChannelERDLoss(nn.Module):
    """
    多通道ERD损失函数
    
    考虑C3, C4, CP3, CP4, Cz等多个运动皮层相关通道
    """
    
    def __init__(self, fs: int = 250, n_fft: int = 1000):
        """
        Args:
            fs: 采样率
            n_fft: FFT点数
        """
        super().__init__()
        self.fs = fs
        self.n_fft = n_fft
        
        # BCI2a数据集的通道索引
        self.motor_channels = {
            'C3': 7,    # 左侧运动皮层
            'Cz': 9,    # 中央
            'C4': 11,   # 右侧运动皮层
            'CP3': 13,  # 左侧中央顶区
            'CP4': 15,  # 右侧中央顶区
        }
        
        # 频率轴
        freqs = torch.fft.rfftfreq(n_fft, 1.0 / fs)
        self.register_buffer('freqs', freqs)
        
        # Alpha频段掩码 (8-13Hz)
        alpha_mask = (freqs >= 8) & (freqs <= 13)
        self.register_buffer('alpha_mask', alpha_mask)
    
    def compute_channel_alpha_power(self, x: torch.Tensor, ch_idx: int) -> torch.Tensor:
        """计算指定通道的alpha功率"""
        channel_data = x[:, ch_idx, :]  # [B, T]
        
        # FFT
        fft = torch.fft.rfft(channel_data, dim=-1)
        psd = fft.abs() ** 2  # [B, num_freqs]
        
        # Alpha功率
        alpha_power = psd[:, self.alpha_mask].mean(dim=-1)  # [B]
        
        return alpha_power
    
    def compute_multi_channel_laterality(self, x: torch.Tensor) -> torch.Tensor:
        """
        计算多通道ERD侧化指数
        
        综合C3-C4, CP3-CP4的侧化信息
        
        Args:
            x: EEG数据 [B, C, T]
        
        Returns:
            laterality: 综合侧化指数 [B]
        """
        # C3-C4侧化
        c3_alpha = self.compute_channel_alpha_power(x, self.motor_channels['C3'])
        c4_alpha = self.compute_channel_alpha_power(x, self.motor_channels['C4'])
        c_laterality = (c4_alpha - c3_alpha) / (c4_alpha + c3_alpha + 1e-10)
        
        # CP3-CP4侧化
        cp3_alpha = self.compute_channel_alpha_power(x, self.motor_channels['CP3'])
        cp4_alpha = self.compute_channel_alpha_power(x, self.motor_channels['CP4'])
        cp_laterality = (cp4_alpha - cp3_alpha) / (cp4_alpha + cp3_alpha + 1e-10)
        
        # 综合侧化指数（加权平均）
        # C3-C4权重更高，因为它们是主要的运动皮层通道
        laterality = 0.7 * c_laterality + 0.3 * cp_laterality
        
        return laterality
    
    def forward(self, x0_pred: torch.Tensor, y: torch.Tensor,
                target_laterality: torch.Tensor) -> torch.Tensor:
        """
        计算多通道ERD损失
        
        Args:
            x0_pred: 预测的x0 [B, C, T]
            y: 类别标签 [B]
            target_laterality: 目标侧化指数 [num_classes]
        
        Returns:
            loss: ERD损失 (标量)
        """
        # 计算多通道侧化指数
        pred_lat = self.compute_multi_channel_laterality(x0_pred)  # [B]
        
        # 获取目标侧化指数
        target_lat = target_laterality[y]  # [B]
        
        # MSE损失
        loss = F.mse_loss(pred_lat, target_lat)
        
        return loss


# ============================================================================
# 使用示例
# ============================================================================

def example_usage():
    """
    演示如何使用增强的ERD损失函数
    """
    import numpy as np
    
    # 1. 准备真实数据
    X_real = np.random.randn(100, 22, 1000)  # [N, C, T]
    y_real = np.random.randint(0, 4, 100)    # [N]
    
    # 2. 创建CSP-based ERD损失
    csp_erd_loss = CSPBasedERDLoss(n_channels=22, n_components=6)
    
    # 3. 从真实数据学习CSP滤波器
    csp_erd_loss.fit_csp_filters(X_real, y_real)
    
    # 4. 计算目标CSP特征
    X_real_torch = torch.FloatTensor(X_real)
    y_real_torch = torch.LongTensor(y_real)
    
    target_csp_features = []
    for cls in range(4):
        mask = y_real_torch == cls
        if mask.sum() > 0:
            cls_features = csp_erd_loss.extract_csp_features(
                X_real_torch[mask], 
                y_real_torch[mask]
            )
            target_csp_features.append(cls_features.mean(dim=0))
        else:
            target_csp_features.append(torch.zeros(6))
    
    target_csp_features = torch.stack(target_csp_features)  # [4, 6]
    
    # 5. 在训练时使用
    x0_pred = torch.randn(32, 22, 1000)  # 生成的数据
    y = torch.randint(0, 4, (32,))       # 标签
    
    loss = csp_erd_loss(x0_pred, y, target_csp_features)
    print(f"CSP-based ERD Loss: {loss.item():.4f}")
    
    # 6. 或者使用多通道ERD损失
    multi_ch_erd_loss = MultiChannelERDLoss()
    target_laterality = torch.randn(4)  # 每个类别的目标侧化指数
    
    loss2 = multi_ch_erd_loss(x0_pred, y, target_laterality)
    print(f"Multi-channel ERD Loss: {loss2.item():.4f}")


if __name__ == '__main__':
    example_usage()

"""
Class-Discriminative DDPM Components

This module implements enhanced class conditioning mechanisms for EEG-DDPM:
1. EnhancedClassEmbedding - Multi-layer MLP with residual connections
2. MultiScaleCondUNet - UNet with multi-scale class injection

Requirements: 2.1, 2.3
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def sinusoidal_embedding(timesteps: torch.Tensor, dim: int = 128, max_period: int = 10000):
    """时间步的正弦位置编码"""
    half = dim // 2
    device = timesteps.device
    t = timesteps.float()
    freqs = torch.exp(-math.log(max_period) * torch.arange(0, half, device=device).float() / half)
    args = t[:, None] * freqs[None]
    emb = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
    if dim % 2 == 1:
        emb = F.pad(emb, (0,1))
    return emb


class EnhancedClassEmbedding(nn.Module):
    """
    Enhanced class embedding module with multi-layer MLP and residual connections.
    
    Architecture:
    - Embedding(num_classes, 64)
    - Linear(64, 128) + SiLU
    - Linear(128, 256) + SiLU  
    - Linear(256, embed_dim) with residual from layer 2 output (projected)
    
    Requirements: 2.3
    """
    
    def __init__(self, num_classes: int = 4, embed_dim: int = 256):
        """
        Args:
            num_classes: Number of classes (4 for BCI2a)
            embed_dim: Final embedding dimension (256)
        """
        super().__init__()
        self.num_classes = num_classes
        self.embed_dim = embed_dim
        
        # Layer 1: Embedding
        self.embedding = nn.Embedding(num_classes, 64)
        
        # Layer 2: Linear(64, 128) + SiLU
        self.linear1 = nn.Linear(64, 128)
        self.act1 = nn.SiLU()
        
        # Layer 3: Linear(128, 256) + SiLU
        self.linear2 = nn.Linear(128, 256)
        self.act2 = nn.SiLU()
        
        # Layer 4: Linear(256, embed_dim)
        self.linear3 = nn.Linear(256, embed_dim)
        
        # Residual projection: project 128-dim to embed_dim for residual connection
        self.residual_proj = nn.Linear(128, embed_dim)
        
    def forward(self, y: torch.Tensor) -> torch.Tensor:
        """
        Args:
            y: Class labels [B] with values in [0, num_classes)
            
        Returns:
            class_embedding: Class embedding vector [B, embed_dim]
        """
        # Layer 1: Embedding lookup
        h = self.embedding(y)  # [B, 64]
        
        # Layer 2: Linear + SiLU
        h = self.linear1(h)    # [B, 128]
        h = self.act1(h)
        
        # Save for residual connection
        residual = h
        
        # Layer 3: Linear + SiLU
        h = self.linear2(h)    # [B, 256]
        h = self.act2(h)
        
        # Layer 4: Linear
        h = self.linear3(h)    # [B, embed_dim]
        
        # Add residual connection (projected to embed_dim)
        h = h + self.residual_proj(residual)
        
        return h


class ResBlock(nn.Module):
    """Residual block with condition injection."""
    
    def __init__(self, in_ch: int, out_ch: int, cond_dim: int):
        super().__init__()
        self.conv1 = nn.Conv1d(in_ch, out_ch, 3, padding=1)
        self.conv2 = nn.Conv1d(out_ch, out_ch, 3, padding=1)
        self.norm1 = nn.GroupNorm(8, out_ch)
        self.norm2 = nn.GroupNorm(8, out_ch)
        self.cond_proj = nn.Linear(cond_dim, out_ch)
        self.skip = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()
        
    def forward(self, x: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        h = self.norm1(F.silu(self.conv1(x)))
        h = h + self.cond_proj(cond).unsqueeze(-1)
        h = self.norm2(F.silu(self.conv2(h)))
        return h + self.skip(x)


class AttentionBlock(nn.Module):
    """Self-attention block."""
    
    def __init__(self, ch: int):
        super().__init__()
        self.norm = nn.GroupNorm(8, ch)
        self.qkv = nn.Conv1d(ch, ch * 3, 1)
        self.proj = nn.Conv1d(ch, ch, 1)
        self.scale = ch ** -0.5
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, C, L = x.shape
        h = self.norm(x)
        qkv = self.qkv(h).reshape(B, 3, C, L)
        q, k, v = qkv[:, 0], qkv[:, 1], qkv[:, 2]
        
        attn = torch.einsum('bcl,bcm->blm', q, k) * self.scale
        attn = F.softmax(attn, dim=-1)
        h = torch.einsum('blm,bcm->bcl', attn, v)
        
        return x + self.proj(h)


class MultiScaleCondUNet(nn.Module):
    """
    Multi-scale conditional UNet with enhanced class embedding injection.
    
    Injects class embedding at:
    - Encoder stages (down1, down2, down3)
    - Bottleneck (mid)
    - Decoder stages (up3, up2, up1)
    
    Requirements: 2.1, 2.3
    """
    
    def __init__(self, channels: int = 22, num_classes: int = 4, time_dim: int = 256):
        """
        Args:
            channels: Number of EEG channels
            num_classes: Number of classes (4 for BCI2a)
            time_dim: Dimension for time embedding
        """
        super().__init__()
        self.channels = channels
        self.num_classes = num_classes
        self.time_dim = time_dim
        
        # Enhanced class embedding (multi-layer MLP with residual)
        self.class_embed = EnhancedClassEmbedding(num_classes, embed_dim=256)
        
        # Time embedding MLP
        self.time_mlp = nn.Sequential(
            nn.Linear(time_dim, 512),
            nn.SiLU(),
            nn.Linear(512, 256),
        )
        
        # Condition dimension (time + class combined)
        cond_dim = 256
        
        # Input projection
        self.in_proj = nn.Conv1d(channels, 64, 3, padding=1)
        
        # Encoder with class injection at each stage
        self.down1 = nn.ModuleList([
            ResBlock(64, 128, cond_dim),
            ResBlock(128, 128, cond_dim),
        ])
        self.down1_attn = AttentionBlock(128)
        
        self.down2 = nn.ModuleList([
            ResBlock(128, 256, cond_dim),
            ResBlock(256, 256, cond_dim),
        ])
        self.down2_attn = AttentionBlock(256)
        
        self.down3 = nn.ModuleList([
            ResBlock(256, 512, cond_dim),
            ResBlock(512, 512, cond_dim),
        ])
        
        # Bottleneck with class injection
        self.mid = nn.ModuleList([
            ResBlock(512, 512, cond_dim),
            AttentionBlock(512),
            ResBlock(512, 512, cond_dim),
        ])
        
        # Decoder with class injection at each stage
        self.up3 = nn.ModuleList([
            ResBlock(1024, 512, cond_dim),  # 512 + 512 skip
            ResBlock(512, 256, cond_dim),
        ])
        
        self.up2 = nn.ModuleList([
            ResBlock(512, 256, cond_dim),   # 256 + 256 skip
            ResBlock(256, 128, cond_dim),
        ])
        self.up2_attn = AttentionBlock(128)
        
        self.up1 = nn.ModuleList([
            ResBlock(256, 128, cond_dim),   # 128 + 128 skip
            ResBlock(128, 64, cond_dim),
        ])
        self.up1_attn = AttentionBlock(64)
        
        # Output projection
        self.out = nn.Sequential(
            nn.GroupNorm(8, 64),
            nn.SiLU(),
            nn.Conv1d(64, channels, 3, padding=1),
        )
        
        # Pooling for downsampling
        self.pool = nn.AvgPool1d(2)
        
    def forward(self, x: torch.Tensor, t: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Noisy EEG data [B, C, T]
            t: Timesteps [B]
            y: Class labels [B]
            
        Returns:
            eps_pred: Predicted noise [B, C, T]
        """
        # Compute time embedding
        t_emb = sinusoidal_embedding(t, self.time_dim)
        t_emb = self.time_mlp(t_emb)  # [B, 256]
        
        # Compute enhanced class embedding
        c_emb = self.class_embed(y)   # [B, 256]
        
        # Combine time and class embeddings
        cond = t_emb + c_emb  # [B, 256]
        
        # Input projection
        h = self.in_proj(x)  # [B, 64, T]
        
        # Encoder stage 1 (with class injection)
        h1 = self.down1[0](h, cond)
        h1 = self.down1[1](h1, cond)
        h1 = self.down1_attn(h1)  # [B, 128, T]
        
        # Encoder stage 2 (with class injection)
        h2 = self.down2[0](self.pool(h1), cond)
        h2 = self.down2[1](h2, cond)
        h2 = self.down2_attn(h2)  # [B, 256, T/2]
        
        # Encoder stage 3 (with class injection)
        h3 = self.down3[0](self.pool(h2), cond)
        h3 = self.down3[1](h3, cond)  # [B, 512, T/4]
        
        # Bottleneck (with class injection)
        m = self.mid[0](self.pool(h3), cond)
        m = self.mid[1](m)  # Attention (no cond)
        m = self.mid[2](m, cond)  # [B, 512, T/8]
        
        # Decoder stage 3 (with class injection)
        m = F.interpolate(m, size=h3.size(-1), mode='linear', align_corners=False)
        u3 = self.up3[0](torch.cat([m, h3], dim=1), cond)
        u3 = self.up3[1](u3, cond)  # [B, 256, T/4]
        
        # Decoder stage 2 (with class injection)
        u3 = F.interpolate(u3, size=h2.size(-1), mode='linear', align_corners=False)
        u2 = self.up2[0](torch.cat([u3, h2], dim=1), cond)
        u2 = self.up2[1](u2, cond)
        u2 = self.up2_attn(u2)  # [B, 128, T/2]
        
        # Decoder stage 1 (with class injection)
        u2 = F.interpolate(u2, size=h1.size(-1), mode='linear', align_corners=False)
        u1 = self.up1[0](torch.cat([u2, h1], dim=1), cond)
        u1 = self.up1[1](u1, cond)
        u1 = self.up1_attn(u1)  # [B, 64, T]
        
        # Output
        return self.out(u1)


# ============================================================================
# Loss Functions for Class-Discriminative DDPM
# ============================================================================

# EEG通道索引 (BCI2a数据集)
C3_IDX = 7   # C3通道索引
C4_IDX = 11  # C4通道索引

# 默认参数
DEFAULT_FS = 250  # 采样率
DEFAULT_T = 1000  # 时间点数


class ERDLateralityLoss(nn.Module):
    """
    ERD侧化损失函数
    
    计算alpha频段(8-13Hz)功率的侧化指数，并惩罚与目标侧化指数的偏差。
    侧化指数 = (C4_alpha - C3_alpha) / (C4_alpha + C3_alpha + eps)
    
    Requirements: 4.1, 4.2, 4.3
    """
    
    def __init__(self, fs: int = DEFAULT_FS, n_fft: int = DEFAULT_T, 
                 c3_idx: int = C3_IDX, c4_idx: int = C4_IDX):
        """
        Args:
            fs: 采样率 (Hz)
            n_fft: FFT点数
            c3_idx: C3通道索引
            c4_idx: C4通道索引
        """
        super().__init__()
        self.fs = fs
        self.n_fft = n_fft
        self.c3_idx = c3_idx
        self.c4_idx = c4_idx
        
        # 计算频率轴
        freqs = torch.fft.rfftfreq(n_fft, 1.0 / fs)
        self.register_buffer('freqs', freqs)
        
        # Alpha频段掩码 (8-13Hz)
        alpha_mask = (freqs >= 8) & (freqs <= 13)
        self.register_buffer('alpha_mask', alpha_mask)
    
    def compute_alpha_power(self, x: torch.Tensor, ch_idx: int) -> torch.Tensor:
        """
        计算指定通道的alpha频段功率
        
        Args:
            x: EEG数据 [B, C, T]
            ch_idx: 通道索引
            
        Returns:
            alpha_power: Alpha功率 [B]
        """
        # 提取指定通道
        channel_data = x[:, ch_idx, :]  # [B, T]
        
        # FFT
        fft = torch.fft.rfft(channel_data, dim=-1)
        psd = fft.abs() ** 2  # [B, num_freqs]
        
        # 提取alpha频段功率
        alpha_power = psd[:, self.alpha_mask].mean(dim=-1)  # [B]
        
        return alpha_power
    
    def compute_laterality(self, x: torch.Tensor) -> torch.Tensor:
        """
        计算ERD侧化指数
        
        侧化指数 = (C4_alpha - C3_alpha) / (C4_alpha + C3_alpha + eps)
        - 正值: C4功率更高 (左手运动想象时预期)
        - 负值: C3功率更高 (右手运动想象时预期)
        
        Args:
            x: EEG数据 [B, C, T]
            
        Returns:
            laterality: 侧化指数 [B]
        """
        c3_alpha = self.compute_alpha_power(x, self.c3_idx)
        c4_alpha = self.compute_alpha_power(x, self.c4_idx)
        
        laterality = (c4_alpha - c3_alpha) / (c4_alpha + c3_alpha + 1e-10)
        
        return laterality
    
    def forward(self, x0_pred: torch.Tensor, y: torch.Tensor, 
                target_laterality: torch.Tensor) -> torch.Tensor:
        """
        计算ERD侧化损失
        
        Args:
            x0_pred: 预测的x0 [B, C, T]
            y: 类别标签 [B]
            target_laterality: 每个类别的目标侧化指数 [num_classes]
            
        Returns:
            loss: ERD侧化损失 (标量)
        """
        # 计算预测数据的侧化指数
        pred_lat = self.compute_laterality(x0_pred)  # [B]
        
        # 获取每个样本的目标侧化指数
        target_lat = target_laterality[y]  # [B]
        
        # MSE损失
        loss = F.mse_loss(pred_lat, target_lat)
        
        return loss


class SpectralLoss(nn.Module):
    """
    频谱损失函数（包含所有生理相关频段）
    
    计算功率谱密度(PSD)的对数MSE损失，对所有生理相关频段进行加权：
    - Delta (1-4 Hz): 基础节律
    - Theta (4-8 Hz): 认知活动
    - Alpha (8-13 Hz): 感觉运动节律，MI任务关键频段
    - Beta (13-30 Hz): 运动准备和执行
    - Gamma (30-50 Hz): 高级认知处理
    
    Requirements: 4.4
    """
    
    def __init__(self, fs: int = DEFAULT_FS, n_fft: int = DEFAULT_T,
                 delta_weight: float = 1.0, theta_weight: float = 1.0,
                 alpha_weight: float = 2.0, beta_weight: float = 1.5,
                 gamma_weight: float = 1.0):
        """
        Args:
            fs: 采样率 (Hz)
            n_fft: FFT点数
            delta_weight: Delta频段权重 (默认1.0)
            theta_weight: Theta频段权重 (默认1.0)
            alpha_weight: Alpha频段权重 (默认2.0，MI任务关键频段)
            beta_weight: Beta频段权重 (默认1.5，运动相关)
            gamma_weight: Gamma频段权重 (默认1.0)
        """
        super().__init__()
        self.fs = fs
        self.n_fft = n_fft
        self.delta_weight = delta_weight
        self.theta_weight = theta_weight
        self.alpha_weight = alpha_weight
        self.beta_weight = beta_weight
        self.gamma_weight = gamma_weight
        
        # 计算频率轴
        freqs = torch.fft.rfftfreq(n_fft, 1.0 / fs)
        self.register_buffer('freqs', freqs)
        
        # 所有生理相关频段掩码
        delta_mask = (freqs >= 1) & (freqs <= 4)
        theta_mask = (freqs >= 4) & (freqs <= 8)
        alpha_mask = (freqs >= 8) & (freqs <= 13)
        beta_mask = (freqs >= 13) & (freqs <= 30)
        gamma_mask = (freqs >= 30) & (freqs <= 50)
        
        self.register_buffer('delta_mask', delta_mask)
        self.register_buffer('theta_mask', theta_mask)
        self.register_buffer('alpha_mask', alpha_mask)
        self.register_buffer('beta_mask', beta_mask)
        self.register_buffer('gamma_mask', gamma_mask)
    
    def compute_psd(self, x: torch.Tensor) -> torch.Tensor:
        """
        计算平均功率谱密度
        
        Args:
            x: EEG数据 [B, C, T]
            
        Returns:
            psd: 平均PSD [num_freqs]
        """
        fft = torch.fft.rfft(x, dim=-1)
        psd = (fft.abs() ** 2).mean(dim=(0, 1))  # 平均所有batch和通道
        return psd
    
    def forward(self, x0_pred: torch.Tensor, target_psd: torch.Tensor) -> torch.Tensor:
        """
        计算频谱损失（包含所有生理相关频段）
        
        Args:
            x0_pred: 预测的x0 [B, C, T]
            target_psd: 目标PSD [num_freqs]
            
        Returns:
            loss: 频谱损失 (标量)
        """
        # 计算预测数据的PSD
        pred_psd = self.compute_psd(x0_pred)
        
        # 对数变换
        pred_log = torch.log(pred_psd + 1e-10)
        target_log = torch.log(target_psd + 1e-10)
        
        # 全频段基础损失
        full_loss = F.mse_loss(pred_log, target_log)
        
        # 各频段加权损失
        delta_loss = F.mse_loss(pred_log[self.delta_mask], target_log[self.delta_mask])
        theta_loss = F.mse_loss(pred_log[self.theta_mask], target_log[self.theta_mask])
        alpha_loss = F.mse_loss(pred_log[self.alpha_mask], target_log[self.alpha_mask])
        beta_loss = F.mse_loss(pred_log[self.beta_mask], target_log[self.beta_mask])
        gamma_loss = F.mse_loss(pred_log[self.gamma_mask], target_log[self.gamma_mask])
        
        # 总损失：全频段损失 + 各频段加权损失
        total_loss = (full_loss + 
                      self.delta_weight * delta_loss +
                      self.theta_weight * theta_loss +
                      self.alpha_weight * alpha_loss +
                      self.beta_weight * beta_loss +
                      self.gamma_weight * gamma_loss)
        
        return total_loss


class ClassificationLoss(nn.Module):
    """
    分类损失函数
    
    使用预训练分类器计算预测x0的交叉熵损失。
    仅在低噪声时间步(t < 200)应用。
    
    Requirements: 2.2
    """
    
    def __init__(self, classifier: nn.Module, low_t_threshold: int = 200):
        """
        Args:
            classifier: 预训练的EEG分类器
            low_t_threshold: 低噪声时间步阈值 (默认200)
        """
        super().__init__()
        self.classifier = classifier
        self.low_t_threshold = low_t_threshold
        
        # 冻结分类器参数
        for param in self.classifier.parameters():
            param.requires_grad = False
    
    def forward(self, x0_pred: torch.Tensor, y: torch.Tensor, 
                t: torch.Tensor) -> torch.Tensor:
        """
        计算分类损失
        
        Args:
            x0_pred: 预测的x0 [B, C, T]
            y: 类别标签 [B]
            t: 时间步 [B]
            
        Returns:
            loss: 分类损失 (标量)
        """
        # 仅在低噪声时间步应用
        low_t_mask = t < self.low_t_threshold
        
        if low_t_mask.sum() == 0:
            return torch.tensor(0.0, device=x0_pred.device)
        
        # 提取低噪声样本
        x0_low_t = x0_pred[low_t_mask]
        y_low_t = y[low_t_mask]
        
        # 分类器预测
        logits = self.classifier(x0_low_t)
        
        # 交叉熵损失
        loss = F.cross_entropy(logits, y_low_t)
        
        return loss


class CombinedLoss(nn.Module):
    """
    组合损失函数
    
    整合噪声损失、频谱损失、ERD损失和分类损失。
    
    Requirements: 2.2
    """
    
    def __init__(self, 
                 erd_loss: ERDLateralityLoss,
                 spectral_loss: SpectralLoss,
                 classification_loss: ClassificationLoss = None,
                 noise_weight: float = 1.0,
                 spectral_weight: float = 1.0,
                 erd_weight: float = 10.0,
                 cls_weight: float = 5.0):
        """
        Args:
            erd_loss: ERD侧化损失模块
            spectral_loss: 频谱损失模块
            classification_loss: 分类损失模块 (可选)
            noise_weight: 噪声损失权重
            spectral_weight: 频谱损失权重
            erd_weight: ERD损失权重
            cls_weight: 分类损失权重
        """
        super().__init__()
        self.erd_loss = erd_loss
        self.spectral_loss = spectral_loss
        self.classification_loss = classification_loss
        
        self.noise_weight = noise_weight
        self.spectral_weight = spectral_weight
        self.erd_weight = erd_weight
        self.cls_weight = cls_weight
    
    def forward(self, 
                eps_pred: torch.Tensor, 
                eps: torch.Tensor,
                x0_pred: torch.Tensor,
                y: torch.Tensor,
                t: torch.Tensor,
                target_psd: torch.Tensor,
                target_laterality: torch.Tensor) -> tuple:
        """
        计算组合损失
        
        Args:
            eps_pred: 预测噪声 [B, C, T]
            eps: 真实噪声 [B, C, T]
            x0_pred: 预测的x0 [B, C, T]
            y: 类别标签 [B]
            t: 时间步 [B]
            target_psd: 目标PSD [num_freqs]
            target_laterality: 目标侧化指数 [num_classes]
            
        Returns:
            total_loss: 总损失 (标量)
            loss_dict: 各项损失字典
        """
        # 噪声损失
        noise_loss = F.mse_loss(eps_pred, eps)
        
        # 频谱损失
        spec_loss = self.spectral_loss(x0_pred, target_psd)
        
        # ERD侧化损失
        erd_loss = self.erd_loss(x0_pred, y, target_laterality)
        
        # 分类损失
        if self.classification_loss is not None:
            cls_loss = self.classification_loss(x0_pred, y, t)
        else:
            cls_loss = torch.tensor(0.0, device=eps_pred.device)
        
        # 总损失
        total_loss = (self.noise_weight * noise_loss + 
                      self.spectral_weight * spec_loss + 
                      self.erd_weight * erd_loss + 
                      self.cls_weight * cls_loss)
        
        # 损失字典
        loss_dict = {
            'noise': noise_loss.item(),
            'spectral': spec_loss.item(),
            'erd': erd_loss.item(),
            'classification': cls_loss.item() if torch.is_tensor(cls_loss) else cls_loss,
            'total': total_loss.item()
        }
        
        return total_loss, loss_dict


# ============================================================================
# EEG Classifier for Guidance (基于EEGNet)
# ============================================================================


class EEGClassifier(nn.Module):
    """
    用于分类器引导的EEG分类器 (基于EEGNet架构)
    
    EEGNet是一个紧凑的卷积神经网络，专门设计用于EEG信号分类。
    包含时间卷积、深度卷积和可分离卷积，支持特征提取用于中间表示。
    
    Requirements: 3.1
    """
    
    def __init__(self, channels: int = 22, n_samples: int = 1000, 
                 num_classes: int = 4, F1: int = 8, D: int = 2, 
                 F2: int = 16, dropout_rate: float = 0.5):
        """
        Args:
            channels: EEG通道数 (默认22)
            n_samples: 时间采样点数 (默认1000)
            num_classes: 类别数量 (默认4)
            F1: 第一层时间滤波器数量 (默认8)
            D: 深度乘数 (默认2)
            F2: 可分离卷积滤波器数量 (默认16)
            dropout_rate: Dropout比率 (默认0.5)
        """
        super().__init__()
        self.channels = channels
        self.n_samples = n_samples
        self.num_classes = num_classes
        
        # 第一个卷积块 - 时间卷积
        self.conv1 = nn.Conv2d(1, F1, (1, 64), padding=(0, 32), bias=False)
        self.batchnorm1 = nn.BatchNorm2d(F1)
        
        # 深度卷积块
        self.depthwiseConv = nn.Conv2d(F1, D * F1, (channels, 1), 
                                       groups=F1, bias=False)
        self.batchnorm2 = nn.BatchNorm2d(D * F1)
        self.activation = nn.ELU()
        self.avgpool1 = nn.AvgPool2d((1, 4))
        self.dropout1 = nn.Dropout(dropout_rate)
        
        # 可分离卷积块
        self.separableConv = nn.Conv2d(D * F1, F2, (1, 16), 
                                       padding=(0, 8), bias=False)
        self.batchnorm3 = nn.BatchNorm2d(F2)
        self.avgpool2 = nn.AvgPool2d((1, 8))
        self.dropout2 = nn.Dropout(dropout_rate)
        
        # 计算特征维度
        self._calculate_feature_size()
        
        # 分类器
        self.classifier = nn.Linear(self.feature_size, num_classes)
        
        # 特征维度 (用于外部访问)
        self.feature_dim = self.feature_size
    
    def _calculate_feature_size(self):
        """计算展平后的特征维度"""
        with torch.no_grad():
            x = torch.zeros(1, 1, self.channels, self.n_samples)
            x = self.conv1(x)
            x = self.batchnorm1(x)
            x = self.depthwiseConv(x)
            x = self.batchnorm2(x)
            x = self.activation(x)
            x = self.avgpool1(x)
            x = self.separableConv(x)
            x = self.batchnorm3(x)
            x = self.activation(x)
            x = self.avgpool2(x)
            self.feature_size = x.numel()
    
    def extract_features(self, x: torch.Tensor) -> torch.Tensor:
        """
        提取中间特征用于特征匹配
        
        Args:
            x: EEG数据 [B, C, T]
            
        Returns:
            features: 特征向量 [B, feature_dim]
        """
        # 输入形状: (batch_size, n_channels, n_samples)
        # 转换为 (batch_size, 1, n_channels, n_samples)
        if x.dim() == 3:
            x = x.unsqueeze(1)
        
        # 第一个卷积块
        x = self.conv1(x)
        x = self.batchnorm1(x)
        
        # 深度卷积块
        x = self.depthwiseConv(x)
        x = self.batchnorm2(x)
        x = self.activation(x)
        x = self.avgpool1(x)
        x = self.dropout1(x)
        
        # 可分离卷积块
        x = self.separableConv(x)
        x = self.batchnorm3(x)
        x = self.activation(x)
        x = self.avgpool2(x)
        x = self.dropout2(x)
        
        # 展平
        features = x.view(x.size(0), -1)
        return features
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        前向传播
        
        Args:
            x: EEG数据 [B, C, T]
            
        Returns:
            logits: 分类logits [B, num_classes]
        """
        features = self.extract_features(x)
        logits = self.classifier(features)
        return logits


def pretrain_classifier(classifier: EEGClassifier, 
                        X: torch.Tensor, 
                        y: torch.Tensor,
                        epochs: int = 50,
                        batch_size: int = 64,
                        lr: float = 1e-3,
                        device: str = 'cuda',
                        save_path: str = None,
                        verbose: bool = True) -> EEGClassifier:
    """
    预训练EEG分类器
    
    Args:
        classifier: EEGClassifier实例
        X: 训练数据 [N, C, T]
        y: 标签 [N]
        epochs: 训练轮数
        batch_size: 批次大小
        lr: 学习率
        device: 设备
        save_path: 保存路径 (可选)
        verbose: 是否打印训练信息
        
    Returns:
        classifier: 训练后的分类器
        
    Requirements: 3.1
    """
    from torch.utils.data import DataLoader, TensorDataset
    
    classifier = classifier.to(device)
    optimizer = torch.optim.Adam(classifier.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, epochs)
    
    # 创建数据加载器
    if not isinstance(X, torch.Tensor):
        X = torch.FloatTensor(X)
    if not isinstance(y, torch.Tensor):
        y = torch.LongTensor(y)
    
    dataset = TensorDataset(X, y)
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=True)
    
    best_acc = 0.0
    best_state = None
    
    if verbose:
        print("预训练EEG分类器...")
    
    for ep in range(1, epochs + 1):
        classifier.train()
        total_loss = 0.0
        correct = 0
        total = 0
        
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            
            # 前向传播
            logits = classifier(xb)
            loss = F.cross_entropy(logits, yb)
            
            # 反向传播
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            # 统计
            total_loss += loss.item()
            pred = logits.argmax(dim=1)
            correct += (pred == yb).sum().item()
            total += len(yb)
        
        scheduler.step()
        
        # 计算准确率
        acc = correct / total
        avg_loss = total_loss / len(loader)
        
        # 保存最佳模型
        if acc > best_acc:
            best_acc = acc
            best_state = classifier.state_dict().copy()
        
        if verbose and (ep % 10 == 0 or ep == 1):
            print(f"  Epoch {ep}: loss={avg_loss:.4f}, acc={acc*100:.2f}%")
    
    # 加载最佳模型
    if best_state is not None:
        classifier.load_state_dict(best_state)
    
    # 保存模型
    if save_path is not None:
        torch.save(classifier.state_dict(), save_path)
        if verbose:
            print(f"  保存分类器到: {save_path}")
    
    if verbose:
        print(f"  最佳准确率: {best_acc*100:.2f}%")
    
    classifier.eval()
    return classifier


# ============================================================================
# ClassDiscriminativeDDPM Main Class
# ============================================================================

import numpy as np


class ClassDiscriminativeDDPM(nn.Module):
    """
    类别判别DDPM主类
    
    整合所有损失函数和分类器引导采样方法。
    
    Requirements: 2.2, 3.1, 3.2, 3.3
    """
    
    def __init__(self, 
                 eps_model: nn.Module,
                 classifier: nn.Module,
                 target_psd: torch.Tensor,
                 target_laterality: torch.Tensor,
                 n_timesteps: int = 1000,
                 channels: int = 22,
                 n_samples: int = 1000,
                 fs: int = 250):
        """
        Args:
            eps_model: UNet噪声预测模型
            classifier: 预训练分类器
            target_psd: 目标功率谱密度 [num_freqs]
            target_laterality: 每个类别的目标侧化指数 [num_classes]
            n_timesteps: 扩散时间步数 (默认1000)
            channels: EEG通道数 (默认22)
            n_samples: 时间采样点数 (默认1000)
            fs: 采样率 (默认250Hz)
        """
        super().__init__()
        self.eps_model = eps_model
        self.classifier = classifier
        self.n_timesteps = n_timesteps
        self.channels = channels
        self.n_samples = n_samples
        self.fs = fs
        
        # 注册目标统计量
        self.register_buffer('target_psd', target_psd)
        self.register_buffer('target_laterality', target_laterality)
        
        # Cosine schedule
        steps = torch.arange(0, n_timesteps + 1, dtype=torch.float32)
        ac = torch.cos(((steps / n_timesteps) + 0.008) / 1.008 * (np.pi / 2)) ** 2
        ac = ac / ac[0]
        betas = torch.clamp(1 - ac[1:] / ac[:-1], 1e-4, 0.02)
        
        self.register_buffer('beta', betas)
        self.register_buffer('alpha', 1 - betas)
        self.register_buffer('alpha_bar', torch.cumprod(self.alpha, 0))
        self.register_buffer('sqrt_ab', torch.sqrt(self.alpha_bar))
        self.register_buffer('sqrt_1_ab', torch.sqrt(1 - self.alpha_bar))
        
        # 损失函数模块
        self.erd_loss_fn = ERDLateralityLoss(fs=fs, n_fft=n_samples)
        self.spectral_loss_fn = SpectralLoss(fs=fs, n_fft=n_samples)
        
        # 冻结分类器
        for param in self.classifier.parameters():
            param.requires_grad = False
    
    def classifier_gradient(self, x: torch.Tensor, y: torch.Tensor, 
                           scale: float = 1.0) -> torch.Tensor:
        """
        计算分类器梯度用于引导
        
        Args:
            x: 输入数据 [B, C, T]
            y: 目标类别 [B]
            scale: 梯度缩放因子
            
        Returns:
            grad: 分类器梯度 [B, C, T]
            
        Requirements: 3.1
        """
        x_req = x.clone().requires_grad_(True)
        logits = self.classifier(x_req)
        log_probs = F.log_softmax(logits, dim=-1)
        selected = log_probs[torch.arange(len(y), device=y.device), y].sum()
        grad = torch.autograd.grad(selected, x_req)[0]
        return scale * grad
    
    def loss(self, x0: torch.Tensor, y: torch.Tensor,
             noise_weight: float = 1.0,
             spectral_weight: float = 1.0,
             erd_weight: float = 5.0,
             cls_weight: float = 5.0,
             low_t_threshold: int = 200) -> tuple:
        """
        计算组合损失
        
        Args:
            x0: 真实EEG数据 [B, C, T]
            y: 类别标签 [B]
            noise_weight: 噪声损失权重
            spectral_weight: 频谱损失权重
            erd_weight: ERD损失权重
            cls_weight: 分类损失权重
            low_t_threshold: 低噪声时间步阈值
            
        Returns:
            total_loss: 总损失 (标量)
            loss_dict: 各项损失字典
            
        Requirements: 2.2
        """
        B = x0.size(0)
        device = x0.device
        
        # 随机采样时间步
        t = torch.randint(0, self.n_timesteps, (B,), device=device)
        
        # 添加噪声
        eps = torch.randn_like(x0)
        x_t = self.sqrt_ab[t].view(B, 1, 1) * x0 + self.sqrt_1_ab[t].view(B, 1, 1) * eps
        
        # 预测噪声
        eps_pred = self.eps_model(x_t, t, y)
        
        # 噪声损失
        noise_loss = F.mse_loss(eps_pred, eps)
        
        # 在低噪声时间步计算其他损失
        low_t_mask = t < low_t_threshold
        
        if low_t_mask.sum() >= 4:
            # 预测x0
            x0_pred = (x_t[low_t_mask] - self.sqrt_1_ab[t[low_t_mask]].view(-1, 1, 1) * eps_pred[low_t_mask]) / \
                      (self.sqrt_ab[t[low_t_mask]].view(-1, 1, 1) + 1e-8)
            
            # 频谱损失
            spec_loss = self.spectral_loss_fn(x0_pred, self.target_psd)
            
            # ERD侧化损失
            erd_loss = self.erd_loss_fn(x0_pred, y[low_t_mask], self.target_laterality)
            
            # 分类损失
            logits = self.classifier(x0_pred)
            cls_loss = F.cross_entropy(logits, y[low_t_mask])
        else:
            spec_loss = torch.tensor(0.0, device=device)
            erd_loss = torch.tensor(0.0, device=device)
            cls_loss = torch.tensor(0.0, device=device)
        
        # 总损失
        total_loss = (noise_weight * noise_loss + 
                      spectral_weight * spec_loss + 
                      erd_weight * erd_loss + 
                      cls_weight * cls_loss)
        
        # 损失字典
        loss_dict = {
            'noise': noise_loss.item(),
            'spectral': spec_loss.item() if torch.is_tensor(spec_loss) else spec_loss,
            'erd': erd_loss.item() if torch.is_tensor(erd_loss) else erd_loss,
            'classification': cls_loss.item() if torch.is_tensor(cls_loss) else cls_loss,
            'total': total_loss.item()
        }
        
        return total_loss, loss_dict
    
    @torch.no_grad()
    def sample(self, batch_size: int, y: torch.Tensor, 
               guidance_scale: float = 2.0,
               device: str = None) -> torch.Tensor:
        """
        带分类器引导的采样
        
        Args:
            batch_size: 批次大小
            y: 目标类别 [B]
            guidance_scale: 引导强度 (0表示无引导)
            device: 设备
            
        Returns:
            samples: 生成的EEG数据 [B, C, T]
            
        Requirements: 3.1, 3.2, 3.3
        """
        if device is None:
            device = next(self.parameters()).device
        
        # 初始化噪声
        x = torch.randn(batch_size, self.channels, self.n_samples, device=device)
        
        # 反向扩散
        for ti in reversed(range(self.n_timesteps)):
            t = torch.full((batch_size,), ti, device=device, dtype=torch.long)
            
            # 预测噪声
            eps = self.eps_model(x, t, y)
            
            # 计算均值
            coef = self.beta[ti] / torch.sqrt(1 - self.alpha_bar[ti])
            mean = (x - coef * eps) / torch.sqrt(self.alpha[ti])
            
            # 添加分类器引导 (guidance_scale > 0 且不在最后几步)
            if guidance_scale > 0 and ti > 50:
                with torch.enable_grad():
                    grad = self.classifier_gradient(mean, y, scale=guidance_scale)
                mean = mean + self.beta[ti] * grad
            
            # 添加噪声 (除了最后一步)
            if ti > 0:
                x = mean + torch.sqrt(self.beta[ti]) * torch.randn_like(x)
            else:
                x = mean
        
        return x
    
    @torch.no_grad()
    def sample_ddim(self, batch_size: int, y: torch.Tensor,
                    steps: int = 50, guidance_scale: float = 2.0,
                    device: str = None) -> torch.Tensor:
        """
        DDIM快速采样 + 分类器引导
        
        Args:
            batch_size: 批次大小
            y: 目标类别 [B]
            steps: 采样步数 (默认50)
            guidance_scale: 引导强度
            device: 设备
            
        Returns:
            samples: 生成的EEG数据 [B, C, T]
        """
        if device is None:
            device = next(self.parameters()).device
        
        # 初始化噪声
        x = torch.randn(batch_size, self.channels, self.n_samples, device=device)
        
        # 时间步序列
        timesteps = torch.linspace(self.n_timesteps - 1, 0, steps, dtype=torch.long, device=device)
        
        for i, ti in enumerate(timesteps):
            t = torch.full((batch_size,), ti.item(), device=device, dtype=torch.long)
            
            # 预测噪声
            eps = self.eps_model(x, t, y)
            
            # 计算alpha_bar
            alpha_bar_t = self.alpha_bar[ti]
            alpha_bar_prev = self.alpha_bar[timesteps[i + 1]] if i < len(timesteps) - 1 else torch.tensor(1.0, device=device)
            
            # 预测x0
            x0_pred = (x - torch.sqrt(1 - alpha_bar_t) * eps) / torch.sqrt(alpha_bar_t)
            
            # 分类器引导
            if guidance_scale > 0 and ti > 50:
                with torch.enable_grad():
                    grad = self.classifier_gradient(x0_pred, y, scale=guidance_scale)
                x0_pred = x0_pred + grad * 0.1
            
            # DDIM更新
            x = torch.sqrt(alpha_bar_prev) * x0_pred + torch.sqrt(1 - alpha_bar_prev) * eps
        
        return x


# ============================================================================
# Evaluation Metrics Module
# ============================================================================

from scipy import signal
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.model_selection import cross_val_score


class EvaluationMetrics:
    """
    评估指标计算模块
    
    提供用于评估生成数据质量的各种指标。
    
    Requirements: 5.1, 5.2, 5.3, 5.5
    """
    
    def __init__(self, fs: int = 250, c3_idx: int = 7, c4_idx: int = 11):
        """
        Args:
            fs: 采样率 (Hz)
            c3_idx: C3通道索引
            c4_idx: C4通道索引
        """
        self.fs = fs
        self.c3_idx = c3_idx
        self.c4_idx = c4_idx
        
        # 频段定义
        self.bands = {
            'delta': (1, 4),
            'theta': (4, 8),
            'alpha': (8, 13),
            'beta': (13, 30)
        }
    
    def compute_laterality(self, data: np.ndarray) -> np.ndarray:
        """
        计算每个样本的侧化指数
        
        侧化指数 = (C4_alpha - C3_alpha) / (C4_alpha + C3_alpha + eps)
        
        Args:
            data: EEG数据 [N, C, T]
            
        Returns:
            laterality: 侧化指数 [N]
            
        Requirements: 5.1
        """
        N = data.shape[0]
        laterality = np.zeros(N)
        
        for i in range(N):
            # 计算C3和C4的alpha功率
            f, psd_c3 = signal.welch(data[i, self.c3_idx], fs=self.fs, nperseg=256)
            f, psd_c4 = signal.welch(data[i, self.c4_idx], fs=self.fs, nperseg=256)
            
            # Alpha频段掩码
            alpha_mask = (f >= 8) & (f <= 13)
            
            c3_alpha = psd_c3[alpha_mask].mean()
            c4_alpha = psd_c4[alpha_mask].mean()
            
            laterality[i] = (c4_alpha - c3_alpha) / (c4_alpha + c3_alpha + 1e-10)
        
        return laterality
    
    def compute_band_powers(self, data: np.ndarray) -> np.ndarray:
        """
        计算频段功率 (Delta, Theta, Alpha, Beta)
        
        Args:
            data: EEG数据 [N, C, T]
            
        Returns:
            band_powers: 频段功率 [N, 4] (Delta, Theta, Alpha, Beta)
            
        Requirements: 5.5
        """
        N = data.shape[0]
        band_powers = np.zeros((N, 4))
        
        for i in range(N):
            # 计算所有通道的平均PSD
            all_psd = []
            for ch in range(data.shape[1]):
                f, psd = signal.welch(data[i, ch], fs=self.fs, nperseg=256)
                all_psd.append(psd)
            avg_psd = np.mean(all_psd, axis=0)
            
            # 计算各频段功率
            for j, (band_name, (low, high)) in enumerate(self.bands.items()):
                mask = (f >= low) & (f <= high)
                band_powers[i, j] = avg_psd[mask].mean()
        
        return band_powers
    
    def compute_class_separability(self, features: np.ndarray, 
                                   labels: np.ndarray) -> float:
        """
        使用LDA计算类别可分性
        
        Args:
            features: 特征矩阵 [N, D]
            labels: 标签 [N]
            
        Returns:
            accuracy: LDA分类准确率
            
        Requirements: 5.2
        """
        lda = LinearDiscriminantAnalysis()
        lda.fit(features, labels)
        return lda.score(features, labels)
    
    def cross_validate_accuracy(self, real_feat: np.ndarray, 
                                real_labels: np.ndarray,
                                gen_feat: np.ndarray, 
                                gen_labels: np.ndarray) -> float:
        """
        交叉验证准确率：在真实数据上训练，在生成数据上测试
        
        Args:
            real_feat: 真实数据特征 [N_real, D]
            real_labels: 真实数据标签 [N_real]
            gen_feat: 生成数据特征 [N_gen, D]
            gen_labels: 生成数据标签 [N_gen]
            
        Returns:
            accuracy: 交叉验证准确率
            
        Requirements: 5.3
        """
        lda = LinearDiscriminantAnalysis()
        lda.fit(real_feat, real_labels)
        return lda.score(gen_feat, gen_labels)
    
    def extract_features(self, data: np.ndarray) -> np.ndarray:
        """
        提取用于分类的特征
        
        特征包括：
        - 每个通道的4个频段功率 (22 * 4 = 88)
        - C3-C4 alpha差异 (1)
        
        Args:
            data: EEG数据 [N, C, T]
            
        Returns:
            features: 特征矩阵 [N, 89]
        """
        N = data.shape[0]
        n_channels = data.shape[1]
        features = []
        
        for i in range(N):
            feat = []
            
            # 每个通道的频段功率
            for ch in range(n_channels):
                f, psd = signal.welch(data[i, ch], fs=self.fs, nperseg=256)
                for band_name, (low, high) in self.bands.items():
                    mask = (f >= low) & (f <= high)
                    feat.append(psd[mask].mean())
            
            # C3-C4 alpha差异
            f, psd_c3 = signal.welch(data[i, self.c3_idx], fs=self.fs, nperseg=256)
            f, psd_c4 = signal.welch(data[i, self.c4_idx], fs=self.fs, nperseg=256)
            alpha_mask = (f >= 8) & (f <= 13)
            feat.append(psd_c3[alpha_mask].mean() - psd_c4[alpha_mask].mean())
            
            features.append(feat)
        
        return np.array(features)
    
    def evaluate(self, real_data: np.ndarray, real_labels: np.ndarray,
                 gen_data: np.ndarray, gen_labels: np.ndarray,
                 num_classes: int = 4) -> dict:
        """
        完整评估
        
        Args:
            real_data: 真实EEG数据 [N_real, C, T]
            real_labels: 真实数据标签 [N_real]
            gen_data: 生成EEG数据 [N_gen, C, T]
            gen_labels: 生成数据标签 [N_gen]
            num_classes: 类别数量
            
        Returns:
            results: 评估结果字典
            
        Requirements: 5.1, 5.2, 5.3, 5.5
        """
        results = {}
        
        # 1. 每类侧化指数
        results['per_class_laterality'] = {}
        real_lat = self.compute_laterality(real_data)
        gen_lat = self.compute_laterality(gen_data)
        
        for cls in range(num_classes):
            real_cls_lat = real_lat[real_labels == cls].mean()
            gen_cls_lat = gen_lat[gen_labels == cls].mean()
            results['per_class_laterality'][cls] = {
                'real': float(real_cls_lat),
                'generated': float(gen_cls_lat)
            }
        
        # 2. 频段功率比
        real_powers = self.compute_band_powers(real_data)
        gen_powers = self.compute_band_powers(gen_data)
        
        real_power_mean = real_powers.mean(axis=0)
        gen_power_mean = gen_powers.mean(axis=0)
        
        results['band_power_ratios'] = {}
        for i, band_name in enumerate(self.bands.keys()):
            ratio = gen_power_mean[i] / (real_power_mean[i] + 1e-10)
            results['band_power_ratios'][band_name] = float(ratio)
        
        # 3. 提取特征
        real_feat = self.extract_features(real_data)
        gen_feat = self.extract_features(gen_data)
        
        # 4. LDA类别可分性
        results['lda_accuracy'] = {
            'real': float(self.compute_class_separability(real_feat, real_labels)),
            'generated': float(self.compute_class_separability(gen_feat, gen_labels))
        }
        
        # 5. 交叉验证准确率 (Real→Gen)
        results['cross_val_accuracy'] = float(
            self.cross_validate_accuracy(real_feat, real_labels, gen_feat, gen_labels)
        )
        
        return results

import math
import torch
import torch.nn as nn
import torch.nn.functional as F

# UNet++ 1D 版本（带时间步嵌入与可选类条件），接口与 UNet1D 兼容：
# forward(x, t, y=None) -> 预测噪声，与 x 同形状 [B, C, T]

def sinusoidal_embedding(timesteps: torch.Tensor, dim: int = 128, max_period: int = 10000):
    half = dim // 2
    device = timesteps.device
    t = timesteps.float()
    freqs = torch.exp(-math.log(max_period) * torch.arange(0, half, device=device).float() / half)
    args = t[:, None] * freqs[None]
    emb = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
    if dim % 2 == 1:
        emb = F.pad(emb, (0,1))
    return emb

class ConvBlock1D(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, t_dim: int):
        super().__init__()
        self.conv1 = nn.Conv1d(in_ch, out_ch, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(out_ch, out_ch, kernel_size=3, padding=1)
        self.emb = nn.Linear(t_dim, out_ch)
        self.norm1 = nn.BatchNorm1d(out_ch)
        self.norm2 = nn.BatchNorm1d(out_ch)
        self.act = nn.SiLU()
    def forward(self, x, t_emb):
        h = self.conv1(x)
        h = h + self.emb(t_emb).unsqueeze(-1)
        h = self.norm1(self.act(h))
        h = self.conv2(h)
        h = self.norm2(self.act(h))
        return h

class UNetPP1D(nn.Module):
    def __init__(self, in_channels: int, base: int = 64, t_dim: int = 128, num_classes: int = 0):
        super().__init__()
        self.num_classes = num_classes
        self.t_dim = t_dim + (num_classes if num_classes>0 else 0)
        self.in_proj = nn.Conv1d(in_channels, base, kernel_size=1)

        # 编码器主干 X_0_0, X_1_0, X_2_0
        self.x00 = ConvBlock1D(base, base, self.t_dim)
        self.down1 = nn.AvgPool1d(2)
        self.x10 = ConvBlock1D(base, base*2, self.t_dim)
        self.down2 = nn.AvgPool1d(2)
        self.x20 = ConvBlock1D(base*2, base*4, self.t_dim)

        # 解码/嵌套节点 X_0_1, X_1_1, X_0_2
        self.up = nn.Upsample(scale_factor=2, mode='linear', align_corners=False)
        self.x01 = ConvBlock1D(base + base*2, base, self.t_dim)
        self.x11 = ConvBlock1D(base*2 + base*4, base*2, self.t_dim)
        self.x02 = ConvBlock1D(base + base*2 + base*2, base, self.t_dim)

        self.out = nn.Conv1d(base, in_channels, kernel_size=1)

    def forward(self, x, t, y=None):
        # 时间步嵌入 + 可选类条件
        t_emb = sinusoidal_embedding(t, self.t_dim - (self.num_classes if self.num_classes>0 else 0))
        if self.num_classes>0 and y is not None:
            y_onehot = F.one_hot(y, num_classes=self.num_classes).float()
            t_emb = torch.cat([t_emb, y_onehot], dim=1)

        x_in = self.in_proj(x)
        # 编码层
        x_00 = self.x00(x_in, t_emb)
        x_10 = self.x10(self.down1(x_00), t_emb)
        x_20 = self.x20(self.down2(x_10), t_emb)

        # 嵌套解码
        up_10 = self.up(x_10)
        x_01 = self.x01(torch.cat([x_00, up_10], dim=1), t_emb)

        up_20 = self.up(x_20)
        x_11 = self.x11(torch.cat([x_10, up_20], dim=1), t_emb)

        up_11 = self.up(x_11)
        x_02 = self.x02(torch.cat([x_00, up_10, up_11], dim=1), t_emb)

        return self.out(x_02)

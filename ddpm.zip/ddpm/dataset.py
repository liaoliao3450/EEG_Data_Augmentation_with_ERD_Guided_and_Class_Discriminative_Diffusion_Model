import os
import numpy as np
import torch
from torch.utils.data import Dataset
from typing import List

class EEGNPYDataset(Dataset):
    def __init__(
        self,
        dataset_dir: str,
        split: str,
        window_size: int = 750,
        step: int = 0,
        random_seed: int = 42,
        train_ratio: float = 0.7,
        val_ratio: float = 0.15,
        include_tail: bool = True,
        no_sliding: bool = False,
    ) -> None:
        assert split in {"train", "val", "test"}
        x_path = os.path.join(dataset_dir, "X.npy")
        y_path = os.path.join(dataset_dir, "y.npy")
        if not (os.path.exists(x_path) and os.path.exists(y_path)):
            raise FileNotFoundError(f"找不到 {x_path} 或 {y_path}，请先运行 data_processing/preprocess_unified.py")

        X = np.load(x_path, allow_pickle=True)
        y = np.load(y_path, allow_pickle=True).astype(int)
        if X.ndim != 3:
            raise ValueError(f"期望 X 维度为 3，但得到 {X.shape}")
        if X.shape[0] != y.shape[0]:
            raise ValueError(f"样本数不匹配：X={X.shape[0]} vs y={y.shape[0]}")

        self.n_trials, self.n_channels, self.n_times = X.shape
        self.window_size = int(window_size)
        self.step = int(step)
        self.include_tail = include_tail

        # 分层划分 trial 索引
        rng = np.random.RandomState(random_seed)
        cls_to_idx: dict[int, List[int]] = {}
        for idx, cls in enumerate(y.tolist()):
            cls_to_idx.setdefault(int(cls), []).append(idx)
        train_idx, val_idx, test_idx = [], [], []
        for _, idxs in cls_to_idx.items():
            idxs = np.array(idxs)
            rng.shuffle(idxs)
            n = len(idxs)
            n_train = int(round(n * train_ratio))
            n_val = int(round(n * val_ratio))
            n_train = max(1, min(n_train, n - 2)) if n >= 3 else max(1, n - 1)
            n_val = max(1, min(n_val, n - n_train - 1)) if n >= 3 else 1
            n_test = n - n_train - n_val
            if n_test <= 0:
                n_test = 1
                if n_val > 1:
                    n_val -= 1
                elif n_train > 1:
                    n_train -= 1
            train_idx.extend(idxs[:n_train].tolist())
            val_idx.extend(idxs[n_train:n_train + n_val].tolist())
            test_idx.extend(idxs[n_train + n_val:].tolist())

        split_to_indices = {"train": train_idx, "val": val_idx, "test": test_idx}
        self.sel_trials = np.array(split_to_indices[split], dtype=int)

        # 保存原始 trial 级数据与统计
        self.trial_data = X.astype(np.float32)[self.sel_trials]  # [N_sel, C, T]
        self.trial_labels = y.astype(np.int64)[self.sel_trials]
        self.n_channels = self.trial_data.shape[1]
        self.n_times = self.trial_data.shape[2]
        self.trial_mean = self.trial_data.mean(axis=2, keepdims=True)  # [N_sel, C, 1]
        self.trial_std = self.trial_data.std(axis=2, keepdims=True)
        self.trial_std[self.trial_std < 1e-8] = 1e-8

        # 构建窗口索引 (trial_idx_in_split, start, end)
        self.windows: list[tuple[int, int, int]] = []
        for ti in range(self.trial_data.shape[0]):
            T = self.trial_data.shape[2]
            if no_sliding:
                # 非滑窗模式：每个 trial 一个整段窗口
                self.windows.append((ti, 0, T))
                continue
            if self.window_size >= T:
                self.windows.append((ti, 0, T))
                continue
            pos = 0
            while pos + self.window_size <= T:
                self.windows.append((ti, pos, pos + self.window_size))
                pos += self.step
            if self.include_tail and pos < T:
                # 最后一段尾巴：对齐到末尾
                self.windows.append((ti, T - self.window_size, T))

    def __len__(self) -> int:
        return len(self.windows)

    def __getitem__(self, i):
        ti, s, e = self.windows[i]
        x = self.trial_data[ti, :, s:e]  # [C, L]
        # 统一按 trial 统计做 z-score，便于后续重建
        mean = torch.from_numpy(self.trial_mean[ti])  # [C,1]
        std = torch.from_numpy(self.trial_std[ti])
        x_t = torch.from_numpy(x)
        x_t = (x_t - mean) / std
        # 若为尾段且长度小于 window_size，后端零填充（模型固定长度）
        if x_t.size(1) < self.window_size:
            pad = self.window_size - x_t.size(1)
            x_t = torch.nn.functional.pad(x_t, (0, pad))
        y = int(self.trial_labels[ti])
        return x_t, y

    # 提供重建所需的元信息
    def get_trial_window_indices(self, trial_idx_in_split: int) -> list[int]:
        idxs = []
        for i, (ti, _, _) in enumerate(self.windows):
            if ti == trial_idx_in_split:
                idxs.append(i)
        return idxs

    def get_window_spans(self, indices: list[int]) -> list[tuple[int,int,int]]:
        return [self.windows[i] for i in indices]

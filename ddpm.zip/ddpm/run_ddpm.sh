#!/usr/bin/env bash
set -euo pipefail

# DDPM 单独运行脚本：训练 -> 评估
# 用法：
#   chmod +x run_ddpm.sh
#   ./run_ddpm.sh                          # 使用默认参数
#   DATASET_KEY=bci2b SUBJECT=B0102T ./run_ddpm.sh
#   DDPM_COND=0 ./run_ddpm.sh              # 关闭条件 DDPM

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

# 参数默认（可被环境变量覆盖）
DATASET_KEY="${DATASET_KEY:-bci2a}"
SUBJECT="${SUBJECT:-A01E}"
EPOCHS="${EPOCHS:-100}"
BATCH="${BATCH:-32}"
EVAL_SAMPLES="${EVAL_SAMPLES:-288}"
N_STEPS="${N_STEPS:-1000}"
NO_SLIDING="${NO_SLIDING:-1}"

# 条件 DDPM 开关（1: 条件；0: 无条件）
DDPM_COND="${DDPM_COND:-1}"

# 选择 python
if command -v python >/dev/null 2>&1; then PY=python
elif command -v python3 >/dev/null 2>&1; then PY=python3
else
  echo "未找到 python/python3" >&2; exit 1
fi

banner() { echo; echo "==== $* ===="; }
latest_ckpt() { local dir="$1" pattern="$2"; ls -1t "$dir"/$pattern 2>/dev/null | head -n 1 || true; }

banner "DDPM: 训练"
DDPM_EXTRA=""
if [ "$DDPM_COND" = "1" ]; then DDPM_EXTRA="--conditional --num_classes -1 --cond_embed_dim 32"; fi

$PY -u Model_ddpm/train_ddpm.py \
  --mode train \
  --dataset_key "$DATASET_KEY" --subject "$SUBJECT" \
  --epochs "$EPOCHS" --batch_size "$BATCH" \
  --n_steps "$N_STEPS" --save_every 10 --ckpt_dir checkpoints_ddpm \
  $DDPM_EXTRA $( [ "$NO_SLIDING" = "1" ] && echo --no_sliding )

CKPT=$(latest_ckpt checkpoints_ddpm 'ddpm_epoch_*.pt')
if [ -z "$CKPT" ]; then echo "未找到 DDPM ckpt" >&2; exit 1; fi

banner "DDPM: 评估 ($CKPT)"
$PY -u Model_ddpm/train_ddpm.py \
  --mode evaluate \
  --dataset_key "$DATASET_KEY" --subject "$SUBJECT" \
  --ckpt "$CKPT" $DDPM_EXTRA \
  --eval_samples "$EVAL_SAMPLES" \
  --viz_psd --viz_tsne --viz_erd --erd_band mu \
  --viz_wave --viz_wave_channel 0 --viz_wave_n 4 --viz_wave_t_start 0 --viz_wave_t_stop 750 \
  --eval_disc_pred --eval_cls_utility --cls_model eegnet --cls_epochs 3 --viz_confmat \
  $( [ "$NO_SLIDING" = "1" ] && echo --no_sliding ) || true

echo
echo "DDPM 运行完成。评估结果目录: results/ddpm_eval"



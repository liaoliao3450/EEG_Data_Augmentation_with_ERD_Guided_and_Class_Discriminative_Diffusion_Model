#!/usr/bin/env python3
"""
DDPM数据增强（去噪版本，只生成t=200）
"""
import sys
import os
from pathlib import Path
import torch
import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT / 'core' / 'models' / 'ddpm'))
sys.path.insert(0, str(PROJECT_ROOT / 'utils'))

from class_discriminative import ClassDiscriminativeDDPM, MultiScaleCondUNet, EEGClassifier
from data_loader import load_bci2a_data

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def load_ddpm_model():
    checkpoint_path = 'checkpoints/best_class_discriminative.pt'
    checkpoint = torch.load(checkpoint_path, map_location=DEVICE)
    
    eps_model = MultiScaleCondUNet(channels=22, num_classes=4).to(DEVICE)
    classifier = EEGClassifier(channels=22, n_samples=1000, num_classes=4).to(DEVICE)
    target_psd = torch.zeros(501).to(DEVICE)
    target_laterality = torch.zeros(4).to(DEVICE)
    
    ddpm = ClassDiscriminativeDDPM(
        eps_model=eps_model, classifier=classifier,
        target_psd=target_psd, target_laterality=target_laterality,
        n_timesteps=1000, channels=22, n_samples=1000, fs=250
    ).to(DEVICE)
    
    if isinstance(checkpoint, dict) and 'model' in checkpoint:
        ddpm.load_state_dict(checkpoint['model'])
    else:
        ddpm.load_state_dict(checkpoint)
    
    ddpm.eval()
    return ddpm

def augment_batch(ddpm, X_batch, y_batch, noise_level=200):
    with torch.no_grad():
        t = torch.full((len(X_batch),), noise_level, device=DEVICE, dtype=torch.long)
        sqrt_ab = ddpm.sqrt_ab[t].view(-1, 1, 1)
        sqrt_1_ab = ddpm.sqrt_1_ab[t].view(-1, 1, 1)
        
        noise = torch.randn_like(X_batch)
        x_noisy = sqrt_ab * X_batch + sqrt_1_ab * noise
        
        steps = 50
        timesteps = torch.linspace(noise_level, 0, steps, dtype=torch.long, device=DEVICE)
        
        x = x_noisy
        for j, ti in enumerate(timesteps[:-1]):
            t_batch = torch.full((len(X_batch),), ti.item(), device=DEVICE, dtype=torch.long)
            eps = ddpm.eps_model(x, t_batch, y_batch)
            
            t_next = timesteps[j + 1]
            alpha_bar_t = ddpm.alpha_bar[t_batch].view(-1, 1, 1)
            alpha_bar_t_next = ddpm.alpha_bar[t_next].view(-1, 1, 1) if t_next > 0 else torch.ones_like(alpha_bar_t)
            
            x0_pred = (x - torch.sqrt(1 - alpha_bar_t) * eps) / torch.sqrt(alpha_bar_t)
            x = torch.sqrt(alpha_bar_t_next) * x0_pred + torch.sqrt(1 - alpha_bar_t_next) * eps
        
        return x.cpu().numpy()

def main():
    print("DDPM去噪增强 (t=200)")
    
    X, y, subjects, sessions = load_bci2a_data()
    session1_mask = sessions == 0
    X_session1 = X[session1_mask]
    y_session1 = y[session1_mask]
    subjects_session1 = subjects[session1_mask]
    
    print(f"Session 1数据: {X_session1.shape}")
    
    ddpm = load_ddpm_model()
    print("模型加载完成")
    
    X_augmented_list = []
    batch_size = 32
    
    for i in range(0, len(X_session1), batch_size):
        end_idx = min(i + batch_size, len(X_session1))
        X_batch = torch.FloatTensor(X_session1[i:end_idx]).to(DEVICE)
        y_batch = torch.LongTensor(y_session1[i:end_idx]).to(DEVICE)
        
        X_aug = augment_batch(ddpm, X_batch, y_batch, noise_level=200)
        X_augmented_list.append(X_aug)
        
        if (i // batch_size + 1) % 20 == 0:
            print(f"进度: {i+len(X_batch)}/{len(X_session1)}")
    
    X_augmented = np.concatenate(X_augmented_list, axis=0)
    
    os.makedirs('outputs/ddpm_samples', exist_ok=True)
    np.save('outputs/ddpm_samples/ddpm_denoising_augmented_session1.npy', X_augmented)
    np.save('outputs/ddpm_samples/ddpm_denoising_augmented_labels.npy', y_session1)
    np.save('outputs/ddpm_samples/ddpm_denoising_augmented_subjects.npy', subjects_session1)
    
    print(f"\n完成！增强样本: {X_augmented.shape}")
    print(f"数据范围: [{X_augmented.min():.3f}, {X_augmented.max():.3f}]")
    print("已保存到: outputs/ddpm_samples/ddpm_denoising_augmented_session1.npy")

    # 额外：为t-SNE可视化保存去噪版本缓存（如需使用可在配置中手动添加方法名）
    tsne_cache_dir = 'outputs/figures/tsne/cached_data'
    os.makedirs(tsne_cache_dir, exist_ok=True)
    tsne_cache_path = os.path.join(tsne_cache_dir, 'ddpm_denoising_data.npz')
    np.savez(tsne_cache_path, X=X_augmented, y=y_session1)
    print(f"t-SNE去噪缓存: {tsne_cache_path}")

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""
全局配置文件
"""
import os

# 数据路径配置
# 原始数据路径（.mat文件）
RAW_DATA_PATH = r'E:\data\BCI2a'

# 处理后的数据路径（.npy文件）
DATA_PATH = 'data/processed/BCI2a'

# 检查处理后的数据是否存在
if not os.path.exists(os.path.join(DATA_PATH, 'X.npy')):
    print(f"⚠️  警告: 处理后的数据不存在: {DATA_PATH}")
    print(f"   原始数据路径: {RAW_DATA_PATH}")
    print(f"   请先运行数据预处理脚本")
else:
    pass  # 数据存在，正常加载

# 模型配置
MODEL_CONFIG = {
    'channels': 22,
    'n_samples': 1000,
    'num_classes': 4,
    'timesteps': 1000,
}

# 训练配置
TRAIN_CONFIG = {
    'classifier_epochs': 100,
    'ddpm_epochs': 500,
    'batch_size': 32,
    'learning_rate': 1e-3,
    'device': 'cuda',  # 'cuda' or 'cpu'
}

# DDPM权重配置
DDPM_WEIGHTS = {
    'erd_weight': 0.5,
    'cls_weight': 1.0,
    'noise_weight': 1.0,
    'spectral_weight': 0.5,
}

# 生成配置
GENERATION_CONFIG = {
    'guidance_scale': 3.0,
    'ddim_steps': 50,
}

# 数据集配置
DATASET_CONFIG = {
    'n_subjects': 9,
    'n_sessions': 2,
    'n_classes': 4,
    'trials_per_session': 288,
}

# 输出路径
OUTPUT_PATHS = {
    'checkpoints': 'checkpoints',
    'results': 'outputs/results',
    'figures': 'outputs/figures',
    'generated_data': 'outputs/generated_data',
}

# 创建输出目录
for path in OUTPUT_PATHS.values():
    os.makedirs(path, exist_ok=True)

# 只在直接运行此脚本时打印配置信息，避免每次导入时重复打印
if __name__ == "__main__":
    print("配置加载完成")
    print(f"   处理后数据路径: {DATA_PATH}")
    print(f"   原始数据路径: {RAW_DATA_PATH}")

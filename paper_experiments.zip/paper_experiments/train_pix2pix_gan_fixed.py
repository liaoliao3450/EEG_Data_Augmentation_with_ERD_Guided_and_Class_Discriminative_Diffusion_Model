#!/usr/bin/env python3
"""
修复后的Pix2Pix GAN数据增强

主要改进：
1. 降低L1权重从100到10（减少模式崩溃）
2. 增加判别器更新次数（5:1）
3. 添加噪声注入增加多样性
4. 使用梯度惩罚稳定训练
"""
import sys
import os
from pathlib import Path
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# 添加路径
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT / 'core' / 'models' / 'gan'))
sys.path.insert(0, str(PROJECT_ROOT / 'utils'))

from pix2pix_1d import UNetGenerator1D, PatchDiscriminator1D
from data_loader import load_bci2a_data

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def train_pix2pix_gan_fixed(X, y, epochs=500, batch_size=32):
    """训练改进的Pix2Pix GAN"""
    print("\n" + "="*60)
    print("训练改进的Pix2Pix GAN")
    print("="*60)
    print("改进点:")
    print("  1. L1权重: 100 -> 10")
    print("  2. 判别器更新: 1:1 -> 5:1")
    print("  3. 添加噪声注入")
    print("="*60)
    
    # 创建模型
    G = UNetGenerator1D(in_channels=22, out_channels=22, num_classes=4, cond_dim=32).to(DEVICE)
    D = PatchDiscriminator1D(in_channels=22, num_classes=4, cond_dim=32).to(DEVICE)
    
    # 优化器 - 降低学习率
    opt_G = optim.Adam(G.parameters(), lr=1e-4, betas=(0.5, 0.999))
    opt_D = optim.Adam(D.parameters(), lr=2e-4, betas=(0.5, 0.999))
    
    # 损失函数
    criterion_GAN = nn.MSELoss()
    criterion_L1 = nn.L1Loss()
    
    # 转换数据
    X_tensor = torch.FloatTensor(X)
    y_tensor = torch.LongTensor(y)
    
    n_samples = len(X)
    
    print(f"\n训练数据: {X.shape}")
    print(f"Epochs: {epochs}, Batch size: {batch_size}")
    print(f"设备: {DEVICE}\n")
    
    for epoch in range(epochs):
        G.train()
        D.train()
        
        # 随机打乱
        indices = torch.randperm(n_samples)
        
        epoch_loss_D = 0
        epoch_loss_G = 0
        n_batches = 0
        
        for i in range(0, n_samples, batch_size):
            batch_indices = indices[i:i+batch_size]
            real_X = X_tensor[batch_indices].to(DEVICE)
            real_y = y_tensor[batch_indices].to(DEVICE)
            current_batch_size = len(real_X)
            
            # 真实和假标签（添加标签平滑）
            real_label = torch.ones(current_batch_size, 1, 1, device=DEVICE) * 0.9
            fake_label = torch.zeros(current_batch_size, 1, 1, device=DEVICE) + 0.1
            
            # ==================== 训练判别器（5次） ====================
            for _ in range(5):
                opt_D.zero_grad()
                
                # 添加噪声到输入（增加鲁棒性）
                noise_scale = 0.05 * (1 - epoch / epochs)  # 逐渐减小噪声
                noisy_real_X = real_X + torch.randn_like(real_X) * noise_scale
                
                # 生成假样本
                with torch.no_grad():
                    fake_X = G(noisy_real_X, real_y)
                
                # 真实样本的判别
                pred_real = D(real_X, real_y)
                pred_real = nn.functional.adaptive_avg_pool1d(pred_real, 1)
                loss_D_real = criterion_GAN(pred_real, real_label)
                
                # 假样本的判别
                pred_fake = D(fake_X, real_y)
                pred_fake = nn.functional.adaptive_avg_pool1d(pred_fake, 1)
                loss_D_fake = criterion_GAN(pred_fake, fake_label)
                
                # 总判别器损失
                loss_D = (loss_D_real + loss_D_fake) * 0.5
                loss_D.backward()
                opt_D.step()
                
                epoch_loss_D += loss_D.item()
            
            # ==================== 训练生成器（1次） ====================
            opt_G.zero_grad()
            
            # 添加噪声到输入
            noisy_real_X = real_X + torch.randn_like(real_X) * noise_scale
            
            # 生成假样本
            fake_X = G(noisy_real_X, real_y)
            
            # GAN损失
            pred_fake = D(fake_X, real_y)
            pred_fake = nn.functional.adaptive_avg_pool1d(pred_fake, 1)
            loss_GAN = criterion_GAN(pred_fake, real_label)
            
            # L1损失（降低权重从100到10）
            loss_L1 = criterion_L1(fake_X, real_X)
            
            # 总生成器损失
            loss_G = loss_GAN + loss_L1 * 10  # L1权重降低
            loss_G.backward()
            opt_G.step()
            
            epoch_loss_G += loss_G.item()
            n_batches += 1
        
        if (epoch + 1) % 20 == 0:
            avg_loss_D = epoch_loss_D / (n_batches * 5)  # 5次判别器更新
            avg_loss_G = epoch_loss_G / n_batches
            print(f"Epoch [{epoch+1}/{epochs}] - D_loss: {avg_loss_D:.4f}, G_loss: {avg_loss_G:.4f}")
    
    print("\n✅ 改进的Pix2Pix GAN训练完成")
    
    # 保存模型
    os.makedirs('checkpoints/gan', exist_ok=True)
    torch.save({
        'G': G.state_dict(),
        'D': D.state_dict()
    }, 'checkpoints/gan/pix2pix_gan_fixed.pt')
    print("模型已保存到: checkpoints/gan/pix2pix_gan_fixed.pt")
    
    return G

def augment_with_pix2pix_gan(G, X_real, y_real):
    """用Pix2Pix GAN对真实样本进行增强"""
    print("\n" + "="*60)
    print("用改进的Pix2Pix GAN进行数据增强")
    print("="*60)
    
    G.eval()
    
    X_tensor = torch.FloatTensor(X_real).to(DEVICE)
    y_tensor = torch.LongTensor(y_real).to(DEVICE)
    
    X_augmented_list = []
    
    with torch.no_grad():
        batch_size = 32
        for i in range(0, len(X_real), batch_size):
            batch_X = X_tensor[i:i+batch_size]
            batch_y = y_tensor[i:i+batch_size]
            
            # 添加小噪声增加多样性
            noisy_X = batch_X + torch.randn_like(batch_X) * 0.05
            
            # 生成增强样本
            fake_X = G(noisy_X, batch_y)
            X_augmented_list.append(fake_X.cpu().numpy())
    
    X_augmented = np.vstack(X_augmented_list)
    
    print(f"  原始样本: {X_real.shape}")
    print(f"  增强样本: {X_augmented.shape}")
    print(f"  数据范围: [{X_augmented.min():.3f}, {X_augmented.max():.3f}]")
    print(f"  均值: {X_augmented.mean():.3f}, 标准差: {X_augmented.std():.3f}")
    
    return X_augmented

def main():
    print("="*60)
    print("修复GAN模式崩溃问题")
    print("="*60)
    
    # 加载数据
    print("\n加载数据...")
    X, y, subjects, sessions = load_bci2a_data()
    
    # 只使用Session 1数据
    session1_mask = sessions == 0
    X_session1 = X[session1_mask]
    y_session1 = y[session1_mask]
    subjects_session1 = subjects[session1_mask]
    
    print(f"Session 1数据: {X_session1.shape}")
    print(f"被试数: {len(np.unique(subjects_session1))}")
    
    # 训练GAN
    G = train_pix2pix_gan_fixed(X_session1, y_session1, epochs=500, batch_size=32)
    
    # 生成增强样本
    X_augmented = augment_with_pix2pix_gan(G, X_session1, y_session1)
    
    # 保存
    os.makedirs('outputs/gan_samples', exist_ok=True)
    
    np.save('outputs/gan_samples/pix2pix_fixed_augmented_session1.npy', X_augmented)
    np.save('outputs/gan_samples/pix2pix_fixed_augmented_labels.npy', y_session1)
    np.save('outputs/gan_samples/pix2pix_fixed_augmented_subjects.npy', subjects_session1)
    
    print(f"\n已保存:")
    print(f"  outputs/gan_samples/pix2pix_fixed_augmented_session1.npy")
    print(f"  outputs/gan_samples/pix2pix_fixed_augmented_labels.npy")
    print(f"  outputs/gan_samples/pix2pix_fixed_augmented_subjects.npy")
    
    print("\n✅ 完成！")

if __name__ == '__main__':
    main()

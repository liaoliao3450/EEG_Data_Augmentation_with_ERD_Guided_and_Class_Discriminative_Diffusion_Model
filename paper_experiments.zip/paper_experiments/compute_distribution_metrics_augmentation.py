#!/usr/bin/env python3
"""
计算分布质量定量指标（数据增强论文）

计算以下指标：
1. Separation Ratio = inter-class distance / intra-class distance
2. Maximum Mean Discrepancy (MMD)
3. Fréchet Inception Distance (FID)
4. Silhouette Score
"""
import sys
from pathlib import Path
import numpy as np
from sklearn.metrics import silhouette_score
import torch
import torch.nn as nn

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT / 'utils'))
sys.path.insert(0, str(PROJECT_ROOT / 'core/classifiers'))

from data_loader import load_bci2a_data
from eegnet import EEGNet

def extract_features_eegnet(X, model_path='checkpoints/pretrained_classifier.pt'):
    """
    使用预训练的EEGNet提取特征
    
    Args:
        X: EEG数据 (n_samples, n_channels, n_timepoints)
        model_path: 预训练模型路径
    
    Returns:
        features: 提取的特征 (n_samples, feature_dim)
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # 加载预训练的EEGNet
    try:
        model = EEGNet(n_classes=4, n_channels=22, n_samples=1000)
        checkpoint = torch.load(model_path, map_location=device)
        
        if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
            model.load_state_dict(checkpoint['model_state_dict'])
        else:
            model.load_state_dict(checkpoint)
        
        model = model.to(device)
        model.eval()
        
        print(f"✓ 加载预训练EEGNet: {model_path}")
        
    except Exception as e:
        print(f"⚠️  无法加载预训练模型: {e}")
        print("使用随机初始化的EEGNet...")
        model = EEGNet(n_classes=4, n_channels=22, n_samples=1000).to(device)
        model.eval()
    
    # 提取特征（使用最后一层之前的输出）
    features_list = []
    
    # 修改模型以输出特征
    feature_extractor = nn.Sequential(*list(model.children())[:-1])  # 移除最后的分类层
    
    with torch.no_grad():
        batch_size = 64
        for i in range(0, len(X), batch_size):
            batch = X[i:i+batch_size]
            batch_tensor = torch.FloatTensor(batch).unsqueeze(1).to(device)  # (batch, 1, channels, time)
            
            features = feature_extractor(batch_tensor)
            features = features.view(features.size(0), -1)  # Flatten
            features_list.append(features.cpu().numpy())
    
    features = np.concatenate(features_list, axis=0)
    print(f"提取的特征维度: {features.shape}")
    
    return features

def compute_separation_ratio(features, labels):
    """
    计算类别分离比 = 类间距离 / 类内距离
    
    Args:
        features: 特征 (n_samples, feature_dim)
        labels: 标签 (n_samples,)
    
    Returns:
        separation_ratio: 分离比（越大越好）
        intra_class_dist: 类内距离
        inter_class_dist: 类间距离
    """
    n_classes = len(np.unique(labels))
    
    # 计算类内距离（平均）
    intra_class_dist = 0
    for c in range(n_classes):
        mask = labels == c
        X_c = features[mask]
        
        if len(X_c) > 1:
            center = X_c.mean(axis=0)
            dist = np.mean(np.linalg.norm(X_c - center, axis=1))
            intra_class_dist += dist
    
    intra_class_dist /= n_classes
    
    # 计算类间距离（平均）
    centers = []
    for c in range(n_classes):
        mask = labels == c
        X_c = features[mask]
        if len(X_c) > 0:
            centers.append(X_c.mean(axis=0))
    
    inter_class_dist = 0
    count = 0
    for i in range(len(centers)):
        for j in range(i+1, len(centers)):
            inter_class_dist += np.linalg.norm(centers[i] - centers[j])
            count += 1
    
    if count > 0:
        inter_class_dist /= count
    
    # 分离比
    separation_ratio = inter_class_dist / intra_class_dist if intra_class_dist > 0 else 0
    
    return separation_ratio, intra_class_dist, inter_class_dist

def compute_mmd(X, Y, kernel='rbf', gamma=None):
    """
    计算Maximum Mean Discrepancy (MMD)
    
    Args:
        X: 第一个分布的样本 (n_samples_X, feature_dim)
        Y: 第二个分布的样本 (n_samples_Y, feature_dim)
        kernel: 核函数类型 ('rbf' or 'linear')
        gamma: RBF核的参数
    
    Returns:
        mmd: MMD值（越小表示两个分布越相似）
    """
    if gamma is None:
        gamma = 1.0 / X.shape[1]
    
    def rbf_kernel(X, Y, gamma):
        """RBF核函数"""
        XX = np.sum(X**2, axis=1)[:, np.newaxis]
        YY = np.sum(Y**2, axis=1)[np.newaxis, :]
        XY = np.dot(X, Y.T)
        distances = XX + YY - 2*XY
        return np.exp(-gamma * distances)
    
    if kernel == 'rbf':
        XX = rbf_kernel(X, X, gamma)
        YY = rbf_kernel(Y, Y, gamma)
        XY = rbf_kernel(X, Y, gamma)
    else:  # linear kernel
        XX = np.dot(X, X.T)
        YY = np.dot(Y, Y.T)
        XY = np.dot(X, Y.T)
    
    mmd = np.mean(XX) + np.mean(YY) - 2*np.mean(XY)
    
    return max(0, mmd)  # MMD应该非负

def compute_fid(X_real, X_generated):
    """
    计算Fréchet Inception Distance (FID)
    
    Args:
        X_real: 真实样本特征 (n_samples, feature_dim)
        X_generated: 生成样本特征 (n_samples, feature_dim)
    
    Returns:
        fid: FID值（越小越好）
    """
    # 计算均值和协方差
    mu_real = np.mean(X_real, axis=0)
    mu_gen = np.mean(X_generated, axis=0)
    
    sigma_real = np.cov(X_real, rowvar=False)
    sigma_gen = np.cov(X_generated, rowvar=False)
    
    # 计算均值差的平方
    diff = mu_real - mu_gen
    mean_diff = np.sum(diff**2)
    
    # 计算协方差的矩阵平方根
    from scipy.linalg import sqrtm
    covmean = sqrtm(sigma_real @ sigma_gen)
    
    # 处理数值误差
    if np.iscomplexobj(covmean):
        covmean = covmean.real
    
    # 计算FID
    fid = mean_diff + np.trace(sigma_real + sigma_gen - 2*covmean)
    
    return fid

def compute_all_metrics():
    """计算所有分布质量指标"""
    
    print("="*60)
    print("计算分布质量指标（数据增强）")
    print("="*60)
    
    # ==================== 加载真实数据 ====================
    print("\n加载真实数据...")
    X, y, subjects, sessions = load_bci2a_data()
    
    # 使用Subject 1 Session 1的数据
    subject1_session1_mask = (subjects == 0) & (sessions == 0)
    X_real = X[subject1_session1_mask]
    y_real = y[subject1_session1_mask]
    
    print(f"真实数据: {X_real.shape}")
    
    # ==================== 提取特征 ====================
    print("\n使用EEGNet提取特征...")
    features_real = extract_features_eegnet(X_real)
    
    # ==================== 计算真实数据的指标 ====================
    print("\n计算真实数据的指标...")
    sep_ratio_real, intra_real, inter_real = compute_separation_ratio(features_real, y_real)
    sil_real = silhouette_score(features_real, y_real)
    
    print(f"\n真实数据:")
    print(f"  Separation Ratio: {sep_ratio_real:.4f}")
    print(f"  Intra-class Distance: {intra_real:.4f}")
    print(f"  Inter-class Distance: {inter_real:.4f}")
    print(f"  Silhouette Score: {sil_real:.4f}")
    
    # ==================== 加载增强样本并计算指标 ====================
    methods = {
        'DDPM (Ours)': 'outputs/ddpm_samples/ddpm_denoising_augmented_session1.npy',
        'VAE': 'outputs/vae_samples/vae_augmented_session1.npy',
        'GAN': 'outputs/gan_samples/pix2pix_augmented_session1.npy',
        'Gaussian': 'outputs/gaussian_samples/gaussian_large_augmented_session1.npy',
        'SMOTE': 'outputs/smote_samples/smote_augmented_session1.npy',
    }
    
    results = {
        'Method': ['Real Data'],
        'Sep. Ratio↑': [f'{sep_ratio_real:.4f}'],
        'Intra-Dist↓': [f'{intra_real:.2f}'],
        'Inter-Dist↑': [f'{inter_real:.2f}'],
        'MMD↓': ['-'],
        'FID↓': ['-'],
        'Silhouette↑': [f'{sil_real:.4f}']
    }
    
    for method_name, filepath in methods.items():
        print(f"\n{'='*60}")
        print(f"处理: {method_name}")
        print(f"{'='*60}")
        
        try:
            # 加载增强样本
            X_aug = np.load(filepath)
            
            # 获取对应的标签
            labels_file = filepath.replace('_session1.npy', '_labels.npy')
            y_aug = np.load(labels_file)
            
            # 获取Subject 1的样本
            subjects_file = filepath.replace('_session1.npy', '_subjects.npy')
            subjects_aug = np.load(subjects_file)
            mask = subjects_aug == 0
            
            X_aug = X_aug[mask]
            y_aug = y_aug[mask]
            
            print(f"增强数据: {X_aug.shape}")
            
            # 提取特征
            print("提取特征...")
            features_aug = extract_features_eegnet(X_aug)
            
            # 计算指标
            print("计算指标...")
            
            # 1. Separation Ratio
            sep_ratio, intra_dist, inter_dist = compute_separation_ratio(features_aug, y_aug)
            
            # 2. MMD (与真实数据比较)
            mmd = compute_mmd(features_real, features_aug)
            
            # 3. FID (与真实数据比较)
            fid = compute_fid(features_real, features_aug)
            
            # 4. Silhouette Score
            sil_score = silhouette_score(features_aug, y_aug)
            
            # 保存结果
            results['Method'].append(method_name)
            results['Sep. Ratio↑'].append(f'{sep_ratio:.4f}')
            results['Intra-Dist↓'].append(f'{intra_dist:.2f}')
            results['Inter-Dist↑'].append(f'{inter_dist:.2f}')
            results['MMD↓'].append(f'{mmd:.4f}')
            results['FID↓'].append(f'{fid:.2f}')
            results['Silhouette↑'].append(f'{sil_score:.4f}')
            
            print(f"\n结果:")
            print(f"  Separation Ratio: {sep_ratio:.4f} (Real: {sep_ratio_real:.4f})")
            print(f"  Intra-class Distance: {intra_dist:.2f} (Real: {intra_real:.2f})")
            print(f"  Inter-class Distance: {inter_dist:.2f} (Real: {inter_real:.2f})")
            print(f"  MMD: {mmd:.4f}")
            print(f"  FID: {fid:.2f}")
            print(f"  Silhouette Score: {sil_score:.4f} (Real: {sil_real:.4f})")
            
        except Exception as e:
            print(f"⚠️  处理失败: {e}")
            results['Method'].append(method_name)
            results['Sep. Ratio↑'].append('N/A')
            results['Intra-Dist↓'].append('N/A')
            results['Inter-Dist↑'].append('N/A')
            results['MMD↓'].append('N/A')
            results['FID↓'].append('N/A')
            results['Silhouette↑'].append('N/A')
    
    # ==================== 打印结果表格 ====================
    print("\n" + "="*80)
    print("分布质量指标汇总")
    print("="*80)
    
    # 打印表格
    header = f"{'Method':<20} {'Sep.Ratio↑':<12} {'Intra↓':<10} {'Inter↑':<10} {'MMD↓':<10} {'FID↓':<10} {'Sil↑':<10}"
    print(header)
    print("-"*80)
    
    for i in range(len(results['Method'])):
        row = f"{results['Method'][i]:<20} "
        row += f"{results['Sep. Ratio↑'][i]:<12} "
        row += f"{results['Intra-Dist↓'][i]:<10} "
        row += f"{results['Inter-Dist↑'][i]:<10} "
        row += f"{results['MMD↓'][i]:<10} "
        row += f"{results['FID↓'][i]:<10} "
        row += f"{results['Silhouette↑'][i]:<10}"
        print(row)
    
    # ==================== 保存结果 ====================
    import os
    import json
    
    os.makedirs('outputs/metrics', exist_ok=True)
    
    # 保存为JSON
    json_path = 'outputs/metrics/distribution_quality_metrics.json'
    with open(json_path, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\n✓ 结果已保存: {json_path}")
    
    # 保存为LaTeX表格
    latex_path = 'outputs/metrics/distribution_quality_metrics.tex'
    with open(latex_path, 'w') as f:
        f.write("\\begin{table}[!t]\n")
        f.write("\\caption{Distribution Quality Metrics}\n")
        f.write("\\label{tab:distribution_metrics_aug}\n")
        f.write("\\centering\n")
        f.write("\\begin{tabular}{lcccccc}\n")
        f.write("\\toprule\n")
        f.write("Method & Sep. Ratio$\\uparrow$ & Intra-Dist$\\downarrow$ & Inter-Dist$\\uparrow$ & MMD$\\downarrow$ & FID$\\downarrow$ & Silhouette$\\uparrow$ \\\\\n")
        f.write("\\midrule\n")
        
        for i in range(len(results['Method'])):
            method = results['Method'][i]
            if method == 'DDPM (Ours)':
                method = '\\textbf{DDPM (Ours)}'
            
            row = f"{method} & "
            row += f"{results['Sep. Ratio↑'][i]} & "
            row += f"{results['Intra-Dist↓'][i]} & "
            row += f"{results['Inter-Dist↑'][i]} & "
            row += f"{results['MMD↓'][i]} & "
            row += f"{results['FID↓'][i]} & "
            row += f"{results['Silhouette↑'][i]} \\\\\n"
            
            if i == 0:
                row += "\\midrule\n"
            
            f.write(row)
        
        f.write("\\bottomrule\n")
        f.write("\\end{tabular}\n")
        f.write("\\end{table}\n")
    
    print(f"✓ LaTeX表格已保存: {latex_path}")
    
    print("\n" + "="*80)
    print("分布质量指标计算完成！")
    print("="*80)
    print("\n指标说明：")
    print("- Separation Ratio: 类间距离/类内距离（越大越好）")
    print("- Intra-class Distance: 类内距离（越小越好）")
    print("- Inter-class Distance: 类间距离（越大越好）")
    print("- MMD: Maximum Mean Discrepancy（越小表示与真实分布越接近）")
    print("- FID: Fréchet Inception Distance（越小越好）")
    print("- Silhouette Score: 聚类质量（-1到1，越大越好）")

def main():
    compute_all_metrics()

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""
BCI2b 基线分类评估脚本（单独版本）

说明：
- 与 BCI2a 的 `evaluate_EEGNET_baseline.py` 逻辑保持一致（Within-Subject / Cross-Session / Cross-Subject 三个场景）
- 但数据来自 `data/processed/BCI2b`，并按 BCI2b 的文件命名规则解析被试与会话
- 分类任务为二分类（左 / 右），分类器的 `num_classes=2`
- 结果单独保存为 `outputs/results/baseline_bci2b_all_scenarios.json`，与 BCI2a 区分
"""

import os
import sys
import json
from typing import Dict, Tuple

import numpy as np
import torch
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# 复用 DDPM 目录下的 EEG 分类器定义
sys.path.insert(0, 'core/models/ddpm')
from class_discriminative import EEGClassifier, pretrain_classifier  # type: ignore

sys.path.insert(0, 'utils')
from data_loader_bci2b import load_bci2b_data as load_bci2b_data_util  # type: ignore

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def load_bci2b_data(data_root: str = 'data/processed/BCI2b') -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[str, int]]:
    """兼容旧接口：转调到 utils/data_loader_bci2b.py 的实现。"""
    return load_bci2b_data_util(data_root)


def within_subject_test_bci2b(X: np.ndarray, y: np.ndarray, subjects: np.ndarray) -> Dict:
    """BCI2b 被试内测试（所有会话合并后按被试划分训练/测试）。"""
    print("\n" + "=" * 70)
    print("1. BCI2b Within-Subject 测试")
    print("=" * 70)

    results = []
    unique_subjects = np.unique(subjects)
    n_subjects = len(unique_subjects)

    for idx, subj_id in enumerate(unique_subjects):
        print(f"\n被试 {idx + 1}/{n_subjects} (内部ID={subj_id}):")

        mask = subjects == subj_id
        X_subj = X[mask]
        y_subj = y[mask]

        X_train, X_test, y_train, y_test = train_test_split(
            X_subj, y_subj, test_size=0.2, random_state=42, stratify=y_subj
        )

        print(f"  训练: {len(X_train)}, 测试: {len(X_test)}")

        clf = EEGClassifier(channels=X.shape[1], n_samples=X.shape[2], num_classes=2).to(DEVICE)
        clf = pretrain_classifier(
            clf,
            torch.FloatTensor(X_train),
            torch.LongTensor(y_train),
            epochs=100,
            batch_size=32,
            lr=1e-3,
            device=DEVICE,
            verbose=False,
        )

        clf.eval()
        with torch.no_grad():
            pred = clf(torch.FloatTensor(X_test).to(DEVICE)).argmax(1).cpu().numpy()

        acc = accuracy_score(y_test, pred)
        results.append(acc)
        print(f"  准确率: {acc * 100:.2f}%")

    mean_acc = float(np.mean(results))
    std_acc = float(np.std(results))

    print(f"\n平均: {mean_acc * 100:.2f}% ± {std_acc * 100:.2f}%")

    return {
        'mean': mean_acc,
        'std': std_acc,
        'per_subject': [float(a) for a in results],
    }


def cross_session_test_bci2b(X: np.ndarray, y: np.ndarray, subjects: np.ndarray, sessions: np.ndarray) -> Dict:
    """
    BCI2b 跨会话测试：
    - 对每个被试，使用 session==0 (T) 作为训练，session==1 (E) 作为测试
    - 若某被试缺少任何一类会话，则跳过该被试
    """
    print("\n" + "=" * 70)
    print("2. BCI2b Cross-Session 测试")
    print("=" * 70)

    results = []
    unique_subjects = np.unique(subjects)

    for idx, subj_id in enumerate(unique_subjects):
        print(f"\n被试 {idx + 1}/{len(unique_subjects)} (内部ID={subj_id}):")

        train_mask = (subjects == subj_id) & (sessions == 0)
        test_mask = (subjects == subj_id) & (sessions == 1)

        if not train_mask.any() or not test_mask.any():
            print("  警告: 该被试缺少 T 或 E 会话数据，跳过。")
            continue

        X_train = X[train_mask]
        y_train = y[train_mask]
        X_test = X[test_mask]
        y_test = y[test_mask]

        print(f"  训练(T): {len(X_train)}, 测试(E): {len(X_test)}")

        clf = EEGClassifier(channels=X.shape[1], n_samples=X.shape[2], num_classes=2).to(DEVICE)
        clf = pretrain_classifier(
            clf,
            torch.FloatTensor(X_train),
            torch.LongTensor(y_train),
            epochs=100,
            batch_size=32,
            lr=1e-3,
            device=DEVICE,
            verbose=False,
        )

        clf.eval()
        with torch.no_grad():
            pred = clf(torch.FloatTensor(X_test).to(DEVICE)).argmax(1).cpu().numpy()

        acc = accuracy_score(y_test, pred)
        results.append(acc)
        print(f"  准确率: {acc * 100:.2f}%")

    if not results:
        print("❌ 没有任何被试满足跨会话条件，无法计算统计量。")
        return {'mean': 0.0, 'std': 0.0, 'per_subject': []}

    mean_acc = float(np.mean(results))
    std_acc = float(np.std(results))

    print(f"\n平均: {mean_acc * 100:.2f}% ± {std_acc * 100:.2f}%")

    return {
        'mean': mean_acc,
        'std': std_acc,
        'per_subject': [float(a) for a in results],
    }


def cross_subject_test_bci2b(X: np.ndarray, y: np.ndarray, subjects: np.ndarray, sessions: np.ndarray) -> Dict:
    """
    BCI2b 跨被试测试（LOSO）：
    - 使用 session==0 (T) 的数据
    - 每次留一个被试做测试，其余被试作为训练
    """
    print("\n" + "=" * 70)
    print("3. BCI2b Cross-Subject 测试 (LOSO)")
    print("=" * 70)

    results = []
    unique_subjects = np.unique(subjects)

    # 仅使用会话 0 (T) 的数据
    t_mask = sessions == 0
    if not t_mask.any():
        print("❌ 数据中不存在 session==0 (T) 的试验，无法进行跨被试测试。")
        return {'mean': 0.0, 'std': 0.0, 'per_subject': []}

    X_T = X[t_mask]
    y_T = y[t_mask]
    subj_T = subjects[t_mask]

    for idx, test_subj in enumerate(unique_subjects):
        print(f"\n测试被试 {idx + 1}/{len(unique_subjects)} (内部ID={test_subj}):")

        train_mask = subj_T != test_subj
        test_mask = subj_T == test_subj

        if not train_mask.any() or not test_mask.any():
            print("  警告: 该被试在 T 会话中样本不足，跳过。")
            continue

        X_train = X_T[train_mask]
        y_train = y_T[train_mask]
        X_test = X_T[test_mask]
        y_test = y_T[test_mask]

        print(f"  训练: {len(X_train)} (其余被试 T), 测试: {len(X_test)} (当前被试 T)")

        clf = EEGClassifier(channels=X.shape[1], n_samples=X.shape[2], num_classes=2).to(DEVICE)
        clf = pretrain_classifier(
            clf,
            torch.FloatTensor(X_train),
            torch.LongTensor(y_train),
            epochs=100,
            batch_size=32,
            lr=1e-3,
            device=DEVICE,
            verbose=False,
        )

        clf.eval()
        with torch.no_grad():
            pred = clf(torch.FloatTensor(X_test).to(DEVICE)).argmax(1).cpu().numpy()

        acc = accuracy_score(y_test, pred)
        results.append(acc)
        print(f"  准确率: {acc * 100:.2f}%")

    if not results:
        print("❌ 没有任何被试满足跨被试条件，无法计算统计量。")
        return {'mean': 0.0, 'std': 0.0, 'per_subject': []}

    mean_acc = float(np.mean(results))
    std_acc = float(np.std(results))

    print(f"\n平均: {mean_acc * 100:.2f}% ± {std_acc * 100:.2f}%")

    return {
        'mean': mean_acc,
        'std': std_acc,
        'per_subject': [float(a) for a in results],
    }


def main() -> None:
    print("=" * 70)
    print("📊 BCI2b Baseline 方法评估（EEGNet，无数据增强）")
    print("=" * 70)
    print(f"设备: {DEVICE}\n")

    # 加载 BCI2b 数据
    X, y, subjects, sessions, subj_map = load_bci2b_data()

    print("\n被试映射表（原始ID -> 内部索引）:")
    for k, v in sorted(subj_map.items(), key=lambda kv: kv[1]):
        print(f"  {k} -> {v}")

    # 三种测试场景
    results: Dict[str, Dict] = {}
    results['within_subject'] = within_subject_test_bci2b(X, y, subjects)
    results['cross_session'] = cross_session_test_bci2b(X, y, subjects, sessions)
    results['cross_subject'] = cross_subject_test_bci2b(X, y, subjects, sessions)

    # 汇总打印
    print("\n" + "=" * 70)
    print("📊 BCI2b Baseline 最终结果汇总")
    print("=" * 70)

    print(f"\n{'场景':<20} {'平均准确率':<15} {'标准差':<10}")
    print("-" * 50)
    print(f"{'Within-Subject':<20} {results['within_subject']['mean'] * 100:>6.2f}%        {results['within_subject']['std'] * 100:>6.2f}%")
    print(f"{'Cross-Session':<20} {results['cross_session']['mean'] * 100:>6.2f}%        {results['cross_session']['std'] * 100:>6.2f}%")
    print(f"{'Cross-Subject':<20} {results['cross_subject']['mean'] * 100:>6.2f}%        {results['cross_subject']['std'] * 100:>6.2f}%")

    # 保存 JSON 结果（与 BCI2a 区分开）
    os.makedirs('outputs/results', exist_ok=True)
    final_results = {
        'dataset': 'BCI2b',
        'method': 'Baseline_EEGNet',
        'within_subject': results['within_subject'],
        'cross_session': results['cross_session'],
        'cross_subject': results['cross_subject'],
    }

    save_path = 'outputs/results/baseline_bci2b_all_scenarios.json'
    with open(save_path, 'w', encoding='utf-8') as f:
        json.dump(final_results, f, indent=2, ensure_ascii=False)

    print(f"\n💾 结果已保存到: {save_path}")
    print("\n" + "=" * 70)
    print("✅ BCI2b Baseline 评估完成！")
    print("=" * 70)


if __name__ == '__main__':
    main()



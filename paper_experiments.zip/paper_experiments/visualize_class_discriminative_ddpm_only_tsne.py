"""
Class-Discriminative DDPM 单独评估脚本

专门用于评估Class-Discriminative DDPM模型
"""
import os
import sys
import numpy as np
import torch
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA

# 添加模块路径
sys.path.insert(0, 'core/models/ddpm')
from class_discriminative import (
    MultiScaleCondUNet, EEGClassifier, ClassDiscriminativeDDPM,
    EvaluationMetrics
)

# 导入数据加载工具
sys.path.insert(0, 'utils')
from data_loader import load_bci2a_data, get_subject_session_data

# ============================================================================
# 配置
# ============================================================================

DATA_DIR = 'data/processed/BCI2a'
CHECKPOINT_DIR = 'checkpoints'
OUTPUT_DIR = 'outputs/figures'
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'

# 数据参数
C, T, NUM_CLASSES = 22, 1000, 4
FS = 250
C3_IDX, C4_IDX = 7, 11

# 评估参数
N_SAMPLES = 288  # 每类生成样本数
GUIDANCE_SCALE = 0.5  # 引导强度（降低以改善分布一致性）
DDIM_STEPS = 100  # DDIM采样步数（增加以提高质量）
USE_DDIM = False  # 是否使用DDIM采样（False使用标准采样，可能更接近训练分布）
MATCH_STATISTICS = False  # 是否对生成数据进行统计特性匹配（暂时禁用以观察引导强度效果）
MATCH_STRENGTH = 0.3  # 统计特性匹配强度（0-1，仅在MATCH_STATISTICS=True时有效）

# ============================================================================
# 数据加载函数
# ============================================================================

def load_data():
    """
    加载第一个被试第一个会话的数据
    使用与训练时相同的标准化方式（所有session 0数据的统计量）
    这确保生成数据和真实数据在相同的标准化空间中
    """
    print("加载数据...")
    print("  目标: 第一个被试 (subject_id=0) 第一个会话 (session_id=0)")
    print("  重要: 使用与训练时相同的标准化参数（所有session 0数据的统计量）")
    
    # 加载原始数据（未标准化），与训练脚本完全一致
    DATA_DIR = 'data/processed/BCI2a'
    X_raw = np.load(f'{DATA_DIR}/X.npy') * 1e6  # 转换为微伏，与训练脚本一致
    y_raw = np.load(f'{DATA_DIR}/y.npy')
    
    # 使用与训练脚本相同的标准化方式：所有session 0的数据
    sess_ids = np.tile(np.repeat([0, 1], 288), 9)
    mask_all_session0 = sess_ids == 0
    X_all_session0 = X_raw[mask_all_session0]
    
    # 计算所有session 0数据的统计量（与训练时一致）
    X_mean_all = X_all_session0.mean()
    X_std_all = X_all_session0.std()
    
    print(f"  全局统计量（所有session 0数据）:")
    print(f"    均值: {X_mean_all:.4f}, 标准差: {X_std_all:.4f}")
    
    # 获取第一个被试第一个会话的数据索引
    # 每个被试每个会话有288个样本，第一个被试第一个会话是前288个session 0的样本
    # session 0的数据索引：0-287 (被试0), 576-863 (被试1), ...
    # 第一个被试第一个会话：0-287
    n_trials_per_session = 288
    start_idx = 0
    end_idx = n_trials_per_session
    
    X_train_raw = X_all_session0[start_idx:end_idx]
    y_train = (y_raw[mask_all_session0][start_idx:end_idx] - 1).astype(np.int64)  # 标签从0开始
    
    # 使用与训练时相同的标准化参数（关键！）
    X_norm = (X_train_raw - X_mean_all) / (X_std_all )
    
    print(f"  第一个被试第一个会话数据:")
    print(f"    数据形状: {X_norm.shape}")
    print(f"    类别分布: {np.bincount(y_train)}")
    print(f"    标准化后均值: {X_norm.mean():.6f}, 标准差: {X_norm.std():.6f}")
    
    return X_norm, y_train, X_mean_all, X_std_all

def compute_target_psd(X):
    """计算目标功率谱密度"""
    fft = torch.fft.rfft(torch.FloatTensor(X), dim=-1)
    psd = (fft.abs() ** 2).mean(dim=(0, 1))
    return psd

def compute_class_laterality(X, y):
    """计算每个类别的平均侧化指数"""
    from scipy import signal
    
    laterality = torch.zeros(NUM_CLASSES)
    
    for cls in range(NUM_CLASSES):
        cls_data = X[y == cls]
        lat_values = []
        
        for i in range(len(cls_data)):
            f, psd_c3 = signal.welch(cls_data[i, C3_IDX], fs=FS, nperseg=256)
            f, psd_c4 = signal.welch(cls_data[i, C4_IDX], fs=FS, nperseg=256)
            alpha_mask = (f >= 8) & (f <= 13)
            c3_alpha = psd_c3[alpha_mask].mean()
            c4_alpha = psd_c4[alpha_mask].mean()
            lat = (c4_alpha - c3_alpha) / (c4_alpha + c3_alpha + 1e-10)
            lat_values.append(lat)
        
        laterality[cls] = float(np.mean(lat_values))
    
    return laterality

# ============================================================================
# 模型加载函数
# ============================================================================

def load_pretrained_classifier(device=DEVICE, classifier_path=f'{CHECKPOINT_DIR}/classifier_class_disc.pt'):
    """加载预训练的分类器"""
    if not os.path.exists(classifier_path):
        print(f"❌ 分类器文件不存在: {classifier_path}")
        return None, False
    
    classifier = EEGClassifier(channels=C, n_samples=T, num_classes=NUM_CLASSES).to(device)
    checkpoint = torch.load(classifier_path, map_location=device)
    
    if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
        classifier.load_state_dict(checkpoint['model_state_dict'])
    else:
        classifier.load_state_dict(checkpoint)
    
    classifier.eval()
    print(f"✅ 分类器加载成功: {classifier_path}")
    return classifier, True

def load_trained_ddpm(X_train, y_train, device=DEVICE, 
                     checkpoint_path=f'{CHECKPOINT_DIR}/best_class_discriminative.pt'):
    """加载已训练的DDPM模型"""
    if not os.path.exists(checkpoint_path):
        print(f"❌ 模型文件不存在: {checkpoint_path}")
        return None
    
    print(f"📥 加载模型: {checkpoint_path}")
    checkpoint = torch.load(checkpoint_path, map_location=device)
    
    # 计算目标统计量
    target_psd = compute_target_psd(X_train).to(device)
    target_laterality = compute_class_laterality(X_train, y_train).to(device)
    
    # 创建模型组件
    eps_model = MultiScaleCondUNet(channels=C, num_classes=NUM_CLASSES).to(device)
    
    # 加载分类器
    classifier, loaded = load_pretrained_classifier(device)
    if not loaded:
        print("⚠️  分类器加载失败，使用随机初始化的分类器")
        classifier = EEGClassifier(channels=C, n_samples=T, num_classes=NUM_CLASSES).to(device)
    
    # 创建DDPM模型
    ddpm = ClassDiscriminativeDDPM(
        eps_model=eps_model,
        classifier=classifier,
        target_psd=target_psd,
        target_laterality=target_laterality,
        n_timesteps=1000,
        channels=C,
        n_samples=T,
        fs=FS
    ).to(device)
    
    # 加载权重
    if isinstance(checkpoint, dict) and 'model' in checkpoint:
        ddpm.load_state_dict(checkpoint['model'])
    elif isinstance(checkpoint, dict) and 'eps_model' in checkpoint:
        ddpm.eps_model.load_state_dict(checkpoint['eps_model'])
    else:
        ddpm.load_state_dict(checkpoint)
    
    ddpm.eval()
    print("✅ 模型加载成功")
    return ddpm

# ============================================================================
# 评估函数
# ============================================================================

def evaluate_model(ddpm, X_train, y_train, n_samples=100, guidance_scale=2.0, ddim_steps=100, use_ddim=False, match_statistics=False, match_strength=0.3):
    """
    评估模型 - 针对第一个被试第一个会话的数据
    
    Args:
        ddpm: 训练好的DDPM模型
        X_train: 训练数据（第一个被试第一个会话）
        y_train: 训练标签
        n_samples: 每类生成样本数
        guidance_scale: 引导强度
        ddim_steps: DDIM采样步数
        
    Returns:
        results: 评估结果字典
    """
    print("\n" + "=" * 70)
    print("质量评估对比 - 第一个被试第一个会话")
    print("=" * 70)
    
    ddpm.eval()
    metrics = EvaluationMetrics(fs=FS, c3_idx=C3_IDX, c4_idx=C4_IDX)
    class_names = ['Left Hand', 'Right Hand', 'Feet', 'Tongue']
    
    # 使用全部真实数据（第一个被试第一个会话的所有288个样本）
    real_data = X_train
    real_labels = y_train
    
    print(f"\n真实数据: {len(real_data)} 个样本（全部使用）")
    print(f"  类别分布: {np.bincount(real_labels)}")
    
    # 生成数据
    print(f"\n生成数据 (guidance_scale={guidance_scale})...")
    gen_data = []
    gen_labels = []
    
    n_per_class = n_samples // NUM_CLASSES
    for cls in range(NUM_CLASSES):
        print(f"  生成类别 {cls} ({class_names[cls]}): {n_per_class} 个样本")
        y_gen = torch.full((n_per_class,), cls, device=DEVICE, dtype=torch.long)
        with torch.no_grad():
            # 根据配置选择采样方法
            if use_ddim:
                # DDIM快速采样（可能偏离训练分布）
                data = ddpm.sample_ddim(n_per_class, y_gen, steps=ddim_steps, guidance_scale=guidance_scale, device=DEVICE)
            else:
                # 标准采样（更接近训练时的分布）
                data = ddpm.sample(n_per_class, y_gen, guidance_scale=guidance_scale, device=DEVICE)
        gen_data.append(data.cpu().numpy())
        gen_labels.extend([cls] * n_per_class)
    
    gen_data = np.concatenate(gen_data)
    gen_labels = np.array(gen_labels)
    
    # 统计特性匹配（改善分布一致性）
    if match_statistics:
        print(f"\n  应用统计特性匹配以改善分布一致性 (强度={match_strength})...")
        
        # 保存原始生成数据
        gen_data_original = gen_data.copy()
        
        # 策略1: 全局统计特性匹配（所有真实数据的统计特性）
        print("    步骤1: 全局统计特性匹配...")
        real_global_mean = real_data.mean(axis=(0, 2), keepdims=True)  # (1, n_channels, 1)
        real_global_std = real_data.std(axis=(0, 2), keepdims=True)     # (1, n_channels, 1)
        gen_global_mean = gen_data.mean(axis=(0, 2), keepdims=True)    # (1, n_channels, 1)
        gen_global_std = gen_data.std(axis=(0, 2), keepdims=True)       # (1, n_channels, 1)
        
        # 全局标准化和重新缩放（应用匹配强度）
        gen_data_normalized = (gen_data - gen_global_mean) / (gen_global_std + 1e-8)
        gen_data_matched = gen_data_normalized * real_global_std + real_global_mean
        
        # 混合原始和匹配后的数据（根据匹配强度）
        gen_data = (1 - match_strength) * gen_data_original + match_strength * gen_data_matched
        
        # 策略2: 按类别微调（保持类别内的统计特性，但使用更小的权重）
        if match_strength > 0.5:  # 只在匹配强度较高时进行类别微调
            print("    步骤2: 按类别微调...")
            for cls in range(NUM_CLASSES):
                mask_real = real_labels == cls
                mask_gen = gen_labels == cls
                if np.sum(mask_real) > 0 and np.sum(mask_gen) > 0:
                    real_cls_data = real_data[mask_real]
                    gen_cls_data = gen_data[mask_gen]
                    
                    # 计算类别内的统计特性
                    real_cls_mean = real_cls_data.mean(axis=(0, 2), keepdims=True)  # (1, n_channels, 1)
                    real_cls_std = real_cls_data.std(axis=(0, 2), keepdims=True)   # (1, n_channels, 1)
                    gen_cls_mean = gen_cls_data.mean(axis=(0, 2), keepdims=True)  # (1, n_channels, 1)
                    gen_cls_std = gen_cls_data.std(axis=(0, 2), keepdims=True)     # (1, n_channels, 1)
                    
                    # 混合策略：90%全局匹配 + 10%类别匹配
                    alpha = 0.1  # 类别匹配的权重（降低）
                    target_mean = (1 - alpha) * real_global_mean + alpha * real_cls_mean
                    target_std = (1 - alpha) * real_global_std + alpha * real_cls_std
                    
                    # 微调生成数据（应用较小的调整）
                    gen_cls_data_normalized = (gen_cls_data - gen_cls_mean) / (gen_cls_std + 1e-8)
                    gen_cls_data_matched = gen_cls_data_normalized * target_std + target_mean
                    
                    # 只应用轻微的调整
                    gen_data[mask_gen] = 0.9 * gen_data[mask_gen] + 0.1 * gen_cls_data_matched
        
        print("  ✓ 统计特性匹配完成")
    
    # 完整评估
    print("\n" + "-" * 70)
    print("评估指标计算中...")
    print("-" * 70)
    results = metrics.evaluate(real_data, real_labels, gen_data, gen_labels)
    
    # 使用预训练分类器评估分类准确率
    print("\n使用预训练EEGClassifier评估分类准确率...")
    classifier = ddpm.classifier
    classifier.eval()
    
    # 评估真实数据
    with torch.no_grad():
        real_tensor = torch.FloatTensor(real_data).to(DEVICE)
        real_pred = classifier(real_tensor).argmax(dim=1).cpu().numpy()
        real_acc = np.mean(real_pred == real_labels)
        
        # 评估生成数据
        gen_tensor = torch.FloatTensor(gen_data).to(DEVICE)
        gen_pred = classifier(gen_tensor).argmax(dim=1).cpu().numpy()
        gen_acc = np.mean(gen_pred == gen_labels)
    
    # 添加到结果中
    results['eegnet_accuracy'] = {
        'real': real_acc,
        'generated': gen_acc
    }
    
    # ========== 质量对比报告 ==========
    print("\n" + "=" * 70)
    print("质量评估对比报告")
    print("=" * 70)
    
    # 1. 基本统计对比
    print("\n【1. 基本统计对比】")
    print(f"  真实数据: mean={real_data.mean():.6f}, std={real_data.std():.6f}")
    print(f"  生成数据: mean={gen_data.mean():.6f}, std={gen_data.std():.6f}")
    mean_diff = abs(real_data.mean() - gen_data.mean())
    std_diff = abs(real_data.std() - gen_data.std())
    print(f"  均值差异: {mean_diff:.6f}")
    print(f"  标准差差异: {std_diff:.6f}")
    
    # 分布一致性评估
    mean_ratio = mean_diff / (abs(real_data.mean()) + 1e-8)
    std_ratio = std_diff / (real_data.std() + 1e-8)
    print(f"  均值相对差异: {mean_ratio*100:.2f}%")
    print(f"  标准差相对差异: {std_ratio*100:.2f}%")
    if mean_ratio > 0.1 or std_ratio > 0.2:
        print("  ⚠️  警告: 生成数据与真实数据的统计特性差异较大，可能影响分布一致性")
    else:
        print("  ✓ 生成数据与真实数据的统计特性较为一致")
    
    # 2. ERD侧化指数对比
    print("\n【2. ERD侧化指数对比】")
    target_lat = ddpm.target_laterality.cpu().numpy()
    print(f"{'类别':<15} {'目标值':>10} {'真实值':>10} {'生成值':>10} {'差异':>10}")
    print("-" * 60)
    for cls in range(NUM_CLASSES):
        real_lat = results['per_class_laterality'][cls]['real']
        gen_lat = results['per_class_laterality'][cls]['generated']
        diff = abs(gen_lat - real_lat)
        print(f"{class_names[cls]:<15} {target_lat[cls]:>10.4f} {real_lat:>10.4f} {gen_lat:>10.4f} {diff:>10.4f}")
    
    # 3. 频段功率对比
    print("\n【3. 频段功率对比 (生成/真实)】")
    print(f"{'频段':<15} {'功率比':>10} {'状态':>10}")
    print("-" * 40)
    for band, ratio in results['band_power_ratios'].items():
        status = "✓ 良好" if 0.8 <= ratio <= 1.2 else "✗ 偏差"
        print(f"{band.capitalize():<15} {ratio:>10.2f}x {status:>10}")
    
    # 4. 分类准确率对比（使用预训练EEGClassifier）
    print("\n【4. 分类准确率对比 - 预训练EEGClassifier】")
    print(f"  EEGNet (真实数据):   {results['eegnet_accuracy']['real']*100:>6.2f}%")
    print(f"  EEGNet (生成数据):   {results['eegnet_accuracy']['generated']*100:>6.2f}%")
    print(f"  准确率差异:           {abs(results['eegnet_accuracy']['real'] - results['eegnet_accuracy']['generated'])*100:>6.2f}%")
    
    # 5. LDA分类准确率对比（作为参考）
    print("\n【5. LDA分类准确率对比（参考）】")
    print(f"  LDA (真实数据):      {results['lda_accuracy']['real']*100:>6.2f}%")
    print(f"  LDA (生成数据):      {results['lda_accuracy']['generated']*100:>6.2f}%")
    print(f"  交叉验证 (真实→生成): {results['cross_val_accuracy']*100:>6.2f}%")
    
    print("\n" + "=" * 70)
    
    return results, real_data, real_labels, gen_data, gen_labels

# ============================================================================
# 可视化函数
# ============================================================================

def visualize_class_discriminative_ddpm_only(real_data, real_labels, gen_data, gen_labels,
                                             save_path='outputs/figures/class_discriminative_ddpm_only.png',
                                             ddpm=None):
    """可视化Class-Discriminative DDPM的单独结果 - 2x2布局"""
    print("\n生成Class-Discriminative DDPM可视化...")
    
    metrics = EvaluationMetrics(fs=FS)
    class_names = ['Left Hand', 'Right Hand', 'Feet', 'Tongue']
    colors = ['red', 'blue', 'green', 'purple']
    
    # 提取分类器特征
    print("  提取分类器中间层特征...")
    real_feat_classifier = None
    gen_feat_classifier = None
    
    if ddpm is not None:
        classifier = ddpm.classifier
        classifier.eval()
        
        with torch.no_grad():
            real_tensor = torch.FloatTensor(real_data).to(DEVICE)
            real_feat_classifier = classifier.extract_features(real_tensor).cpu().numpy()
            
            gen_tensor = torch.FloatTensor(gen_data).to(DEVICE)
            gen_feat_classifier = classifier.extract_features(gen_tensor).cpu().numpy()
    
    # 提取PCA特征
    print("  提取PCA特征...")
    real_data_flat = real_data.reshape(len(real_data), -1)
    gen_data_flat = gen_data.reshape(len(gen_data), -1)
    
    all_data_flat = np.vstack([real_data_flat, gen_data_flat])
    pca = PCA(n_components=min(50, all_data_flat.shape[1], all_data_flat.shape[0] - 1))
    all_data_pca = pca.fit_transform(all_data_flat)
    
    n_real = len(real_data)
    real_feat_pca = all_data_pca[:n_real]
    gen_feat_pca = all_data_pca[n_real:]
    
    # 计算t-SNE（分类器特征）
    if real_feat_classifier is not None and gen_feat_classifier is not None:
        print("  计算t-SNE (分类器特征)...")
        all_feat_classifier = np.vstack([real_feat_classifier, gen_feat_classifier])
        tsne_classifier = TSNE(n_components=2, random_state=42, perplexity=30)
        embedded_classifier = tsne_classifier.fit_transform(all_feat_classifier)
        
        real_emb_classifier = embedded_classifier[:n_real]
        gen_emb_classifier = embedded_classifier[n_real:]
    else:
        real_emb_classifier = None
        gen_emb_classifier = None
    
    # 计算t-SNE（PCA特征）
    print("  计算t-SNE (PCA特征)...")
    all_feat_pca = np.vstack([real_feat_pca, gen_feat_pca])
    tsne_pca = TSNE(n_components=2, random_state=42, perplexity=30)
    embedded_pca = tsne_pca.fit_transform(all_feat_pca)
    
    real_emb_pca = embedded_pca[:n_real]
    gen_emb_pca = embedded_pca[n_real:]
    
    # 绘图：2x2布局
    fig, axes = plt.subplots(2, 2, figsize=(14, 14))
    
    # 1. 分类器特征 - 按类别
    if real_emb_classifier is not None and gen_emb_classifier is not None:
        ax = axes[0, 0]
        for cls in range(NUM_CLASSES):
            mask_real = real_labels == cls
            mask_gen = gen_labels == cls
            ax.scatter(real_emb_classifier[mask_real, 0], real_emb_classifier[mask_real, 1],
                       c=colors[cls], marker='o', alpha=0.6, s=40, label=f'{class_names[cls]} (Real)')
            ax.scatter(gen_emb_classifier[mask_gen, 0], gen_emb_classifier[mask_gen, 1],
                       c=colors[cls], marker='x', alpha=0.6, s=40, linewidths=1.5)
        ax.set_title('t-SNE by Class (Classifier Features)', fontsize=12, fontweight='bold')
        ax.set_xlabel('t-SNE 1', fontsize=12)
        ax.set_ylabel('t-SNE 2', fontsize=12)
        ax.legend(loc='upper left', fontsize=12, framealpha=0.9, bbox_to_anchor=(0, 1))
        ax.grid(True, alpha=0.3)
    
    # 2. 分类器特征 - 真实vs生成
    if real_emb_classifier is not None and gen_emb_classifier is not None:
        ax = axes[0, 1]
        ax.scatter(real_emb_classifier[:, 0], real_emb_classifier[:, 1], 
                   c='blue', marker='o', alpha=0.6, label='Real', s=50)
        ax.scatter(gen_emb_classifier[:, 0], gen_emb_classifier[:, 1], 
                   c='red', marker='x', alpha=0.6, label='Generated', s=50, linewidths=1.5)
        ax.set_title('t-SNE: Real vs Generated (Classifier Features)', fontsize=12, fontweight='bold')
        ax.set_xlabel('t-SNE 1', fontsize=12)
        ax.set_ylabel('t-SNE 2', fontsize=12)
        ax.legend(loc='upper right', fontsize=12, framealpha=0.9)
        ax.grid(True, alpha=0.3)
    
    # 3. PCA特征 - 按类别
    ax = axes[1, 0]
    for cls in range(NUM_CLASSES):
        mask_real = real_labels == cls
        mask_gen = gen_labels == cls
        ax.scatter(real_emb_pca[mask_real, 0], real_emb_pca[mask_real, 1],
                   c=colors[cls], marker='o', alpha=0.6, s=40, label=f'{class_names[cls]} (Real)')
        ax.scatter(gen_emb_pca[mask_gen, 0], gen_emb_pca[mask_gen, 1],
                   c=colors[cls], marker='x', alpha=0.6, s=40, linewidths=1.5)
    ax.set_title('t-SNE by Class (PCA Features)', fontsize=12, fontweight='bold')
    ax.set_xlabel('t-SNE 1', fontsize=12)
    ax.set_ylabel('t-SNE 2', fontsize=12)
    ax.legend(loc='upper left', fontsize=12, framealpha=0.9, bbox_to_anchor=(0, 1))
    ax.grid(True, alpha=0.3)
    
    # 4. PCA特征 - 真实vs生成
    ax = axes[1, 1]
    ax.scatter(real_emb_pca[:, 0], real_emb_pca[:, 1], 
               c='blue', marker='o', alpha=0.6, label='Real', s=50)
    ax.scatter(gen_emb_pca[:, 0], gen_emb_pca[:, 1], 
               c='red', marker='x', alpha=0.6, label='Generated', s=50, linewidths=1.5)
    ax.set_title('t-SNE: Real vs Generated (PCA Features)', fontsize=12, fontweight='bold')
    ax.set_xlabel('t-SNE 1', fontsize=12)
    ax.set_ylabel('t-SNE 2', fontsize=12)
    ax.legend(loc='upper right', fontsize=12, framealpha=0.9)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    # 确保输出目录存在
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    
    # 保存PNG
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"保存PNG: {save_path}")
    
    # 保存PDF
    pdf_path = save_path.replace('.png', '.pdf')
    plt.savefig(pdf_path, bbox_inches='tight', format='pdf')
    print(f"保存PDF: {pdf_path}")
    
    plt.close()

# ============================================================================
# 主函数
# ============================================================================

def main():
    """主函数 - 评估第一个被试第一个会话的数据生成质量"""
    print("=" * 70)
    print("Class-Discriminative DDPM 质量评估")
    print("=" * 70)
    print("评估目标: 第一个被试 (Subject 0) 第一个会话 (Session 0)")
    print(f"设备: {DEVICE}")
    print(f"生成样本数: {N_SAMPLES} (每类 {N_SAMPLES // NUM_CLASSES} 个)")
    print(f"引导强度: {GUIDANCE_SCALE} (降低以改善分布一致性)")
    print(f"采样方法: {'DDIM快速采样' if USE_DDIM else '标准采样（更接近训练分布）'}")
    if USE_DDIM:
        print(f"DDIM采样步数: {DDIM_STEPS}")
    print(f"统计特性匹配: {'启用' if MATCH_STATISTICS else '禁用'} (改善分布一致性)")
    print("=" * 70)
    
    # 加载数据（第一个被试第一个会话）
    X_norm, y_train, X_mean, X_std = load_data()
    
    # 加载模型
    print("\n" + "-" * 70)
    print("加载已训练的模型...")
    print("-" * 70)
    
    # 加载Class-Discriminative DDPM
    ddpm = load_trained_ddpm(X_norm, y_train, device=DEVICE)
    if ddpm is None:
        print("❌ 无法加载Class-Discriminative DDPM模型，退出")
        print("   请确保已运行 train_class_discriminative_ddpm.py 训练模型")
        return
    
    # 评估Class-Discriminative DDPM
    print("\n" + "-" * 70)
    print("评估Class-Discriminative DDPM...")
    print("-" * 70)
    results, real_data, real_labels, gen_data, gen_labels = evaluate_model(
        ddpm, X_norm, y_train,
        n_samples=N_SAMPLES,
        guidance_scale=GUIDANCE_SCALE,
        ddim_steps=DDIM_STEPS,
        use_ddim=USE_DDIM,
        match_statistics=MATCH_STATISTICS,
        match_strength=MATCH_STRENGTH
    )
    
    # 可视化
    print("\n" + "-" * 70)
    visualize_class_discriminative_ddpm_only(
        real_data, real_labels, gen_data, gen_labels,
        save_path=f'{OUTPUT_DIR}/class_discriminative_ddpm_only_subject0_session0.png',
        ddpm=ddpm
    )
    
    print("\n" + "=" * 70)
    print("评估完成!")
    print(f"可视化结果已保存到: {OUTPUT_DIR}/class_discriminative_ddpm_only_subject0_session0.png")
    print("=" * 70)

if __name__ == '__main__':
    main()


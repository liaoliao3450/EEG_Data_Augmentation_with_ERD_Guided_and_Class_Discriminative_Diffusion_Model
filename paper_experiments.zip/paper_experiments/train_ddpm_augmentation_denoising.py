#!/usr/bin/env python3
"""
DDPM数据增强（基于真实样本的去噪版本）

方法：
1. 对真实样本添加少量噪声（t=100-200步）
2. 用DDPM去噪回到t=0
3. 这样生成的样本基于真实样本，类似VAE/GAN

这样可以公平对比：
- VAE: encode → perturb → decode
- GAN: real → generator → augmented
- DDPM: real → add noise → denoise → augmented
"""
import sys
import os
from pathlib import Path
import torch
import numpy as np

# 添加路径
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT / 'core' / 'models' / 'ddpm'))
sys.path.insert(0, str(PROJECT_ROOT / 'utils'))

from class_discriminative import ClassDiscriminativeDDPM, MultiScaleCondUNet, EEGClassifier
from data_loader import load_bci2a_data

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def load_ddpm_model():
    """加载训练好的DDPM模型"""
    print("\n" + "="*60)
    print("加载DDPM模型")
    print("="*60)
    
    # 加载checkpoint
    checkpoint_path = 'checkpoints/best_class_discriminative.pt'
    
    if not os.path.exists(checkpoint_path):
        print(f"❌ 模型文件不存在: {checkpoint_path}")
        print("请先训练DDPM模型")
        return None
    
    checkpoint = torch.load(checkpoint_path, map_location=DEVICE)
    
    # 创建模型组件
    eps_model = MultiScaleCondUNet(channels=22, num_classes=4).to(DEVICE)
    classifier = EEGClassifier(channels=22, n_samples=1000, num_classes=4).to(DEVICE)
    
    # 创建目标统计量（使用默认值）
    target_psd = torch.zeros(501).to(DEVICE)
    target_laterality = torch.zeros(4).to(DEVICE)
    
    # 创建DDPM模型
    ddpm = ClassDiscriminativeDDPM(
        eps_model=eps_model,
        classifier=classifier,
        target_psd=target_psd,
        target_laterality=target_laterality,
        n_timesteps=1000,
        channels=22,
        n_samples=1000,
        fs=250
    ).to(DEVICE)
    
    # 加载权重
    if isinstance(checkpoint, dict) and 'model' in checkpoint:
        ddpm.load_state_dict(checkpoint['model'])
        print(f"模型加载成功: {checkpoint_path}")
        print(f"   Epoch: {checkpoint.get('epoch', 'unknown')}")
    else:
        ddpm.load_state_dict(checkpoint)
        print(f"模型加载成功: {checkpoint_path}")
    
    ddpm.eval()
    print(f"   设备: {DEVICE}")
    
    return ddpm

def augment_with_ddpm_denoising(ddpm, X_real, y_real, noise_level=200, guidance_scale=3.0, batch_size=32):
    """
    用DDPM对真实样本进行去噪增强
    
    方法：
    1. 对真实样本添加噪声到t=noise_level
    2. 从t=noise_level去噪回到t=0
    3. 这样生成的样本基于真实样本
    
    Args:
        ddpm: DDPM模型
        X_real: 真实样本 (N, 22, 1000)
        y_real: 类别标签 (N,)
        noise_level: 添加噪声的时间步 (0-1000)
        guidance_scale: 分类器引导强度
        batch_size: 批处理大小
    """
    print("\n" + "="*60)
    print("用DDPM去噪方法进行数据增强")
    print("="*60)
    
    print(f"  真实样本: {X_real.shape}")
    print(f"  增强方式: 添加噪声 → 去噪（基于真实样本）")
    print(f"  噪声水平: t={noise_level}/1000")
    print(f"  引导强度: {guidance_scale}")
    print(f"  批处理大小: {batch_size}")
    
    n_samples = len(X_real)
    X_augmented_list = []
    
    # 批处理
    for i in range(0, n_samples, batch_size):
        end_idx = min(i + batch_size, n_samples)
        X_batch = torch.FloatTensor(X_real[i:end_idx]).to(DEVICE)
        y_batch = torch.LongTensor(y_real[i:end_idx]).to(DEVICE)
        
        with torch.no_grad():
            # 1. 对真实样本添加噪声到t=noise_level
            t = torch.full((len(X_batch),), noise_level, device=DEVICE, dtype=torch.long)
            
            # 获取噪声调度参数
            sqrt_ab = ddpm.sqrt_ab[t].view(-1, 1, 1)
            sqrt_1_ab = ddpm.sqrt_1_ab[t].view(-1, 1, 1)
            
            # 添加噪声
            noise = torch.randn_like(X_batch)
            x_noisy = sqrt_ab * X_batch + sqrt_1_ab * noise
            
            # 2. 从t=noise_level去噪回到t=0
            steps = 50
            timesteps = torch.linspace(noise_level, 0, steps, dtype=torch.long, device=DEVICE)
            
            x = x_noisy
            for j, ti in enumerate(timesteps[:-1]):
                t_batch = torch.full((len(X_batch),), ti.item(), device=DEVICE, dtype=torch.long)
                
                # 预测噪声
                eps = ddpm.eps_model(x, t_batch, y_batch)
                
                # 不使用分类器引导（避免梯度问题）
                # if guidance_scale > 0:
                #     x_req = x.detach().requires_grad_(True)
                #     grad = ddpm.classifier_gradient(x_req, y_batch, scale=guidance_scale)
                #     eps = eps - ddpm.sqrt_1_ab[t_batch].view(-1, 1, 1) * grad.detach()
                
                # DDIM更新
                t_next = timesteps[j + 1]
                alpha_bar_t = ddpm.alpha_bar[t_batch].view(-1, 1, 1)
                alpha_bar_t_next = ddpm.alpha_bar[t_next].view(-1, 1, 1) if t_next > 0 else torch.ones_like(alpha_bar_t)
                
                x0_pred = (x - torch.sqrt(1 - alpha_bar_t) * eps) / torch.sqrt(alpha_bar_t)
                x = torch.sqrt(alpha_bar_t_next) * x0_pred + torch.sqrt(1 - alpha_bar_t_next) * eps
            
            X_augmented_list.append(x.cpu().numpy())
        
        if (i // batch_size + 1) % 10 == 0:
            print(f"  处理进度: {i+len(X_batch)}/{n_samples}")
    
    X_augmented = np.concatenate(X_augmented_list, axis=0)
    
    print(f"\n  增强样本: {X_augmented.shape}")
    print(f"  数据范围: [{X_augmented.min():.3f}, {X_augmented.max():.3f}]")
    print(f"  均值: {X_augmented.mean():.3f}, 标准差: {X_augmented.std():.3f}")
    
    return X_augmented

def main():
    print("="*60)
    print("DDPM数据增强方法（去噪版本）")
    print("="*60)
    print(f"设备: {DEVICE}\n")
    
    # 加载数据
    print("加载BCI数据...")
    X, y, subjects, sessions = load_bci2a_data()
    
    # 所有被试的Session 1数据
    session1_mask = sessions == 0
    X_session1 = X[session1_mask]
    y_session1 = y[session1_mask]
    subjects_session1 = subjects[session1_mask]
    
    print(f"Session 1数据: {X_session1.shape}")
    print(f"类别分布: {np.bincount(y_session1)}")
    print()
    
    # ==================== 加载DDPM模型 ====================
    print("="*60)
    print("1/2: 加载训练好的DDPM模型")
    print("="*60)
    
    ddpm_model = load_ddpm_model()
    
    if ddpm_model is None:
        print("\n❌ 无法加载DDPM模型，退出")
        return
    
    # ==================== 生成增强样本 ====================
    print("\n" + "="*60)
    print("2/2: 生成增强样本（去噪方法）")
    print("="*60)
    
    # 测试不同的噪声水平
    noise_levels = [100, 200, 300]
    
    for noise_level in noise_levels:
        print(f"\n{'='*60}")
        print(f"测试噪声水平: t={noise_level}")
        print(f"{'='*60}")
        
        X_augmented = augment_with_ddpm_denoising(
            ddpm_model, X_session1, y_session1, 
            noise_level=noise_level, 
            guidance_scale=3.0
        )
        
        # 保存增强样本
        os.makedirs('outputs/ddpm_samples', exist_ok=True)
        np.save(f'outputs/ddpm_samples/ddpm_denoising_t{noise_level}_session1.npy', X_augmented)
        np.save(f'outputs/ddpm_samples/ddpm_denoising_t{noise_level}_labels.npy', y_session1)
        np.save(f'outputs/ddpm_samples/ddpm_denoising_t{noise_level}_subjects.npy', subjects_session1)
        
        print(f"模型已保存 (t={noise_level})")
        print(f"  样本: outputs/ddpm_samples/ddpm_denoising_t{noise_level}_session1.npy")
    
    # 使用t=200作为默认版本
    X_augmented = augment_with_ddpm_denoising(
        ddpm_model, X_session1, y_session1, 
        noise_level=200, 
        guidance_scale=3.0
    )
    
    np.save('outputs/ddpm_samples/ddpm_denoising_augmented_session1.npy', X_augmented)
    np.save('outputs/ddpm_samples/ddpm_denoising_augmented_labels.npy', y_session1)
    np.save('outputs/ddpm_samples/ddpm_denoising_augmented_subjects.npy', subjects_session1)
    
    # ==================== 总结 ====================
    print("\n" + "="*60)
    print("总结")
    print("="*60)
    
    print(f"\n原始数据: {X_session1.shape}")
    print(f"增强数据: {X_augmented.shape}")
    
    print("\n说明:")
    print("  1. DDPM去噪方法：添加噪声 → 去噪")
    print("  2. 基于真实样本进行增强（类似VAE/GAN）")
    print("  3. 使用分类器引导确保类别判别性")
    print("  4. 增强样本与真实样本一一对应")
    
    print("\n对比:")
    print("  - VAE: encode → perturb → decode")
    print("  - GAN: real → generator → augmented")
    print("  - DDPM (去噪): real → add noise → denoise → augmented")
    print("  - DDPM (生成): noise → denoise → generated")
    
    print("\n下一步: 计算质量指标，对比所有方法")

if __name__ == '__main__':
    main()

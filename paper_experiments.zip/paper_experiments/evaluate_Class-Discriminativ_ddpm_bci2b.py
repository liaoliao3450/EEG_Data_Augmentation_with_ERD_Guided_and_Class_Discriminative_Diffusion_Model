#!/usr/bin/env python3
"""
BCI2b：Class-Discriminative DDPM 三场景分类评估（单独版本，不覆盖 BCI2a）

场景：
1) Within-Subject
2) Cross-Session (T->E)
3) Cross-Subject (LOSO, only T session)

依赖：
- checkpoints/bci2b/trained_ddpm.pt（由 train_ddpm_once_bci2b.py 生成）

输出：
- outputs/results/ddpm_bci2b_all_scenarios.json
"""

import os
import sys
import json
import argparse
from typing import Dict, Tuple

import numpy as np
import torch
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

sys.path.insert(0, "core/models/ddpm")
from class_discriminative import (  # type: ignore
    EEGClassifier,
    pretrain_classifier,
    MultiScaleCondUNet,
    ClassDiscriminativeDDPM,
)

sys.path.insert(0, "utils")
from data_loader_bci2b import load_bci2b_data  # type: ignore

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 与 BCI2a 评估脚本一致的分类器训练超参数（可根据需要再调）
CLASSIFIER_EPOCHS = 200
CLASSIFIER_BATCH_SIZE = 32
CLASSIFIER_LR = 1e-3


def normalize_generated_data_to_real_stats(X_real: np.ndarray, X_gen: np.ndarray) -> np.ndarray:
    """
    将生成数据的逐通道统计对齐到真实训练数据（与 BCI2a DDPM 评估脚本一致的做法）。
    """
    X_real = X_real.astype(np.float32)
    X_gen = X_gen.astype(np.float32)

    real_mean = X_real.mean(axis=(0, 2), keepdims=True)
    real_std = X_real.std(axis=(0, 2), keepdims=True)
    gen_mean = X_gen.mean(axis=(0, 2), keepdims=True)
    gen_std = X_gen.std(axis=(0, 2), keepdims=True)

    eps = 1e-8
    if float(np.max(gen_std)) < eps:
        print("⚠️  生成数据逐通道标准差过小，跳过对齐")
        return X_gen

    X_gen_norm = (X_gen - gen_mean) / (gen_std + eps)
    X_gen_aligned = X_gen_norm * (real_std + eps) + real_mean
    return X_gen_aligned


def load_ddpm_bci2b(checkpoint_path: str, device: torch.device) -> Tuple[ClassDiscriminativeDDPM, Dict]:
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"❌ DDPM checkpoint 不存在: {checkpoint_path}")

    print(f"📥 加载 BCI2b DDPM checkpoint: {checkpoint_path}")
    ckpt = torch.load(checkpoint_path, map_location=device)

    # 从 checkpoint 获取维度信息（若缺失则用兜底）
    C = int(ckpt.get("channels", 3))
    T = int(ckpt.get("n_samples", 1000))
    num_classes = int(ckpt.get("num_classes", 2))
    fs = int(ckpt.get("fs", 250))

    # 组件
    eps_model = MultiScaleCondUNet(channels=C, num_classes=num_classes).to(device)
    classifier = EEGClassifier(channels=C, n_samples=T, num_classes=num_classes).to(device)

    # target
    if isinstance(ckpt, dict) and "target_psd" in ckpt and "target_laterality" in ckpt:
        target_psd = ckpt["target_psd"].to(device)
        target_lat = ckpt["target_laterality"].to(device)
    else:
        target_psd = torch.zeros(T // 2 + 1, device=device)
        target_lat = torch.zeros(num_classes, device=device)

    ddpm = ClassDiscriminativeDDPM(
        eps_model=eps_model,
        classifier=classifier,
        target_psd=target_psd,
        target_laterality=target_lat,
        n_timesteps=1000,
        channels=C,
        n_samples=T,
        fs=fs,
    ).to(device)

    # 加载 state_dict（优先 model_state_dict）
    if isinstance(ckpt, dict) and "model_state_dict" in ckpt:
        try:
            ddpm.load_state_dict(ckpt["model_state_dict"], strict=True)
        except RuntimeError as e:
            print(f"⚠️  strict=True 加载失败，改用 strict=False: {e}")
            ddpm.load_state_dict(ckpt["model_state_dict"], strict=False)
    else:
        ddpm.load_state_dict(ckpt)

    ddpm.eval()
    print("✅ DDPM 加载成功")
    return ddpm, ckpt


def generate_samples(ddpm: ClassDiscriminativeDDPM, n_samples_per_class: int, num_classes: int, guidance_scale: float, ddim_steps: int) -> Tuple[np.ndarray, np.ndarray]:
    ddpm.eval()
    gen_X, gen_y = [], []
    with torch.no_grad():
        for c in range(num_classes):
            n_batches = (n_samples_per_class + 49) // 50
            made = 0
            for _ in range(n_batches):
                bs = min(50, n_samples_per_class - made)
                if bs <= 0:
                    break
                yg = torch.full((bs,), c, dtype=torch.long, device=DEVICE)
                samples = ddpm.sample_ddim(bs, yg, steps=ddim_steps, guidance_scale=guidance_scale, device=str(DEVICE))
                gen_X.append(samples.cpu().numpy())
                gen_y.extend([c] * bs)
                made += bs
    return np.concatenate(gen_X, axis=0), np.array(gen_y, dtype=np.int64)


def within_subject_test(ddpm: ClassDiscriminativeDDPM, X: np.ndarray, y: np.ndarray, subjects: np.ndarray, num_classes: int, guidance_scale: float, ddim_steps: int) -> Dict:
    print("\n" + "=" * 70)
    print("1. BCI2b Within-Subject 测试（DDPM增强）")
    print("=" * 70)

    results = []
    unique_subjects = np.unique(subjects)

    for idx, subj_id in enumerate(unique_subjects):
        print(f"\n被试 {idx + 1}/{len(unique_subjects)} (内部ID={subj_id}):")
        mask = subjects == subj_id
        X_subj = X[mask]
        y_subj = y[mask]

        X_train, X_test, y_train, y_test = train_test_split(
            X_subj, y_subj, test_size=0.2, random_state=42, stratify=y_subj
        )

        samples_per_class = int(len(X_train) // num_classes)
        print(f"  训练: {len(X_train)}, 测试: {len(X_test)}, 生成: {samples_per_class}×{num_classes}")

        gen_X, gen_y = generate_samples(ddpm, samples_per_class, num_classes, guidance_scale, ddim_steps)
        gen_X = normalize_generated_data_to_real_stats(X_train, gen_X)

        X_train_aug = np.concatenate([X_train, gen_X], axis=0)
        y_train_aug = np.concatenate([y_train, gen_y], axis=0)

        clf = EEGClassifier(channels=X.shape[1], n_samples=X.shape[2], num_classes=num_classes).to(DEVICE)
        clf = pretrain_classifier(
            clf,
            torch.FloatTensor(X_train_aug),
            torch.LongTensor(y_train_aug),
            epochs=CLASSIFIER_EPOCHS,
            batch_size=CLASSIFIER_BATCH_SIZE,
            lr=CLASSIFIER_LR,
            device=str(DEVICE),
            verbose=False,
        )

        clf.eval()
        with torch.no_grad():
            pred = clf(torch.FloatTensor(X_test).to(DEVICE)).argmax(1).cpu().numpy()

        acc = accuracy_score(y_test, pred)
        results.append(acc)
        print(f"  准确率: {acc * 100:.2f}%")

    return {"mean": float(np.mean(results)), "std": float(np.std(results)), "per_subject": [float(a) for a in results]}


def cross_session_test(ddpm: ClassDiscriminativeDDPM, X: np.ndarray, y: np.ndarray, subjects: np.ndarray, sessions: np.ndarray, num_classes: int, guidance_scale: float, ddim_steps: int) -> Dict:
    print("\n" + "=" * 70)
    print("2. BCI2b Cross-Session 测试（T->E，DDPM增强）")
    print("=" * 70)

    results = []
    unique_subjects = np.unique(subjects)

    for idx, subj_id in enumerate(unique_subjects):
        print(f"\n被试 {idx + 1}/{len(unique_subjects)} (内部ID={subj_id}):")
        train_mask = (subjects == subj_id) & (sessions == 0)
        test_mask = (subjects == subj_id) & (sessions == 1)

        if not train_mask.any() or not test_mask.any():
            print("  警告: 缺少 T 或 E 会话，跳过。")
            continue

        X_train, y_train = X[train_mask], y[train_mask]
        X_test, y_test = X[test_mask], y[test_mask]

        samples_per_class = int(len(X_train) // num_classes)
        print(f"  训练(T): {len(X_train)}, 测试(E): {len(X_test)}, 生成: {samples_per_class}×{num_classes}")

        gen_X, gen_y = generate_samples(ddpm, samples_per_class, num_classes, guidance_scale, ddim_steps)
        gen_X = normalize_generated_data_to_real_stats(X_train, gen_X)

        X_train_aug = np.concatenate([X_train, gen_X], axis=0)
        y_train_aug = np.concatenate([y_train, gen_y], axis=0)

        clf = EEGClassifier(channels=X.shape[1], n_samples=X.shape[2], num_classes=num_classes).to(DEVICE)
        clf = pretrain_classifier(
            clf,
            torch.FloatTensor(X_train_aug),
            torch.LongTensor(y_train_aug),
            epochs=CLASSIFIER_EPOCHS,
            batch_size=CLASSIFIER_BATCH_SIZE,
            lr=CLASSIFIER_LR,
            device=str(DEVICE),
            verbose=False,
        )

        clf.eval()
        with torch.no_grad():
            pred = clf(torch.FloatTensor(X_test).to(DEVICE)).argmax(1).cpu().numpy()

        acc = accuracy_score(y_test, pred)
        results.append(acc)
        print(f"  准确率: {acc * 100:.2f}%")

    if not results:
        return {"mean": 0.0, "std": 0.0, "per_subject": []}
    return {"mean": float(np.mean(results)), "std": float(np.std(results)), "per_subject": [float(a) for a in results]}


def cross_subject_test(ddpm: ClassDiscriminativeDDPM, X: np.ndarray, y: np.ndarray, subjects: np.ndarray, sessions: np.ndarray, num_classes: int, guidance_scale: float, ddim_steps: int) -> Dict:
    print("\n" + "=" * 70)
    print("3. BCI2b Cross-Subject 测试（LOSO, T-only，DDPM增强）")
    print("=" * 70)

    results = []
    unique_subjects = np.unique(subjects)

    t_mask = sessions == 0
    if not t_mask.any():
        return {"mean": 0.0, "std": 0.0, "per_subject": []}

    X_T, y_T, subj_T = X[t_mask], y[t_mask], subjects[t_mask]

    for idx, test_subj in enumerate(unique_subjects):
        print(f"\n测试被试 {idx + 1}/{len(unique_subjects)} (内部ID={test_subj}):")
        train_mask = subj_T != test_subj
        test_mask = subj_T == test_subj

        if not train_mask.any() or not test_mask.any():
            print("  警告: T 会话样本不足，跳过。")
            continue

        X_train, y_train = X_T[train_mask], y_T[train_mask]
        X_test, y_test = X_T[test_mask], y_T[test_mask]

        samples_per_class = int(len(X_train) // num_classes)
        print(f"  训练: {len(X_train)}, 测试: {len(X_test)}, 生成: {samples_per_class}×{num_classes}")

        gen_X, gen_y = generate_samples(ddpm, samples_per_class, num_classes, guidance_scale, ddim_steps)
        gen_X = normalize_generated_data_to_real_stats(X_train, gen_X)

        X_train_aug = np.concatenate([X_train, gen_X], axis=0)
        y_train_aug = np.concatenate([y_train, gen_y], axis=0)

        clf = EEGClassifier(channels=X.shape[1], n_samples=X.shape[2], num_classes=num_classes).to(DEVICE)
        clf = pretrain_classifier(
            clf,
            torch.FloatTensor(X_train_aug),
            torch.LongTensor(y_train_aug),
            epochs=CLASSIFIER_EPOCHS,
            batch_size=CLASSIFIER_BATCH_SIZE,
            lr=CLASSIFIER_LR,
            device=str(DEVICE),
            verbose=False,
        )

        clf.eval()
        with torch.no_grad():
            pred = clf(torch.FloatTensor(X_test).to(DEVICE)).argmax(1).cpu().numpy()

        acc = accuracy_score(y_test, pred)
        results.append(acc)
        print(f"  准确率: {acc * 100:.2f}%")

    if not results:
        return {"mean": 0.0, "std": 0.0, "per_subject": []}
    return {"mean": float(np.mean(results)), "std": float(np.std(results)), "per_subject": [float(a) for a in results]}


def main() -> None:
    parser = argparse.ArgumentParser(description="BCI2b DDPM 三场景评估（单独版本）")
    parser.add_argument("--data_root", type=str, default="data/processed/BCI2b")
    parser.add_argument("--ddpm_ckpt", type=str, default="checkpoints/bci2b/trained_ddpm.pt")
    parser.add_argument("--guidance_scale", type=float, default=5.5)
    parser.add_argument("--ddim_steps", type=int, default=50)
    args = parser.parse_args()

    print("=" * 70)
    print("📊 BCI2b Class-Discriminative DDPM 三场景评估")
    print("=" * 70)
    print(f"设备: {DEVICE}\n")

    ddpm, ckpt = load_ddpm_bci2b(args.ddpm_ckpt, DEVICE)
    num_classes = int(ckpt.get("num_classes", 2))

    X, y, subjects, sessions, subj_map = load_bci2b_data(args.data_root, standardize=True)
    print(f"\n被试映射: {subj_map}")
    print(f"num_classes={num_classes}, guidance_scale={args.guidance_scale}, ddim_steps={args.ddim_steps}")

    results: Dict[str, Dict] = {}
    results["within_subject"] = within_subject_test(ddpm, X, y, subjects, num_classes, args.guidance_scale, args.ddim_steps)
    results["cross_session"] = cross_session_test(ddpm, X, y, subjects, sessions, num_classes, args.guidance_scale, args.ddim_steps)
    results["cross_subject"] = cross_subject_test(ddpm, X, y, subjects, sessions, num_classes, args.guidance_scale, args.ddim_steps)

    print("\n" + "=" * 70)
    print("📊 DDPM(BIC2b) 最终结果汇总")
    print("=" * 70)
    print(f"\n{'场景':<20} {'平均准确率':<15} {'标准差':<10}")
    print("-" * 50)
    print(f"{'Within-Subject':<20} {results['within_subject']['mean'] * 100:>6.2f}%        {results['within_subject']['std'] * 100:>6.2f}%")
    print(f"{'Cross-Session':<20} {results['cross_session']['mean'] * 100:>6.2f}%        {results['cross_session']['std'] * 100:>6.2f}%")
    print(f"{'Cross-Subject':<20} {results['cross_subject']['mean'] * 100:>6.2f}%        {results['cross_subject']['std'] * 100:>6.2f}%")

    os.makedirs("outputs/results", exist_ok=True)
    out = {
        "dataset": "BCI2b",
        "method": "Class-Discriminative DDPM",
        "ddpm_checkpoint": args.ddpm_ckpt,
        "guidance_scale": float(args.guidance_scale),
        "ddim_steps": int(args.ddim_steps),
        "within_subject": results["within_subject"],
        "cross_session": results["cross_session"],
        "cross_subject": results["cross_subject"],
    }

    out_path = "outputs/results/ddpm_bci2b_all_scenarios.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(f"\n💾 结果已保存到: {out_path}")

    print("\n" + "=" * 70)
    print("✅ BCI2b DDPM 三场景评估完成")
    print("=" * 70)


if __name__ == "__main__":
    main()



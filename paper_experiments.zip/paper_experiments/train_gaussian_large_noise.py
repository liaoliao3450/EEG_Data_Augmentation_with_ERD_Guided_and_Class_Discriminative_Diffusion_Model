#!/usr/bin/env python3
"""
生成更大噪声的Gaussian增强数据（用于可视化）

noise_scale = 0.5 (原来是0.1)
"""
import sys
import os
from pathlib import Path
import numpy as np

# 添加路径
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT / 'utils'))

from data_loader import load_bci2a_data

def main():
    print("="*60)
    print("生成大噪声Gaussian增强数据（用于可视化）")
    print("="*60)
    
    # 加载数据
    print("\n加载数据...")
    X, y, subjects, sessions = load_bci2a_data()
    
    # 只使用Session 1数据
    session1_mask = sessions == 0
    X_session1 = X[session1_mask]
    y_session1 = y[session1_mask]
    subjects_session1 = subjects[session1_mask]
    
    print(f"Session 1数据: {X_session1.shape}")
    print(f"被试数: {len(np.unique(subjects_session1))}")
    
    # 增大噪声强度
    noise_scale = 0.5  # 从0.1增大到0.5
    
    print(f"\n使用Gaussian Noise增强 (noise_scale={noise_scale})...")
    noise = np.random.randn(*X_session1.shape) * noise_scale
    X_augmented = X_session1 + noise
    
    print(f"增强样本: {X_augmented.shape}")
    print(f"数据范围: [{X_augmented.min():.3f}, {X_augmented.max():.3f}]")
    print(f"均值: {X_augmented.mean():.3f}, 标准差: {X_augmented.std():.3f}")
    
    # 保存
    os.makedirs('outputs/gaussian_samples', exist_ok=True)
    
    np.save('outputs/gaussian_samples/gaussian_large_augmented_session1.npy', X_augmented)
    np.save('outputs/gaussian_samples/gaussian_large_augmented_labels.npy', y_session1)
    np.save('outputs/gaussian_samples/gaussian_large_augmented_subjects.npy', subjects_session1)
    
    print(f"\n已保存:")
    print(f"  outputs/gaussian_samples/gaussian_large_augmented_session1.npy")
    print(f"  outputs/gaussian_samples/gaussian_large_augmented_labels.npy")
    print(f"  outputs/gaussian_samples/gaussian_large_augmented_subjects.npy")
    
    print("\n完成！")

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""
Pix2Pix风格的GAN数据增强

训练：用所有被试Session 1数据训练
增强：输入真实样本 -> 输出变体
"""
import sys
import os
from pathlib import Path
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# 添加路径
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT / 'core' / 'models' / 'gan'))
sys.path.insert(0, str(PROJECT_ROOT / 'utils'))

from pix2pix_1d import UNetGenerator1D, PatchDiscriminator1D
from data_loader import load_bci2a_data

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def train_pix2pix_gan(X, y, epochs=500, batch_size=32):
    """训练Pix2Pix GAN"""
    print("\n" + "="*60)
    print("训练Pix2Pix GAN（所有被试Session 1数据）")
    print("="*60)
    
    # 创建模型
    G = UNetGenerator1D(in_channels=22, out_channels=22, num_classes=4, cond_dim=32).to(DEVICE)
    D = PatchDiscriminator1D(in_channels=22, num_classes=4, cond_dim=32).to(DEVICE)
    
    # 优化器
    opt_G = optim.Adam(G.parameters(), lr=2e-4, betas=(0.5, 0.999))
    opt_D = optim.Adam(D.parameters(), lr=2e-4, betas=(0.5, 0.999))
    
    # 损失函数
    criterion_GAN = nn.MSELoss()
    criterion_L1 = nn.L1Loss()
    
    # 转换数据
    X_tensor = torch.FloatTensor(X)
    y_tensor = torch.LongTensor(y)
    
    n_samples = len(X)
    
    print(f"训练数据: {X.shape}")
    print(f"Epochs: {epochs}, Batch size: {batch_size}")
    print(f"设备: {DEVICE}\n")
    
    for epoch in range(epochs):
        G.train()
        D.train()
        
        # 随机打乱
        indices = torch.randperm(n_samples)
        
        epoch_loss_D = 0
        epoch_loss_G = 0
        n_batches = 0
        
        for i in range(0, n_samples, batch_size):
            batch_indices = indices[i:i+batch_size]
            real_X = X_tensor[batch_indices].to(DEVICE)
            real_y = y_tensor[batch_indices].to(DEVICE)
            current_batch_size = len(real_X)
            
            # 真实和假标签
            real_label = torch.ones(current_batch_size, 1, 1, device=DEVICE)
            fake_label = torch.zeros(current_batch_size, 1, 1, device=DEVICE)
            
            # ==================== 训练判别器 ====================
            opt_D.zero_grad()
            
            # 生成假样本
            fake_X = G(real_X, real_y)
            
            # 真实样本的判别
            pred_real = D(real_X, real_y)
            pred_real = nn.functional.adaptive_avg_pool1d(pred_real, 1)
            loss_D_real = criterion_GAN(pred_real, real_label)
            
            # 假样本的判别
            pred_fake = D(fake_X.detach(), real_y)
            pred_fake = nn.functional.adaptive_avg_pool1d(pred_fake, 1)
            loss_D_fake = criterion_GAN(pred_fake, fake_label)
            
            # 总判别器损失
            loss_D = (loss_D_real + loss_D_fake) * 0.5
            loss_D.backward()
            opt_D.step()
            
            epoch_loss_D += loss_D.item()
            
            # ==================== 训练生成器 ====================
            opt_G.zero_grad()
            
            # 生成假样本
            fake_X = G(real_X, real_y)
            
            # GAN损失
            pred_fake = D(fake_X, real_y)
            pred_fake = nn.functional.adaptive_avg_pool1d(pred_fake, 1)
            loss_GAN = criterion_GAN(pred_fake, real_label)
            
            # L1损失（保持与原始样本的相似性）
            loss_L1 = criterion_L1(fake_X, real_X)
            
            # 总生成器损失
            loss_G = loss_GAN + loss_L1 * 100  # L1权重
            loss_G.backward()
            opt_G.step()
            
            epoch_loss_G += loss_G.item()
            n_batches += 1
        
        if (epoch + 1) % 20 == 0:
            print(f"Epoch [{epoch+1}/{epochs}] - D_loss: {epoch_loss_D/n_batches:.4f}, G_loss: {epoch_loss_G/n_batches:.4f}")
    
    print("\n✅ Pix2Pix GAN训练完成")
    
    # 保存模型
    os.makedirs('checkpoints/gan', exist_ok=True)
    torch.save({
        'G': G.state_dict(),
        'D': D.state_dict()
    }, 'checkpoints/gan/pix2pix_gan_all_subjects_session1.pt')
    print("模型已保存到: checkpoints/gan/pix2pix_gan_all_subjects_session1.pt")
    
    return G

def augment_with_pix2pix_gan(G, X_real, y_real):
    """
    用Pix2Pix GAN对真实样本进行增强
    
    输入：真实样本
    输出：增强样本（变体）
    """
    print("\n" + "="*60)
    print("用Pix2Pix GAN进行数据增强")
    print("="*60)
    
    G.eval()
    
    X_tensor = torch.FloatTensor(X_real).to(DEVICE)
    y_tensor = torch.LongTensor(y_real).to(DEVICE)
    
    with torch.no_grad():
        # 生成增强样本
        X_augmented = G(X_tensor, y_tensor)
    
    X_augmented = X_augmented.cpu().numpy()
    
    print(f"  原始样本: {X_real.shape}")
    print(f"  增强样本: {X_augmented.shape}")
    print(f"  数据范围: [{X_augmented.min():.3f}, {X_augmented.max():.3f}]")
    print(f"  均值: {X_augmented.mean():.3f}, 标准差: {X_augmented.std():.3f}")
    
    return X_augmented

def main():
    print("="*60)
    print("Pix2Pix GAN数据增强方法")
    print("="*60)
    print(f"设备: {DEVICE}\n")
    
    # 加载数据
    print("加载BCI数据...")
    X, y, subjects, sessions = load_bci2a_data()
    
    # 所有被试的Session 1数据用于训练
    session1_mask = sessions == 0
    X_session1 = X[session1_mask]
    y_session1 = y[session1_mask]
    subjects_session1 = subjects[session1_mask]
    
    print(f"Session 1数据: {X_session1.shape}")
    print(f"类别分布: {np.bincount(y_session1)}")
    print()
    
    # ==================== 训练Pix2Pix GAN ====================
    print("="*60)
    print("1/2: 训练Pix2Pix GAN（所有被试Session 1数据）")
    print("="*60)
    
    gan_model = train_pix2pix_gan(X_session1, y_session1, epochs=500, batch_size=32)
    
    # ==================== 数据增强 ====================
    print("\n" + "="*60)
    print("2/2: 对Session 1数据进行增强")
    print("="*60)
    
    # 对每个真实样本生成一个增强样本
    X_augmented = augment_with_pix2pix_gan(gan_model, X_session1, y_session1)
    
    # 保存增强样本
    os.makedirs('outputs/gan_samples', exist_ok=True)
    np.save('outputs/gan_samples/pix2pix_augmented_session1.npy', X_augmented)
    np.save('outputs/gan_samples/pix2pix_augmented_labels.npy', y_session1)
    np.save('outputs/gan_samples/pix2pix_augmented_subjects.npy', subjects_session1)
    
    print("\n✅ Pix2Pix GAN增强样本已保存")
    print(f"  样本: outputs/gan_samples/pix2pix_augmented_session1.npy")
    print(f"  标签: outputs/gan_samples/pix2pix_augmented_labels.npy")
    print(f"  被试: outputs/gan_samples/pix2pix_augmented_subjects.npy")

    # 额外：为t-SNE最终可视化保存GAN缓存
    tsne_cache_dir = 'outputs/figures/tsne/cached_data'
    os.makedirs(tsne_cache_dir, exist_ok=True)
    tsne_cache_path = os.path.join(tsne_cache_dir, 'gan_data.npz')
    np.savez(tsne_cache_path, X=X_augmented, y=y_session1)
    print(f"  t-SNE缓存(GAN): {tsne_cache_path}")
    
    # ==================== 总结 ====================
    print("\n" + "="*60)
    print("总结")
    print("="*60)
    
    print(f"\n原始数据: {X_session1.shape}")
    print(f"增强数据: {X_augmented.shape}")
    
    print("\n说明:")
    print("  1. Pix2Pix GAN在所有被试Session 1数据上训练")
    print("  2. 输入真实样本，输出增强样本（变体）")
    print("  3. 使用U-Net架构保持样本结构")
    print("  4. L1损失确保增强样本与原始样本相似")
    print("  5. 增强样本是基于真实样本的变体，不是凭空生成")
    
    print("\n下一步: 用增强数据训练分类器，在Session 2上测试")

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""
DDPM数据增强

注意：DDPM与VAE/GAN不同
- VAE/GAN: 基于真实样本增强 (X_real → X_augmented)
- DDPM: 从噪声生成 (noise + class → X_generated)

为了公平对比，我们也让DDPM生成与真实样本对应的增强样本
方法：为每个真实样本生成一个相同类别的样本
"""
import sys
import os
from pathlib import Path
import torch
import numpy as np

# 添加路径
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT / 'core' / 'models' / 'ddpm'))
sys.path.insert(0, str(PROJECT_ROOT / 'utils'))

from class_discriminative import ClassDiscriminativeDDPM
from data_loader import load_bci2a_data

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def load_ddpm_model():
    """加载训练好的DDPM模型"""
    print("\n" + "="*60)
    print("加载DDPM模型")
    print("="*60)
    
    # 加载checkpoint
    checkpoint_path = 'checkpoints/best_class_discriminative.pt'
    
    if not os.path.exists(checkpoint_path):
        print(f"❌ 模型文件不存在: {checkpoint_path}")
        print("请先训练DDPM模型")
        return None
    
    checkpoint = torch.load(checkpoint_path, map_location=DEVICE)
    
    # 从checkpoint中提取模型状态
    # 注意：checkpoint可能只包含state_dict，不包含完整模型结构
    # 我们需要重新创建模型结构
    
    from class_discriminative import MultiScaleCondUNet, EEGClassifier, ClassDiscriminativeDDPM
    
    # 创建模型组件
    eps_model = MultiScaleCondUNet(channels=22, num_classes=4).to(DEVICE)
    classifier = EEGClassifier(channels=22, n_samples=1000, num_classes=4).to(DEVICE)
    
    # 创建目标统计量（使用默认值）
    target_psd = torch.zeros(501).to(DEVICE)  # rfft输出长度
    target_laterality = torch.zeros(4).to(DEVICE)
    
    # 创建DDPM模型
    ddpm = ClassDiscriminativeDDPM(
        eps_model=eps_model,
        classifier=classifier,
        target_psd=target_psd,
        target_laterality=target_laterality,
        n_timesteps=1000,
        channels=22,
        n_samples=1000,
        fs=250
    ).to(DEVICE)
    
    # 加载权重
    if isinstance(checkpoint, dict) and 'model' in checkpoint:
        ddpm.load_state_dict(checkpoint['model'])
        print(f"模型加载成功: {checkpoint_path}")
        print(f"   Epoch: {checkpoint.get('epoch', 'unknown')}")
    else:
        ddpm.load_state_dict(checkpoint)
        print(f"模型加载成功: {checkpoint_path}")
    
    ddpm.eval()
    print(f"   设备: {DEVICE}")
    
    return ddpm

def augment_with_ddpm(ddpm, X_real, y_real, guidance_scale=3.0):
    """
    用DDPM生成增强样本
    
    方法：为每个真实样本生成一个相同类别的样本
    注意：DDPM是从噪声生成，不是基于真实样本
    """
    print("\n" + "="*60)
    print("用DDPM生成增强样本")
    print("="*60)
    
    n_samples = len(X_real)
    
    print(f"  真实样本: {X_real.shape}")
    print(f"  生成方式: 从噪声生成（不基于真实样本）")
    print(f"  引导强度: {guidance_scale}")
    
    # 为每个类别生成样本
    X_augmented_list = []
    
    unique_classes = np.unique(y_real)
    for c in unique_classes:
        mask = y_real == c
        n_class = mask.sum()
        
        print(f"\n  生成类别 {c}: {n_class} 个样本")
        
        # 生成该类别的样本
        y_tensor = torch.full((n_class,), c, dtype=torch.long, device=DEVICE)
        
        with torch.no_grad():
            samples = ddpm.sample_ddim(
                batch_size=n_class,
                y=y_tensor,
                steps=50,
                guidance_scale=guidance_scale,
                device=DEVICE
            )
        
        X_augmented_list.append(samples.cpu().numpy())
    
    # 合并所有类别
    X_augmented = np.concatenate(X_augmented_list, axis=0)
    
    # 重新排序以匹配原始顺序
    # 创建索引映射
    indices = []
    for c in unique_classes:
        mask = y_real == c
        indices.extend(np.where(mask)[0])
    
    # 反向映射
    inverse_indices = np.argsort(indices)
    X_augmented = X_augmented[inverse_indices]
    
    print(f"\n  增强样本: {X_augmented.shape}")
    print(f"  数据范围: [{X_augmented.min():.3f}, {X_augmented.max():.3f}]")
    print(f"  均值: {X_augmented.mean():.3f}, 标准差: {X_augmented.std():.3f}")
    
    return X_augmented

def main():
    print("="*60)
    print("DDPM数据增强方法")
    print("="*60)
    print(f"设备: {DEVICE}\n")
    
    # 加载数据
    print("加载BCI数据...")
    X, y, subjects, sessions = load_bci2a_data()
    
    # 所有被试的Session 1数据
    session1_mask = sessions == 0
    X_session1 = X[session1_mask]
    y_session1 = y[session1_mask]
    subjects_session1 = subjects[session1_mask]
    
    print(f"Session 1数据: {X_session1.shape}")
    print(f"类别分布: {np.bincount(y_session1)}")
    print()
    
    # ==================== 加载DDPM模型 ====================
    print("="*60)
    print("1/2: 加载训练好的DDPM模型")
    print("="*60)
    
    ddpm_model = load_ddpm_model()
    
    if ddpm_model is None:
        print("\n❌ 无法加载DDPM模型，退出")
        return
    
    # ==================== 生成增强样本 ====================
    print("\n" + "="*60)
    print("2/2: 生成增强样本")
    print("="*60)
    
    X_augmented = augment_with_ddpm(ddpm_model, X_session1, y_session1, guidance_scale=3.0)
    
    # 保存增强样本（通用位置）
    os.makedirs('outputs/ddpm_samples', exist_ok=True)
    np.save('outputs/ddpm_samples/ddpm_augmented_session1.npy', X_augmented)
    np.save('outputs/ddpm_samples/ddpm_augmented_labels.npy', y_session1)
    np.save('outputs/ddpm_samples/ddpm_augmented_subjects.npy', subjects_session1)
    
    print("\n✅ DDPM增强样本已保存")
    print(f"  样本: outputs/ddpm_samples/ddpm_augmented_session1.npy")
    print(f"  标签: outputs/ddpm_samples/ddpm_augmented_labels.npy")
    print(f"  被试: outputs/ddpm_samples/ddpm_augmented_subjects.npy")

    # 额外：为t-SNE最终可视化保存统一缓存文件
    tsne_cache_dir = 'outputs/figures/tsne/cached_data'
    os.makedirs(tsne_cache_dir, exist_ok=True)
    tsne_cache_path = os.path.join(tsne_cache_dir, 'class_discriminative_ddpm_data.npz')
    np.savez(tsne_cache_path, X=X_augmented, y=y_session1)
    print(f"  t-SNE缓存: {tsne_cache_path}")
    
    # ==================== 总结 ====================
    print("\n" + "="*60)
    print("总结")
    print("="*60)
    
    print(f"\n原始数据: {X_session1.shape}")
    print(f"增强数据: {X_augmented.shape}")
    
    print("\n说明:")
    print("  1. DDPM从噪声生成样本（不基于真实样本）")
    print("  2. 使用分类器引导确保类别判别性")
    print("  3. 为每个真实样本生成一个相同类别的样本")
    print("  4. 生成样本与真实样本一一对应（按类别）")
    
    print("\n重要区别:")
    print("  - VAE/GAN: X_real[i] → X_augmented[i] (基于真实样本)")
    print("  - DDPM: noise + class[i] → X_augmented[i] (从噪声生成)")
    
    print("\n下一步: 计算质量指标，对比所有方法")

if __name__ == '__main__':
    main()

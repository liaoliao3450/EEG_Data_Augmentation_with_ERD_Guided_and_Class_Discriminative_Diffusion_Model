#!/usr/bin/env python3
"""
Class-Discriminative DDPM方法评估

包含三种测试场景：
1. Within-Subject (被试内)
2. Cross-Session (跨会话)
3. Cross-Subject (跨被试, LOSO)

使用预训练的DDPM模型
"""
import sys, os, torch, numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

sys.path.insert(0, 'core/models/ddpm')
sys.path.insert(0, 'utils')
from class_discriminative import (
    EEGClassifier, pretrain_classifier,
    MultiScaleCondUNet, ClassDiscriminativeDDPM
)
from data_loader import load_bci2a_data, get_subject_session_data

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 与敏感度分析脚本保持一致的分类器训练超参数
CLASSIFIER_EPOCHS = 200
CLASSIFIER_BATCH_SIZE = 32
CLASSIFIER_LR = 1e-3

def normalize_generated_data_to_real_stats(X_real: np.ndarray, X_gen: np.ndarray) -> np.ndarray:
    """
    将生成数据的统计特性对齐到真实数据（与 utils/data_loader.py 一致的逐通道标准化空间）:

    data_loader 的标准化方式为:
        X = (X - mean(axis=(0,2))) / std(axis=(0,2))

    这里对齐逻辑为:
        先把生成数据按自身逐通道 mean/std 标准化到“近似 z-score”空间，
        再映射到真实训练数据的逐通道 mean/std 空间。

    这样能保证增强数据与当前折/场景的 X_train 在同一标准化空间中使用。
    """
    X_real = X_real.astype(np.float32)
    X_gen = X_gen.astype(np.float32)

    # 逐通道统计 (1, C, 1)
    real_mean = X_real.mean(axis=(0, 2), keepdims=True)
    real_std = X_real.std(axis=(0, 2), keepdims=True)
    gen_mean = X_gen.mean(axis=(0, 2), keepdims=True)
    gen_std = X_gen.std(axis=(0, 2), keepdims=True)

    eps = 1e-8
    if float(np.max(gen_std)) < eps:
        print("⚠️  生成数据逐通道标准差过小，跳过对齐")
        return X_gen

    # 生成数据先做逐通道标准化，再对齐到真实训练集统计量
    X_gen_norm = (X_gen - gen_mean) / (gen_std + eps)
    X_gen_aligned = X_gen_norm * (real_std + eps) + real_mean
    return X_gen_aligned

def load_class_discriminative_ddpm(device='cuda', checkpoint_path='checkpoints/trained_ddpm.pt'):
    """
    加载已训练的Class-Discriminative DDPM模型
    与敏感度分析脚本 load_ddpm_model 保持一致：
      - 使用同一类 checkpoint（含 target_psd / target_laterality / model_state_dict）
      - 使用相同的 MultiScaleCondUNet + EEGClassifier 结构
    """
    if not os.path.exists(checkpoint_path):
        print(f"❌ 模型文件不存在: {checkpoint_path}")
        return None, False

    print(f"📥 加载模型: {checkpoint_path}")
    checkpoint = torch.load(checkpoint_path, map_location=device)

    # 创建模型组件（与敏感度脚本相同）
    eps_model = MultiScaleCondUNet(channels=22, num_classes=4).to(device)
    classifier = EEGClassifier(channels=22, n_samples=1000, num_classes=4).to(device)

    # 从 checkpoint 中读取 target_psd / target_laterality（如果存在）
    if isinstance(checkpoint, dict) and 'target_psd' in checkpoint and 'target_laterality' in checkpoint:
        target_psd = checkpoint['target_psd'].to(device)
        target_laterality = checkpoint['target_laterality'].to(device)
    else:
        # 兜底：如果老 checkpoint 里没有这些字段，就用零向量
        target_psd = torch.zeros(501).to(device)
        target_laterality = torch.zeros(4).to(device)

    ddpm = ClassDiscriminativeDDPM(
        eps_model, classifier,
        target_psd, target_laterality,
        n_timesteps=1000, channels=22, n_samples=1000, fs=250
    ).to(device)

    # 加载 state_dict（与敏感度脚本一致，优先用 'model_state_dict'）
    if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
        try:
            ddpm.load_state_dict(checkpoint['model_state_dict'], strict=True)
        except RuntimeError as e:
            if 'Missing key(s)' in str(e) or 'Unexpected key(s)' in str(e):
                print("  警告: checkpoint 参数不完全匹配，使用 strict=False 加载 ...")
                ddpm.load_state_dict(checkpoint['model_state_dict'], strict=False)
            else:
                raise
    else:
        ddpm.load_state_dict(checkpoint)

    ddpm.eval()
    print("✅ 模型加载成功")
    return ddpm, True

def generate_samples(ddpm, n_samples_per_class, guidance_scale=5.5):
    """生成样本"""
    ddpm.eval()
    gen_X, gen_y = [], []
    
    with torch.no_grad():
        for c in range(4):
            n_batches = (n_samples_per_class + 49) // 50
            for _ in range(n_batches):
                batch_size = min(50, n_samples_per_class - len([y for y in gen_y if y == c]))
                if batch_size <= 0:
                    break
                yg = torch.full((batch_size,), c, dtype=torch.long, device=DEVICE)
                samples = ddpm.sample_ddim(batch_size, yg, steps=50, guidance_scale=guidance_scale, device=DEVICE)
                gen_X.append(samples.cpu().numpy())
                gen_y.extend([c] * batch_size)
    
    return np.concatenate(gen_X), np.array(gen_y)

def within_subject_test(ddpm, X, y, subjects):
    """被试内测试"""
    print("\n" + "="*70)
    print("1. Within-Subject 测试")
    print("="*70)
    
    results = []
    n_subjects = len(np.unique(subjects))
    
    for subj_id in range(n_subjects):
        print(f"\n被试 {subj_id+1}/{n_subjects}:")
        
        mask = subjects == subj_id
        X_subj = X[mask]
        y_subj = y[mask]
        
        X_train, X_test, y_train, y_test = train_test_split(
            X_subj, y_subj, test_size=0.2, random_state=42, stratify=y_subj
        )
        
        samples_per_class = len(X_train) // 4
        print(f"  训练: {len(X_train)}, 测试: {len(X_test)}, 生成: {samples_per_class}×4")
        
        # 生成数据
        gen_X, gen_y = generate_samples(ddpm, samples_per_class)
        # 生成数据做全局标准化对齐到真实训练数据
        gen_X = normalize_generated_data_to_real_stats(X_train, gen_X)

        # 合并（真实 + 增强），用于训练分类器
        X_train_aug = np.concatenate([X_train, gen_X])
        y_train_aug = np.concatenate([y_train, gen_y])

        # 使用与敏感度分析一致的协议：在增强后的训练集上重新训练一个 EEGNet 分类器
        clf = EEGClassifier(channels=22, n_samples=1000, num_classes=4).to(DEVICE)
        clf = pretrain_classifier(
            clf,
            torch.FloatTensor(X_train_aug),
            torch.LongTensor(y_train_aug),
            epochs=CLASSIFIER_EPOCHS,
            batch_size=CLASSIFIER_BATCH_SIZE,
            lr=CLASSIFIER_LR,
            device=DEVICE,
            verbose=False
        )
        clf.eval()

        # 评估
        with torch.no_grad():
            pred = clf(torch.FloatTensor(X_test).to(DEVICE)).argmax(1).cpu().numpy()
        
        acc = accuracy_score(y_test, pred)
        results.append(acc)
        print(f"  准确率: {acc*100:.2f}%")
    
    mean_acc = np.mean(results)
    std_acc = np.std(results)
    
    print(f"\n平均: {mean_acc*100:.2f}% ± {std_acc*100:.2f}%")
    
    return {
        'mean': float(mean_acc),
        'std': float(std_acc),
        'per_subject': [float(acc) for acc in results]
    }

def cross_session_test(ddpm, X, y, subjects, sessions):
    """跨会话测试"""
    print("\n" + "="*70)
    print("2. Cross-Session 测试")
    print("="*70)
    
    results = []
    n_subjects = len(np.unique(subjects))
    
    for subj_id in range(n_subjects):
        print(f"\n被试 {subj_id+1}/{n_subjects}:")
        
        train_mask = (subjects == subj_id) & (sessions == 0)
        test_mask = (subjects == subj_id) & (sessions == 1)
        
        X_train = X[train_mask]
        y_train = y[train_mask]
        X_test = X[test_mask]
        y_test = y[test_mask]
        
        samples_per_class = len(X_train) // 4  # 每类72个
        print(f"  Session 1训练: {len(X_train)}, Session 2测试: {len(X_test)}, 生成: {samples_per_class}×4")
        
        # 生成数据
        gen_X, gen_y = generate_samples(ddpm, samples_per_class)
        # 生成数据做全局标准化对齐到真实训练数据
        gen_X = normalize_generated_data_to_real_stats(X_train, gen_X)

        # 合并（真实 + 增强），用于训练分类器
        X_train_aug = np.concatenate([X_train, gen_X])
        y_train_aug = np.concatenate([y_train, gen_y])

        # 在跨会话增强训练集上重新训练一个 EEGNet 分类器（与敏感度分析一致）
        clf = EEGClassifier(channels=22, n_samples=1000, num_classes=4).to(DEVICE)
        clf = pretrain_classifier(
            clf,
            torch.FloatTensor(X_train_aug),
            torch.LongTensor(y_train_aug),
            epochs=CLASSIFIER_EPOCHS,
            batch_size=CLASSIFIER_BATCH_SIZE,
            lr=CLASSIFIER_LR,
            device=DEVICE,
            verbose=False
        )
        clf.eval()

        # 评估
        with torch.no_grad():
            pred = clf(torch.FloatTensor(X_test).to(DEVICE)).argmax(1).cpu().numpy()
        
        acc = accuracy_score(y_test, pred)
        results.append(acc)
        print(f"  准确率: {acc*100:.2f}%")
    
    mean_acc = np.mean(results)
    std_acc = np.std(results)
    
    print(f"\n平均: {mean_acc*100:.2f}% ± {std_acc*100:.2f}%")
    
    return {
        'mean': float(mean_acc),
        'std': float(std_acc),
        'per_subject': [float(acc) for acc in results]
    }

def cross_subject_test(ddpm, X, y, subjects, sessions):
    """跨被试测试（LOSO）"""
    print("\n" + "="*70)
    print("3. Cross-Subject 测试 (LOSO)")
    print("="*70)
    
    results = []
    n_subjects = len(np.unique(subjects))
    
    for test_subj in range(n_subjects):
        print(f"\n测试被试 {test_subj+1}/{n_subjects}:")
        
        train_mask = (subjects != test_subj) & (sessions == 0)
        test_mask = (subjects == test_subj) & (sessions == 0)
        
        X_train = X[train_mask]
        y_train = y[train_mask]
        X_test = X[test_mask]
        y_test = y[test_mask]
        
        samples_per_class = len(X_train) // 4  # 8个被试×72 = 576/4 = 144
        print(f"  训练: {len(X_train)} (8个被试), 测试: {len(X_test)}, 生成: {samples_per_class}×4")
        
        # 生成数据
        gen_X, gen_y = generate_samples(ddpm, samples_per_class)
        # 生成数据做全局标准化对齐到真实训练数据
        gen_X = normalize_generated_data_to_real_stats(X_train, gen_X)

        # 合并（真实 + 增强），用于训练分类器
        X_train_aug = np.concatenate([X_train, gen_X])
        y_train_aug = np.concatenate([y_train, gen_y])

        # 在跨被试增强训练集上重新训练一个 EEGNet 分类器（与敏感度分析一致）
        clf = EEGClassifier(channels=22, n_samples=1000, num_classes=4).to(DEVICE)
        clf = pretrain_classifier(
            clf,
            torch.FloatTensor(X_train_aug),
            torch.LongTensor(y_train_aug),
            epochs=CLASSIFIER_EPOCHS,
            batch_size=CLASSIFIER_BATCH_SIZE,
            lr=CLASSIFIER_LR,
            device=DEVICE,
            verbose=False
        )
        clf.eval()

        # 评估
        with torch.no_grad():
            pred = clf(torch.FloatTensor(X_test).to(DEVICE)).argmax(1).cpu().numpy()
        
        acc = accuracy_score(y_test, pred)
        results.append(acc)
        print(f"  准确率: {acc*100:.2f}%")
    
    mean_acc = np.mean(results)
    std_acc = np.std(results)
    
    print(f"\n平均: {mean_acc*100:.2f}% ± {std_acc*100:.2f}%")
    
    return {
        'mean': float(mean_acc),
        'std': float(std_acc),
        'per_subject': [float(acc) for acc in results]
    }

def main():
    print("="*70)
    print("📊 Class-Discriminative DDPM方法评估")
    print("="*70)
    print(f"设备: {DEVICE}\n")
    
    # 加载预训练的Class-Discriminative DDPM模型
    print("📥 加载预训练的Class-Discriminative DDPM模型...")
    ddpm, loaded = load_class_discriminative_ddpm(DEVICE)
    
    if not loaded:
        print("❌ 未找到预训练的DDPM模型！")
        print("请先运行: python train_class_discriminative_ddpm.py")
        return
    
    print("✅ Class-Discriminative DDPM加载成功\n")
    
    # 加载数据
    X, y, subjects, sessions = load_bci2a_data()
    print(f"被试数: {len(np.unique(subjects))}")
    print(f"会话数: {len(np.unique(sessions))}")
    
    # 三种测试
    results = {}
    results['within_subject'] = within_subject_test(ddpm, X, y, subjects)
    results['cross_session'] = cross_session_test(ddpm, X, y, subjects, sessions)
    results['cross_subject'] = cross_subject_test(ddpm, X, y, subjects, sessions)
    
    # 汇总
    print("\n" + "="*70)
    print("📊 Class-Discriminative DDPM 最终结果汇总")
    print("="*70)
    
    print(f"\n{'场景':<20} {'平均准确率':<15} {'标准差':<10}")
    print("-" * 50)
    print(f"{'Within-Subject':<20} {results['within_subject']['mean']*100:>6.2f}%        {results['within_subject']['std']*100:>6.2f}%")
    print(f"{'Cross-Session':<20} {results['cross_session']['mean']*100:>6.2f}%        {results['cross_session']['std']*100:>6.2f}%")
    print(f"{'Cross-Subject':<20} {results['cross_subject']['mean']*100:>6.2f}%        {results['cross_subject']['std']*100:>6.2f}%")
    
    # 保存
    import json
    os.makedirs('outputs/results', exist_ok=True)
    
    final_results = {
        'method': 'Class-Discriminative DDPM',
        'within_subject': results['within_subject'],
        'cross_session': results['cross_session'],
        'cross_subject': results['cross_subject']
    }
    
    with open('outputs/results/ddpm_all_scenarios.json', 'w') as f:
        json.dump(final_results, f, indent=2)
    
    print(f"\n💾 结果已保存到: outputs/results/ddpm_all_scenarios.json")
    print("\n" + "="*70)
    print("✅ Class-Discriminative DDPM评估完成！")
    print("="*70)

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""
正确生成DDPM样本用于质量指标计算

使用 trained_ddpm.pt 模型生成2000个样本（每类500个）
这是用于论文实验的DDPM模型（包含ERD+分类器引导）
"""
import sys
import os
import torch
import numpy as np

sys.path.insert(0, 'utils')
from load_models import load_trained_ddpm

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def main():
    print("="*70)
    print("生成DDPM样本用于质量指标计算")
    print("="*70)
    print(f"设备: {DEVICE}\n")
    
    # 加载训练好的DDPM
    print("📥 加载训练好的DDPM模型...")
    ddpm, loaded = load_trained_ddpm(DEVICE)
    
    if not loaded:
        print("❌ 未找到 checkpoints/trained_ddpm.pt")
        print("请先运行: python train_ddpm_once.py")
        return
    
    print("✅ DDPM模型加载成功")
    print(f"   - 模型类型: ClassDiscriminativeDDPM")
    print(f"   - 包含: ERD损失 + 频谱损失 + 分类器引导")
    print()
    
    # 生成样本
    print("🎲 生成样本...")
    print("   - 每类: 500个样本")
    print("   - 总计: 2000个样本")
    print("   - 采样方法: DDIM (50步)")
    print("   - 引导强度: 3.0")
    print()
    
    ddpm.eval()
    gen_X = []
    gen_y = []
    
    with torch.no_grad():
        for c in range(4):
            print(f"   生成类别 {c}...")
            # 每次生成50个，共10批
            for batch_idx in range(10):
                yg = torch.full((50,), c, dtype=torch.long, device=DEVICE)
                samples = ddpm.sample_ddim(50, yg, steps=50, guidance_scale=3.0)
                gen_X.append(samples.cpu().numpy())
                gen_y.extend([c] * 50)
                
                if (batch_idx + 1) % 5 == 0:
                    print(f"      进度: {(batch_idx + 1) * 50}/500")
    
    # 合并
    gen_X = np.concatenate(gen_X, axis=0)  # [2000, 22, 1000]
    gen_y = np.array(gen_y)  # [2000]
    
    print()
    print(f"✅ 生成完成")
    print(f"   - 形状: {gen_X.shape}")
    print(f"   - 标签: {gen_y.shape}")
    print(f"   - 每类数量: {[(gen_y == c).sum() for c in range(4)]}")
    print()
    
    # 保存
    os.makedirs('outputs/ddpm_samples', exist_ok=True)
    
    np.save('outputs/ddpm_samples/ddpm_samples.npy', gen_X)
    np.save('outputs/ddpm_samples/ddpm_labels.npy', gen_y)
    
    print("💾 样本已保存:")
    print("   - outputs/ddpm_samples/ddpm_samples.npy")
    print("   - outputs/ddpm_samples/ddpm_labels.npy")
    print()
    
    # 基本统计
    print("📊 基本统计:")
    print(f"   - 均值: {gen_X.mean():.6f}")
    print(f"   - 标准差: {gen_X.std():.6f}")
    print(f"   - 最小值: {gen_X.min():.6f}")
    print(f"   - 最大值: {gen_X.max():.6f}")
    print()
    
    print("="*70)
    print("✅ DDPM样本生成完成！")
    print("="*70)
    print()
    print("下一步: 运行质量指标计算")
    print("  python experiments/paper_experiments/6_compute_quality_metrics_from_saved.py")

if __name__ == '__main__':
    main()

"""
分析PSD对比图的结果
验证生成数据的频谱特性是否合理
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

import numpy as np
import torch
from scipy import signal
from scipy.stats import pearsonr
from pathlib import Path

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent

# 导入数据加载
from utils.data_loader import load_bci2a_data

# 导入DDPM模型
sys.path.insert(0, str(PROJECT_ROOT / 'core' / 'models' / 'ddpm'))
from class_discriminative import MultiScaleCondUNet, EEGClassifier, ClassDiscriminativeDDPM

def load_real_data(subject_id=1, session_id=1):
    """加载真实实验数据"""
    X, y, subjects, sessions = load_bci2a_data()
    mask = (subjects == subject_id) & (sessions == session_id)
    return X[mask], y[mask]

def load_ddpm_model():
    """加载训练好的DDPM模型"""
    checkpoint_path = 'checkpoints/trained_ddpm.pt'
    if not os.path.exists(checkpoint_path):
        return None
    
    checkpoint = torch.load(checkpoint_path, map_location=DEVICE)
    eps = MultiScaleCondUNet(channels=22, num_classes=4).to(DEVICE)
    clf = EEGClassifier(channels=22, n_samples=1000, num_classes=4).to(DEVICE)
    
    if isinstance(checkpoint, dict) and 'target_psd' in checkpoint and 'target_laterality' in checkpoint:
        target_psd = checkpoint['target_psd'].to(DEVICE)
        target_laterality = checkpoint['target_laterality'].to(DEVICE)
    else:
        target_psd = torch.zeros(501).to(DEVICE)
        target_laterality = torch.zeros(4).to(DEVICE)
    
    ddpm = ClassDiscriminativeDDPM(
        eps, clf, target_psd, target_laterality,
        n_timesteps=1000, channels=22, n_samples=1000, fs=250
    ).to(DEVICE)
    
    if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
        try:
            ddpm.load_state_dict(checkpoint['model_state_dict'], strict=True)
        except RuntimeError:
            ddpm.load_state_dict(checkpoint['model_state_dict'], strict=False)
    else:
        ddpm.load_state_dict(checkpoint, strict=False)
    
    ddpm.eval()
    return ddpm

def normalize_generated_data_to_real_stats(real_data, gen_data):
    """将生成数据对齐到真实数据的统计特性"""
    real_data = real_data.astype(np.float32)
    gen_data = gen_data.astype(np.float32)
    
    real_mean = real_data.mean(axis=(0, 2), keepdims=True)
    real_std = real_data.std(axis=(0, 2), keepdims=True)
    gen_mean = gen_data.mean(axis=(0, 2), keepdims=True)
    gen_std = gen_data.std(axis=(0, 2), keepdims=True)
    
    eps = 1e-8
    if float(np.max(gen_std)) < eps:
        return gen_data
    
    X_gen_norm = (gen_data - gen_mean) / (gen_std + eps)
    X_gen_aligned = X_gen_norm * (real_std + eps) + real_mean
    return X_gen_aligned

def generate_ddpm_samples(ddpm, n_samples_per_class=25):
    """使用DDPM生成样本"""
    ddpm.eval()
    gen_X, gen_y = [], []
    
    with torch.no_grad():
        for c in range(4):
            yg = torch.full((n_samples_per_class,), c, dtype=torch.long, device=DEVICE)
            samples = ddpm.sample_ddim(n_samples_per_class, yg, steps=50, guidance_scale=5.2)
            gen_X.append(samples.cpu().numpy())
            gen_y.extend([c] * n_samples_per_class)
    
    return np.concatenate(gen_X), np.array(gen_y)

def compute_psd(data, fs=250, nperseg=256):
    """计算功率谱密度"""
    psds = []
    for i in range(len(data)):
        channel_psds = []
        for ch in range(data.shape[1]):
            f, psd = signal.welch(data[i, ch, :], fs=fs, nperseg=nperseg)
            channel_psds.append(psd)
        psds.append(np.mean(channel_psds, axis=0))
    
    mean_psd = np.mean(psds, axis=0)
    return f, mean_psd

def compute_band_power(psd, freqs, fmin, fmax):
    """计算频段功率"""
    mask = (freqs >= fmin) & (freqs <= fmax)
    return np.mean(psd[mask])

def analyze_psd_results(real_data, real_labels, gen_data, gen_labels):
    """分析PSD结果"""
    print("\n" + "="*70)
    print("PSD结果分析")
    print("="*70)
    
    # 定义频段
    bands = {
        'Delta (1-4 Hz)': (1, 4),
        'Theta (4-8 Hz)': (4, 8),
        'Alpha (8-13 Hz)': (8, 13),
        'Beta (13-30 Hz)': (13, 30),
        'Gamma (30-50 Hz)': (30, 50)
    }
    
    class_names = ['Left Hand', 'Right Hand', 'Feet', 'Tongue']
    
    print("\n【1. 整体PSD相关性】")
    f_real, psd_real = compute_psd(real_data)
    f_gen, psd_gen = compute_psd(gen_data)
    
    # 确保频率轴一致
    min_len = min(len(psd_real), len(psd_gen))
    psd_real = psd_real[:min_len]
    psd_gen = psd_gen[:min_len]
    f_real = f_real[:min_len]
    
    corr, p_value = pearsonr(psd_real, psd_gen)
    print(f"  整体PSD相关性: {corr:.4f} (p={p_value:.2e})")
    
    print("\n【2. 各频段相似度】")
    band_corrs = {}
    for band_name, (fmin, fmax) in bands.items():
        mask = (f_real >= fmin) & (f_real <= fmax)
        if mask.sum() > 0:
            corr, _ = pearsonr(psd_real[mask], psd_gen[mask])
            band_corrs[band_name] = corr
            print(f"  {band_name:20s}: {corr:.4f}")
    
    mean_band_corr = np.mean(list(band_corrs.values()))
    print(f"  平均频段相关性: {mean_band_corr:.4f}")
    
    print("\n【3. 各类别PSD分析】")
    for c in range(4):
        print(f"\n  {class_names[c]}:")
        real_mask = real_labels == c
        gen_mask = gen_labels == c
        
        if np.sum(real_mask) > 0 and np.sum(gen_mask) > 0:
            real_class_data = real_data[real_mask]
            gen_class_data = gen_data[gen_mask]
            
            f_real_c, psd_real_c = compute_psd(real_class_data)
            f_gen_c, psd_gen_c = compute_psd(gen_class_data)
            
            min_len = min(len(psd_real_c), len(psd_gen_c))
            psd_real_c = psd_real_c[:min_len]
            psd_gen_c = psd_gen_c[:min_len]
            f_real_c = f_real_c[:min_len]
            
            corr_c, _ = pearsonr(psd_real_c, psd_gen_c)
            print(f"    类别PSD相关性: {corr_c:.4f}")
            
            # Alpha和Beta频段功率
            alpha_real = compute_band_power(psd_real_c, f_real_c, 8, 13)
            alpha_gen = compute_band_power(psd_gen_c, f_real_c, 8, 13)
            beta_real = compute_band_power(psd_real_c, f_real_c, 13, 30)
            beta_gen = compute_band_power(psd_gen_c, f_real_c, 13, 30)
            
            print(f"    Alpha频段功率: Real={alpha_real:.4f}, Gen={alpha_gen:.4f}, 差异={abs(alpha_real-alpha_gen)/alpha_real*100:.2f}%")
            print(f"    Beta频段功率:  Real={beta_real:.4f}, Gen={beta_gen:.4f}, 差异={abs(beta_real-beta_gen)/beta_real*100:.2f}%")
    
    print("\n【4. 数据统计特性】")
    print(f"  真实数据形状: {real_data.shape}")
    print(f"  生成数据形状: {gen_data.shape}")
    print(f"  真实数据均值: {real_data.mean():.4f}, 标准差: {real_data.std():.4f}")
    print(f"  生成数据均值: {gen_data.mean():.4f}, 标准差: {gen_data.std():.4f}")
    
    # 检查数据对齐效果
    mean_diff = abs(real_data.mean() - gen_data.mean())
    std_diff = abs(real_data.std() - gen_data.std())
    print(f"  均值差异: {mean_diff:.6f}")
    print(f"  标准差差异: {std_diff:.6f}")
    
    print("\n【5. 结果评估】")
    print("  [标准] 整体PSD相关性 > 0.7: 优秀")
    print("  [标准] 整体PSD相关性 > 0.5: 良好")
    print("  [标准] 整体PSD相关性 < 0.5: 需要改进")
    
    if corr > 0.7:
        print(f"  [优秀] 整体PSD相关性优秀 ({corr:.4f})")
    elif corr > 0.5:
        print(f"  [良好] 整体PSD相关性良好 ({corr:.4f})，可以进一步优化")
    else:
        print(f"  [需改进] 整体PSD相关性较低 ({corr:.4f})，需要检查模型和数据对齐")
    
    if mean_band_corr > 0.7:
        print(f"  [优秀] 平均频段相关性优秀 ({mean_band_corr:.4f})")
    elif mean_band_corr > 0.5:
        print(f"  [良好] 平均频段相关性良好 ({mean_band_corr:.4f})")
    else:
        print(f"  [需改进] 平均频段相关性较低 ({mean_band_corr:.4f})")
    
    print("\n" + "="*70)

def main():
    print("="*70)
    print("PSD结果分析工具")
    print("="*70)
    
    # 加载真实数据
    print("\n[1/4] 加载真实数据...")
    real_data, real_labels = load_real_data(subject_id=1, session_id=1)
    print(f"  真实数据: {real_data.shape}, 标签分布: {np.bincount(real_labels)}")
    
    # 加载DDPM模型
    print("\n[2/4] 加载DDPM模型...")
    ddpm = load_ddpm_model()
    if ddpm is None:
        print("[ERROR] 无法加载DDPM模型")
        return
    print("  [OK] DDPM模型加载成功")
    
    # 生成样本
    print("\n[3/4] 生成DDPM样本...")
    gen_data, gen_labels = generate_ddpm_samples(ddpm, n_samples_per_class=25)
    print(f"  生成数据: {gen_data.shape}, 标签分布: {np.bincount(gen_labels)}")
    
    # 对齐数据
    print("\n[3.5/4] 对齐生成数据到真实数据统计特性...")
    gen_data = normalize_generated_data_to_real_stats(real_data, gen_data)
    
    # 分析结果
    print("\n[4/4] 分析PSD结果...")
    analyze_psd_results(real_data, real_labels, gen_data, gen_labels)

if __name__ == '__main__':
    main()


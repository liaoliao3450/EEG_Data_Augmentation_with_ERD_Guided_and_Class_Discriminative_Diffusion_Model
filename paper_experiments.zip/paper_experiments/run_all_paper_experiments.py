"""
运行所有论文补充实验
Run All Paper Experiments
"""

import sys
import os
import time
import subprocess

def run_experiment(script_name, description):
    """运行单个实验"""
    print("\n" + "="*80)
    print(f"开始实验: {description}")
    print(f"脚本: {script_name}")
    print("="*80 + "\n")
    
    start_time = time.time()
    
    try:
        # 运行脚本
        result = subprocess.run(
            [sys.executable, script_name],
            cwd=os.path.dirname(os.path.abspath(__file__)),
            capture_output=False,
            text=True
        )
        
        elapsed_time = time.time() - start_time
        
        if result.returncode == 0:
            print(f"\n✅ 实验完成! 用时: {elapsed_time:.1f}秒")
            return True
        else:
            print(f"\n❌ 实验失败! 返回码: {result.returncode}")
            return False
            
    except Exception as e:
        elapsed_time = time.time() - start_time
        print(f"\n❌ 实验出错: {e}")
        print(f"用时: {elapsed_time:.1f}秒")
        return False

def main():
    print("="*80)
    print("论文补充实验 - 批量运行")
    print("="*80)
    print("\n将依次运行以下5个实验:")
    print("1. 消融实验 (Ablation Study)")
    print("2. 统计显著性检验 (Statistical Significance Test)")
    print("3. 生成模型对比 (Comparison with Other Generative Models)")
    print("4. 数据质量分析 (Data Quality Analysis)")
    print("5. 增强比例分析 (Augmentation Ratio Analysis)")
    
    input("\n按Enter键开始运行...")
    
    experiments = [
        ("1_ablation_study.py", "消融实验 (Ablation Study)"),
        ("2_statistical_test.py", "统计显著性检验 (Statistical Test)"),
        ("3_compare_generative_models.py", "生成模型对比 (Model Comparison)"),
        ("4_data_quality_analysis.py", "数据质量分析 (Quality Analysis)"),
        ("5_augmentation_ratio_analysis.py", "增强比例分析 (Ratio Analysis)")
    ]
    
    results = []
    total_start_time = time.time()
    
    for script, description in experiments:
        success = run_experiment(script, description)
        results.append((description, success))
        
        if not success:
            print(f"\n⚠️  警告: {description} 失败")
            response = input("是否继续运行下一个实验? (y/n): ")
            if response.lower() != 'y':
                print("用户中止实验")
                break
    
    total_elapsed_time = time.time() - total_start_time
    
    # 打印总结
    print("\n" + "="*80)
    print("实验运行总结")
    print("="*80)
    
    print(f"\n总用时: {total_elapsed_time/60:.1f} 分钟")
    print(f"\n实验结果:")
    
    success_count = 0
    for description, success in results:
        status = "✅ 成功" if success else "❌ 失败"
        print(f"  {status} - {description}")
        if success:
            success_count += 1
    
    print(f"\n完成率: {success_count}/{len(results)} ({success_count/len(results)*100:.0f}%)")
    
    # 输出文件位置
    print("\n" + "="*80)
    print("输出文件位置:")
    print("="*80)
    print("\n结果文件:")
    print("  - outputs/results/paper_experiments/ablation_study.json")
    print("  - outputs/results/paper_experiments/statistical_test.json")
    print("  - outputs/results/paper_experiments/generative_models_comparison.json")
    print("  - outputs/results/paper_experiments/data_quality_report.json")
    print("  - outputs/results/paper_experiments/augmentation_ratio_analysis.json")
    
    print("\n图表文件:")
    print("  - outputs/figures/paper_experiments/statistical_test.png")
    print("  - outputs/figures/paper_experiments/data_quality_summary.png")
    print("  - outputs/figures/paper_experiments/augmentation_ratio_analysis.png")
    
    print("\n" + "="*80)
    print("下一步:")
    print("="*80)
    print("1. 查看生成的JSON文件，获取实验数据")
    print("2. 查看生成的PNG图片，用于论文插图")
    print("3. 使用提供的LaTeX代码，插入到论文中")
    print("4. 根据实验结果，撰写分析和讨论部分")
    
    if success_count == len(results):
        print("\n🎉 所有实验成功完成！论文内容已大大丰富！")
    else:
        print(f"\n⚠️  有 {len(results) - success_count} 个实验失败，请检查错误信息")

if __name__ == '__main__':
    main()
